# Authzie 1.0.0 Design

**Audience:** Product managers and service owners  
**Reading time:** About 5 minutes

## 1. Overview

Authzie is a centralized authorization service for one tenant. It answers:

> Can this user or service account perform this action on this resource?

Authzie does not sign business users in. The business service or identity provider authenticates the user first. The business backend then asks Authzie for a decision and enforces the result.

<a href="assets/authzie-overview.png"><img src="assets/authzie-overview.png" width="800" alt="Authzie system context"></a>

Authzie 1.0.0 provides:

- Role-based access control (RBAC).
- Users and groups mirrored from LDAP / Active Directory.
- Permissions scoped to a tenant, service, or resource tree.
- Service credentials for trusted backend calls.
- Administrator management and audit logs.
- Default-deny behavior when access cannot be confirmed.

It does not provide business-user login, nested groups, explicit Deny rules, or item-level business restrictions.

## 2. Authorization Model

| Concept | Purpose |
| --- | --- |
| Subject | A user, group, or service account that can receive access. |
| Service | A protected business application, such as Jira or Service Desk. |
| Resource | A protected container, such as a project or workspace. Resources form a tree. |
| Permission | An action on a resource type, such as `jira.project.issue_edit`. |
| Role | A reusable set of permissions. |
| Assignment | A subject receiving a role within a scope. |

A user's effective access is the combination of direct assignments and assignments granted to the user's active groups. Permissions are additive: one valid matching assignment is enough to allow the request. Authzie 1.0.0 has no Deny rule.

## 3. How Authentication Works

Authzie uses three separate authentication paths.

### Business User Identity

1. The user signs in through the business application or its identity provider.
2. The business backend obtains the user's LDAP `objectGUID` from trusted identity data.
3. The backend asks Authzie to resolve that value to an internal subject ID.
4. Unknown or inactive users are not allowed.

Authzie never receives the business user's password. The backend must not accept a username, subject ID, resource ID, or action directly from untrusted end-user input.

### Business Service Authentication

The business service calls Authzie with a revocable credential bound to that service. Credential scopes control whether it may perform authorization checks, resolve subjects, or manage its resources.

The credential authenticates the calling service, not the end user. A service credential cannot authorize access to another service's resources.

### Administrator Authentication

Administrators sign in to Authzie with an LDAP username and password. Authzie validates the password through LDAP and then checks the LDAP user ID against its administrator allowlist. A valid administrator receives a protected management session.

In 1.0.0, the administrator allowlist is hard-coded. Changing administrators requires a code change and redeployment.

## 4. Authorization Flow

<a href="assets/authzie-check-flow.png"><img src="assets/authzie-check-flow.png" width="800" alt="Authzie authorization request flow"></a>

For a request such as “edit an issue in Project A”:

1. The business service authenticates the user and confirms that the issue belongs to Project A.
2. The service resolves the trusted LDAP `objectGUID` to an Authzie subject ID.
3. The service sends Authzie its credential, the subject ID, Project A's resource ID, and the `issue_edit` action.
4. Authzie authenticates the service and validates the subject, resource, and permission.
5. Authzie checks the user's direct assignments and active group assignments.
6. Authzie returns `ALLOW` if an active role contains the permission and its scope covers Project A. Otherwise it returns `DENY`.
7. The business service allows the operation only when Authzie returns HTTP 200 with `allowed=true`.

Timeouts, non-200 responses, unavailable policy data, and stale LDAP data for users must all be treated as denied. Decision results are not cached in 1.0.0, so permission changes apply to the next check.

Authzie checks the project container, not the individual issue. After an Authzie `ALLOW`, the business service must still enforce issue visibility, workflow rules, and other business restrictions.

## 5. Decision Rules and Scope

A request is allowed only when all of these conditions are true:

1. The caller has a valid credential for the target service.
2. The subject and resource exist and are active.
3. The requested action is defined for the resource type.
4. The subject, or one of the user's active groups, has an active role containing the permission.
5. The assignment scope covers the target resource.

If any condition fails, Authzie denies the request.

<a href="assets/authzie-scope-coverage.png"><img src="assets/authzie-scope-coverage.png" width="800" alt="Authzie resource scope coverage"></a>

| Scope | Coverage |
| --- | --- |
| Tenant | All services and resources in the tenant. |
| Service | All resources in one service. |
| Resource with descendants | The selected resource and its active descendants. |
| Resource only | Exactly the selected resource. |

Each service has a root resource for actions without a specific business object, such as creating a project.

Example: if the `Developers` group receives a `Project Editor` role on Project A with descendant coverage, its members can edit items in Project A but not Project B unless another assignment covers Project B.

## 6. Administration and Policy Changes

An administrator configures a service by creating its resource types, permissions, resource tree, roles, assignments, service accounts, and credentials.

Every successful configuration change is written with an audit record and published as a new policy version. Disabling a service, role, resource, or subject—and revoking a credential—stops the related authorization. Re-enabling supported objects restores their retained assignments.

Users, groups, and direct group membership come from the LDAP mirror and are read-only in Authzie. If the mirror has never completed or becomes too stale, user checks are unavailable and therefore denied. Service-account checks are not affected by LDAP staleness.

## 7. Deployment Boundary

Authzie 1.0.0 runs as one instance with one database per tenant. It is a runtime dependency for protected business operations. The business service must fail closed whenever Authzie cannot return a confirmed allow decision.

Detailed API and implementation information is available in [dev-1.0.0.md](dev-1.0.0.md).
