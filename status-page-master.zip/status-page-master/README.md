# status-page

```bash
npm install jquery --save
npm install bootstrap --save

```