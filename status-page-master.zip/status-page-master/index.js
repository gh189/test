const express = require('express');
const app = express();
const port = process.env.port || 3000;
var mustacheExpress = require('mustache-express');
app.engine('html', mustacheExpress());
app.set('view engine', 'mustache');
app.set('views', __dirname + '/views');

app.use('/static', express.static('static'))
app.use('/static', express.static('node_modules'))
// app.use('/webfonts', express.static(__dirname + '/static/@fortawesome/fontawesome-free/webfonts'));

// etcd
var Etcd = require('node-etcd');
etcd = new Etcd("10.0.1.6:2379");
var info = etcd.getSync("/zhang", { recursive: true });

// const path = require('path');
// app.get('/', (req, res) => res.sendFile(path.join(__dirname, './index.html')))
app.get('/', function(req,res) {
    var haStats = require('haproxy-stats');
    haStats('http://10.0.1.6:88/stats;csv;norefresh', function(err, data) {
        var stats = []
        for (var key in data) {
            if (key != "stats" && key != "balancer") {
                // console.log(data[key]["BACKEND"]["status"]);
                var item = {};
                item["name"] = key;
                if (data[key]["BACKEND"]["status"] == "UP") {
                    item["status"] = true;
                }
                else {
                    item["status"] = false;
                }

                stats.push(item);
            }
        }
        msg = "Sorry, we're down for scheduled maintenance right now.";
        // msg = "";
        console.log(info["body"]);

        res.render('index.html', {"msg": msg, "stats": stats});
    });
});

app.listen(port, () => console.log(`Example app listening on port ${port}!`));
