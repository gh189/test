### Notification Manager
#### Highlights
  * JWT
  * LDAP based auth
  * GSD/Service Now Cache (Postgres)
  * Admins: hard-coded

#### Database
  * data (number, change owner, start & end time, duration)
  * banner, cr + text, remove if closed, cache, refresh every 5 mins,
  * queue, unprocessed???

| Change Order | Title | Summary |
|--------------|-------|---------|
| Header       | Title |         |
| Paragraph    | Text  |         |

#### Development
```shell
docker pull postgres:latest
docker run --name postgres -p 5432:5432 -e POSTGRES_PASSWORD=mysecretpassword -d postgres
docker pull atlassian/confluence-server:latest
docker run --name="confluence" -d -p 8090:8090 -p 8091:8091 atlassian/confluence-server:latest
```

#### References
  * https://confluence.atlassian.com/conf713/confluence-storage-format-1077913458.html
  * 