$(document).ready(function() {
    var jqxhr = $.getJSON( "/login", function(data) {
        $("#welcome").html(`&nbsp; Hello, ${data.user}`)
        $("#logout").removeClass("is-hidden");
        $("#login").addClass("is-hidden");
    }).fail(function() {
        $("#logout").addClass("is-hidden");
        $("#login").removeClass("is-hidden");
    });

    $('#username').on('input',function(e){
        $("#loginMsg").addClass("is-hidden");
    });

    $('#password').on('input',function(e){
        $("#loginMsg").addClass("is-hidden");
    });

    $( "#loginBtn" ).on( "click", function(event) {
        event.preventDefault();
        $.ajax({
            url: "/login",
            type: "POST",
            dataType:'json',
            contentType : 'application/json',
            data: JSON.stringify({username: $("#username").val(), password: $("#password").val()}),
            success: function(data, status, xhr){
                console.log(xhr.status);
                location.reload();
            },
            error: function (xhr, ajaxOptions, thrownError) {
                $("#loginMsg").removeClass("is-hidden");
                console.log(xhr.status);
                console.log(thrownError);
            }
        });
    });

    $("#logout").click(function(){
        $.removeCookie('jwtToken', { path: '/' });
        $.removeCookie("data")
        location.reload();
    });

    $( "#send" ).on( "click", function(event) {
        event.preventDefault();
        var data = {};
        data['order'] = $("#order").val();
        data['summary'] = $("#summary").val();
        data['title'] = $("#title").val();
        data['details'] = $("#details").val();
        data['link'] = $("#link").val();
        data['services'] = $("#services").val();
        data['start'] = $("#start").val();
        data['duration'] = $("#duration-days").val() * 21600 + $("#duration-hours").val() * 3600 + $("#duration-minutes").val() * 60 + $("#duration-seconds").val();
        data['channels'] = { "blog": $("#blog").is(":checked"), "symphony": $("#symphony").is(":checked"), "ins": $("#ins").is(":checked"), "email": $("#email").is(":checked"), "banner": $("#banner").is(":checked") }
        data['test'] = $("#test").is(":checked");
        console.log(data);
        $.ajax({
            url: "/notify",
            type: "POST",
            dataType:'json',
            contentType : 'application/json',
            data: JSON.stringify(data),
            success: function(data, status, xhr){
                console.log(xhr.status);
                $('#message').css('display','block');
                $('#message').addClass("is-success");
                $('#message').text("Notification sent.");
            },
            error: function (xhr, ajaxOptions, thrownError) {
                console.log(xhr.status);
                console.log(thrownError);
                $('#message').css('display','block');
                $('#message').addClass("is-danger");
                $('#message').text("Failed.");
            }
        });
    });
});