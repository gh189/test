package com.lab.tools;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.slf4j.Logger;

import javax.naming.directory.InitialDirContext;

import java.util.concurrent.TimeUnit;

import static spark.Spark.*;
import static spark.Spark.post;

public class Web {
    static final long COOKIE_TIMEOUT_IN_SECONDS = TimeUnit.DAYS.toSeconds(15);
    static final Logger logger = MyLogger.getLogger(Web.class.getCanonicalName());
    private JsonObject banner;

    public Web(JsonObject jsonObject) {
        banner = jsonObject;
    }

    public void start() {
        port(8000);
        staticFiles.location("/public");
        get("/login", (req, res) -> {
            System.out.println("headers: " + req.headers("authorization"));
            if (req.cookies().containsKey("jwtToken") && !req.cookie("jwtToken").isEmpty()) {
                try {
                    res.status(200);
                    res.type("application/json");
                    String user = LoginHandler.verifyCookie(req.cookie("jwtToken")).getClaim("name").asString();
                    return "{\"user\":\"" + user +  "\"}";
                } catch (Exception e) {
                    res.status(401);
                    return "Unauthorized";
                }
            } else {
                res.status(401);
                return "Unauthorized";
            }
        });

        post("/login", (req, res) -> {
            System.out.println(req.body());
            JsonObject obj = new Gson().fromJson(req.body(), JsonObject.class);
            System.out.println("user: " + obj.get("username").getAsString());
            System.out.println("pass: " + obj.get("password").getAsString());
            try {
                InitialDirContext initialDirContext = LdapAuth.login(obj.get("username").getAsString(), obj.get("password").getAsString());
                res.cookie(
                        "jwtToken",
                        LoginHandler.createCookie(obj.get("username").getAsString(), LdapAuth.searchName(initialDirContext, obj.get("username").getAsString())),
                        (int) COOKIE_TIMEOUT_IN_SECONDS,
                        true);
                res.status(200);
                res.type("application/json");
                return "{\"message\":\"Success.\"}";
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage() + ", " + e.getCause());
//                e.printStackTrace();
                res.status(401);
                res.type("application/json");
                return "{\"message\":\"Failed.\"}";
            }
        });

        post("/notify", (req, res) -> {
            System.out.println(req.cookies());
            JsonObject obj = new Gson().fromJson(req.body(), JsonObject.class);

            System.out.println(obj.toString());
            logger.info("Notification details: " + obj);
            return "{\"message\":\"Done.\"}";
        });

        get("/banner", (req, res) -> {
            res.status(200);
            res.type("application/json");
            return "{\"message\":\"" + banner.get("status") + "\"}";
        });

        // keepie
        post("/secrets", (req, res) -> {
            System.out.println(req.cookies());
            res.cookie("foo", "bar");
            return "Done.";
        });

        // pgmaker
        post("/pg", (req, res) -> {
            System.out.println(req.cookies());
            res.cookie("foo", "bar");
            return "Done.";
        });
    }
}
