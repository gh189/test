package com.lab.tools;

public class Symphony {
    private String username;
    private String password;

    public Symphony(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public void sendMessage() {

    }
}
