package com.lab.tools;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.KeyFactory;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * openssl genrsa -out private.pem 3072
 * openssl rsa -in private.pem -pubout -out public.pem
 * # convert private key to pkcs8 format in order to import it from Java
 * openssl pkcs8 -topk8 -in private.pem -inform pem -out private_pkcs8.pem -outform pem -nocrypt
 */
public class LoginHandler {
    static final long SESSION_TIMEOUT_IN_SECONDS = TimeUnit.DAYS.toSeconds(15);
    static RSAPublicKey publicKey;
    static RSAPrivateKey privateKey;
    static Algorithm algorithm;
    public static void init() throws NoSuchAlgorithmException, InvalidKeySpecException, URISyntaxException, IOException {
//        String privateKeyContent = new String(Files.readAllBytes(Paths.get(ClassLoader.getSystemResource("private_pkcs8.pem").toURI())));
//        String publicKeyContent = new String(Files.readAllBytes(Paths.get(ClassLoader.getSystemResource("public.pem").toURI())));
        String privateKeyContent = new String(Files.readAllBytes(Paths.get("private_pkcs8.pem")));
        String publicKeyContent = new String(Files.readAllBytes(Paths.get("public.pem")));
        privateKeyContent = privateKeyContent.replaceAll("\\n", "").replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "");
        publicKeyContent = publicKeyContent.replaceAll("\\n", "").replace("-----BEGIN PUBLIC KEY-----", "").replace("-----END PUBLIC KEY-----", "");
        KeyFactory kf = KeyFactory.getInstance("RSA");

        PKCS8EncodedKeySpec keySpecPKCS8 = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(privateKeyContent));
        privateKey = (RSAPrivateKey) kf.generatePrivate(keySpecPKCS8);

        X509EncodedKeySpec keySpecX509 = new X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyContent));
        publicKey = (RSAPublicKey) kf.generatePublic(keySpecX509);

        algorithm = Algorithm.RSA256(publicKey, privateKey);
    }

    public static String createCookie(String id, String name) throws Exception {
        init();
        String jwt = JWT.create()
                .withExpiresAt(new Date(System.currentTimeMillis() + (SESSION_TIMEOUT_IN_SECONDS * 1000)))
                .withSubject(id)
                .withClaim("name", name)
                .sign(algorithm);
        return jwt;
    }

    public static DecodedJWT verifyCookie(String jwt) throws NoSuchAlgorithmException, InvalidKeySpecException, URISyntaxException, IOException {
        init();
        Algorithm algorithm = Algorithm.RSA256(publicKey, privateKey);
        JWTVerifier verifier = JWT.require(algorithm).build();
        return verifier.verify(jwt);
    }
}
