package com.lab.tools;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import java.util.Properties;

public class LdapAuth {
    public static InitialDirContext login(String username, String password) throws NamingException {
        Properties props = new Properties();
        props.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        props.put(Context.PROVIDER_URL, "ldap://10.0.1.8:389");
        props.put(Context.SECURITY_AUTHENTICATION, "simple");
        props.put(Context.SECURITY_PRINCIPAL, String.format("uid=%s,cn=users,dc=lab,dc=local", username));
        props.put(Context.SECURITY_CREDENTIALS, password);
        InitialDirContext context = new InitialDirContext(props);
//        context.close();
        return context;
    }

    public static String searchName(InitialDirContext ctx, String id) throws NamingException {
        NamingEnumeration<?> namingEnum = ctx.search("dc=lab,dc=local", String.format("(employeeNumber=%s)", id), getSimpleSearchControls());
        String displayName = "";
        while (namingEnum.hasMore ()) {
            SearchResult result = (SearchResult) namingEnum.next();
            Attributes attrs = result.getAttributes ();
            displayName = attrs.get("displayName").get().toString();
        }

        namingEnum.close();
        return displayName;
    }

    private static SearchControls getSimpleSearchControls() {
        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        searchControls.setTimeLimit(30000);
        //String[] attrIDs = {"objectGUID"};
        //searchControls.setReturningAttributes(attrIDs);
        return searchControls;
    }
}
