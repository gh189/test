package com.lab.tools;

public class Banner {
    public static String get() {
        // get banner from db
        return "";
    }
}
