package com.lab.tools;

import org.slf4j.Logger;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Date;
import java.util.Properties;

public class Email {
    static final Logger logger = MyLogger.getLogger(Email.class.getCanonicalName());
    private static Session session;

    public Email() {
        // change it
        String server = "smtp.example.com";

        Properties props = System.getProperties();
        props.put("mail.smtp.host", server);
        props.put("mail.smtp.socketFactory.port", "25");
        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.port", "25");

        session = Session.getInstance(props, null);
    }

    public void send(String toEmail, String subject, String body){
        try {
            MimeMessage msg = new MimeMessage(session);
            //set message headers
            msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
            msg.addHeader("format", "flowed");
            msg.addHeader("Content-Transfer-Encoding", "8bit");

            // change it
            msg.setFrom(new InternetAddress("no_reply@example.com"));
            // change it
            msg.setReplyTo(InternetAddress.parse("no_reply@example.com", false));
            msg.setSubject(subject, "UTF-8");
            msg.setText(body, "UTF-8");
            msg.setSentDate(new Date());
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail, false));

            Transport.send(msg);
            logger.info("Email sent successfully!!");
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("Failed to send email, error: " + e.getMessage());
        }
    }
}
