package com.lab.tools;

import com.google.gson.JsonObject;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.impl.StdSchedulerFactory;

import java.util.Properties;

import static org.quartz.JobBuilder.newJob;
import static org.quartz.SimpleScheduleBuilder.simpleSchedule;
import static org.quartz.TriggerBuilder.newTrigger;

/**
 * Cache update scheduler
 */
public class CacheService {
    public static int UPDATE_INTERVAL = 2;
    public static void start(JsonObject json) throws SchedulerException {
        Properties props = new Properties();
        props.setProperty("org.quartz.threadPool.threadCount", "2");
        StdSchedulerFactory schedulerFactory = new StdSchedulerFactory(props);
        Scheduler scheduler = schedulerFactory.getScheduler();

        JobDetail job = newJob(CacheJob.class)
                .withIdentity("CacheJob")
                .build();

        job.getJobDataMap().put("PARAM_1_NAME", json);

        Trigger trigger = newTrigger()
                .withIdentity("CacheJob")
                .startNow()
                .withSchedule(simpleSchedule()
                        .withIntervalInSeconds(UPDATE_INTERVAL)
                        .repeatForever())
                .build();

        scheduler.scheduleJob(job, trigger);
        scheduler.start();
    }
}
