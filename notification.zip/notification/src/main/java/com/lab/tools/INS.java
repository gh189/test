package com.lab.tools;

public class INS {
}
