package com.lab.tools;


import org.slf4j.Logger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DB {
    static final Logger logger = MyLogger.getLogger(DB.class.getCanonicalName());

    public static void test(String url, String user, String pass) throws SQLException {
        try (Connection conn = DriverManager.getConnection(url, user, pass);
             Statement stmt = conn.createStatement()) {
            stmt.executeQuery("SELECT 1;");
        } catch (SQLException e) {
            logger.error("Test failed.");
        }
    }
}
