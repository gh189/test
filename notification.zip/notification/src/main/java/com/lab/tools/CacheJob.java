package com.lab.tools;

import com.google.gson.JsonObject;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.slf4j.Logger;

/**
 * Get latest change order details from Service now and also remove closed items
 */
public class CacheJob implements Job {
    static final Logger logger = MyLogger.getLogger(CacheJob.class.getCanonicalName());
    public void execute(JobExecutionContext context) {

        JobDataMap dataMap = context.getJobDetail().getJobDataMap();
        //fetch parameters from JobDataMap
        JsonObject first_param = (JsonObject) dataMap.get("PARAM_1_NAME");

        logger.info("CacheJob: " + first_param.toString());
        first_param.addProperty("status", System.currentTimeMillis());
    }
}