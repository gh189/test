package com.lab.tools;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import okhttp3.*;
import org.slf4j.Logger;

import java.io.IOException;

public class Confluence {
    public OkHttpClient client;
    private String username;
    private String password;
    static final Logger logger = MyLogger.getLogger(Confluence.class.getCanonicalName());

    public Confluence(String username, String password) {
        this.username = username;
        this.password = password;
        client = Utils.getHttpClient();
    }

    public void createBlog() throws IOException {
        JsonObject json = new JsonObject();
        json.addProperty("type", "blogpost");
        json.addProperty("title", "MSS Jira roleswap Sat 18th 1pm to 5pm HKT " + System.currentTimeMillis());

        JsonObject space = new JsonObject();
        space.addProperty("key", "TEST");
        json.add("space", space);

        JsonObject storage = new JsonObject();
        storage.addProperty("value", "<ac:image ac:width='120'><ri:url ri:value='https://upload.wikimedia.org/wikipedia/commons/thumb/a/aa/HSBC_logo_%282018%29.svg/1280px-HSBC_logo_%282018%29.svg.png'/></ac:image><br/><br/><strong>Change Owner: </strong>45020897<br/><strong>Order: </strong>CR1234567<br/><strong>Impacted Services: </strong>Confluence, Jira, BitBucket<br/><strong>Outage Start Time: </strong>Mon, 06 Mar 2023 16:00:00 +0000 UK<br/><strong>Outage Duration: </strong>60 mins<br/><br/>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo.");
        storage.addProperty("representation", "storage");

        JsonObject body = new JsonObject();
        body.add("storage", storage);

        json.add("body", body);

        System.out.println(json.toString());

        MediaType mediaType = MediaType.get("application/json; charset=utf-8");
        RequestBody requestBody = RequestBody.Companion.create(String.valueOf(json), mediaType);
        Request request = new Request.Builder()
                .url("http://localhost:8090/rest/api/content")
                .addHeader("Authorization", Credentials.basic("admin", "admin"))
                .post(requestBody)
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) throw new IOException("Unexpected response: " + response.body().string());
            JsonObject obj = new Gson().fromJson(response.body().string(), JsonObject.class);
            logger.info(obj.toString());
        }

    }
}
