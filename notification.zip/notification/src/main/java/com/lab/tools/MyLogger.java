package com.lab.tools;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.ConsoleAppender;
import org.slf4j.LoggerFactory;

import java.util.Objects;

public class MyLogger {
    public static org.slf4j.Logger getLogger(String name) {
        Logger logger = (Logger) LoggerFactory.getLogger(name);
        LoggerContext loggerContext = logger.getLoggerContext();

        // spark logging
        Logger root = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        root.setLevel(Level.WARN);

        PatternLayoutEncoder encoder = new PatternLayoutEncoder();
        encoder.setContext(loggerContext);
        encoder.setPattern("%date{ISO8601} %-5level [%thread] %logger{50} - %msg%n");
        encoder.start();

        ConsoleAppender<ILoggingEvent> appender = new ConsoleAppender<>();
        appender.setContext(loggerContext);
        appender.setEncoder(encoder);
        appender.start();

        logger.addAppender(appender);
        logger.setAdditive(false);

        logger.setLevel(Objects.equals(System.getenv("ENV"), "prd") ? Level.INFO : Level.DEBUG);
        return logger;
    }
}
