package com.lab.tools;

import com.google.gson.JsonObject;
import org.quartz.*;
import org.slf4j.Logger;

import java.io.IOException;

public class App {
    static final Logger logger = MyLogger.getLogger(App.class.getCanonicalName());
    public static void main(String[] args) throws SchedulerException, IOException {
        System.out.println("Hello World!");

        logger.info("INFO");
        logger.debug("DEBUG");

        JsonObject json = new JsonObject();
        json.addProperty("status", "init");
        Web web = new Web(json);

        new Thread(() -> {
            web.start();
        }).start();

        CacheService.start(json);

        logger.debug("Done");
    }
}
