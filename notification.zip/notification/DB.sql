CREATE DATABASE notification;

drop table changeorder;

CREATE TABLE changeorder (
	id VARCHAR ( 255 ) UNIQUE NOT null PRIMARY KEY,
	summary VARCHAR ( 255 ),
	title VARCHAR ( 255 ),
	status VARCHAR ( 255 ),
	start_time TIMESTAMP,
	change_owner VARCHAR ( 255 ),
);