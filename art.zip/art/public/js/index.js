$(function () {
  $.getJSON('/api/plugins')
    .done(function (data) {
      const $grid = $('#plugin-grid').empty();
      const plugins = data.plugins || [];

      if (plugins.length === 0) {
        $grid.append('<p class="loading-text">No plugins found.</p>');
        return;
      }

      plugins.forEach(function (p) {
        const safeName = $('<span>').text(p.name).html();
        const $btn = $('<button class="run-btn">▶ Run</button>');

        $btn.on('click', function () {
          $btn.prop('disabled', true).text('Running…');
          $.ajax({ url: '/api/plugins/' + encodeURIComponent(p.name), method: 'POST' })
            .done(function (res) {
              $btn.text('✓ Done').addClass('run-btn--done');
              console.log('[' + p.name + '] result:', res.result);
            })
            .fail(function (xhr) {
              $btn.text('✗ Failed').addClass('run-btn--error');
              console.error('[' + p.name + '] error:', xhr.responseJSON && xhr.responseJSON.error);
            })
            .always(function () {
              setTimeout(function () {
                $btn.prop('disabled', false).text('▶ Run')
                    .removeClass('run-btn--done run-btn--error');
              }, 3000);
            });
        });

        const $card = $(
          '<div class="card">' +
            '<div class="card-icon">🔌</div>' +
            '<h3>' + safeName + '</h3>' +
            '<p>Binary plugin available in <code>./bin</code>.</p>' +
          '</div>'
        ).append($btn);

        $grid.append($card);
      });
    })
    .fail(function () {
      $('#plugin-grid').html('<p class="loading-text">Failed to load plugins.</p>');
    });
});

