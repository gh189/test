package shared

import (
	"net/rpc"

	"github.com/hashicorp/go-plugin"
)

// Runner is the interface that both host and plugins agree on.
type Runner interface {
	Run(name string) (string, error)
}

// ---- RPC client (runs in the host process) ----

type RunnerRPC struct{ client *rpc.Client }

func (r *RunnerRPC) Run(name string) (string, error) {
	var resp string
	err := r.client.Call("Plugin.Run", name, &resp)
	return resp, err
}

// ---- RPC server (runs in the plugin process) ----

type RunnerRPCServer struct{ Impl Runner }

func (s *RunnerRPCServer) Run(name string, resp *string) error {
	var err error
	*resp, err = s.Impl.Run(name)
	return err
}

// ---- go-plugin plumbing ----

type RunnerPlugin struct{ Impl Runner }

func (p *RunnerPlugin) Server(*plugin.MuxBroker) (interface{}, error) {
	return &RunnerRPCServer{Impl: p.Impl}, nil
}

func (p *RunnerPlugin) Client(_ *plugin.MuxBroker, c *rpc.Client) (interface{}, error) {
	return &RunnerRPC{client: c}, nil
}

// Handshake is shared between host and plugin to verify compatibility.
var Handshake = plugin.HandshakeConfig{
	ProtocolVersion:  1,
	MagicCookieKey:   "ART_PLUGIN",
	MagicCookieValue: "runner",
}

// PluginMap is the map of plugins the host supports.
var PluginMap = map[string]plugin.Plugin{
	"runner": &RunnerPlugin{},
}
