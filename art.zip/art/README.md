# A.R.T
```
   █████╗     ██████╗    ████████╗
  ██╔══██╗    ██╔══██╗   ╚══██╔══╝
  ███████║    ██████╔╝      ██║   
  ██╔══██║    ██╔══██╗      ██║   
  ██║  ██║    ██║  ██║      ██║   
  ╚═╝  ╚═╝    ╚═╝  ╚═╝      ╚═╝   

  A . R . T  —  Automated Regression Testing
  ───────────────────────────────────────────
```

A.R.T is a lightweight, plugin-driven automated regression testing framework. Plugins are standalone Go binaries loaded at runtime via [hashicorp/go-plugin](https://github.com/hashicorp/go-plugin) (net/rpc). A built-in web UI lets you discover and trigger plugins from a browser without touching the CLI.

---

## Build

Build the main application and any plugin binaries separately:

```bash
# Build the demo plugin binary
go build -o bin/demo-plugin ./plugins/demo

# Build the main application
go build -o bin/art .
```

Or build everything at once:

```bash
go build ./...
```

---

## Run

```bash
# Run directly (recommended during development)
go run .

# Or run the pre-built binary
./bin/art
```

The server starts on **http://localhost:8080** by default.

---

## REST API

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/plugins` | List all plugin binaries found in `./bin` |
| `POST` | `/api/plugins/:name` | Run the named plugin and return its result |

### Examples

```bash
# List available plugins
curl http://localhost:8080/api/plugins
# → {"plugins":[{"name":"demo-plugin"}]}

# Run a plugin
curl -X POST http://localhost:8080/api/plugins/demo-plugin
# → {"plugin":"demo-plugin","result":"Hello, demo-plugin! (from plugin)"}
```

---

## Web UI

Opening **http://localhost:8080** in a browser shows the A.R.T dashboard.  
It automatically fetches the plugin list from `/api/plugins` and renders a card for each one.  
Each card has a **▶ Run** button that POSTs to `/api/plugins/:name` in the background and shows the outcome inline (✓ Done / ✗ Failed).

---

## Writing a Plugin

1. Create a new package under `plugins/<your-plugin>/main.go`.
2. Implement the `shared.Runner` interface:
   ```go
   type Runner interface {
       Run(name string) (string, error)
   }
   ```
3. Serve it with `go-plugin`:
   ```go
   func main() {
       goplugin.Serve(&goplugin.ServeConfig{
           HandshakeConfig: shared.Handshake,
           Plugins: map[string]goplugin.Plugin{
               "runner": &shared.RunnerPlugin{Impl: &yourImpl{}},
           },
       })
   }
   ```
4. Build the binary into `./bin`:
   ```bash
   go build -o bin/<your-plugin> ./plugins/<your-plugin>
   ```
5. Refresh the web UI — the new plugin card appears automatically.

---

## Project Structure

```
.
├── main.go               # Entry point — starts the web server
├── web.go                # Gin HTTP server, REST API handlers & graceful shutdown
├── go.mod                # Go module definition (module: art)
├── go.sum                # Dependency checksums
├── plugins/
│   └── demo/
│       └── main.go       # Demo plugin (logs activity, returns a greeting)
├── shared/
│   └── interface.go      # Runner interface, RPC client/server wrappers & handshake config
├── public/               # Static web assets served by Gin
│   ├── index.html        # Dashboard — dynamically loads and runs plugins via jQuery
│   ├── css/
│   │   └── index.css     # Stylesheet
│   ├── js/
│   │   ├── jquery-4.0.0.min.js
│   │   └── index.js      # Fetches /api/plugins and wires up Run buttons
│   └── images/
│       ├── favicon.png
│       └── logo.png
├── misc/                 # Design / branding assets (not served)
│   ├── avatar.svg
│   ├── avatar-s.svg
│   └── logo.svg
└── bin/                  # Compiled binaries (git-ignored)
    ├── art               # Main application binary
    └── demo-plugin       # Demo plugin binary
```
