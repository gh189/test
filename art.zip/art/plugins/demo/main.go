package main

import (
	"fmt"

	goplugin "github.com/hashicorp/go-plugin"

	"art/shared"
)

// runnerImpl is the real implementation running inside the plugins process.
type runnerImpl struct{}

func (r *runnerImpl) Run(name string) (string, error) {
	return fmt.Sprintf("Hello, %s! (from plugin)", name), nil
}

func main() {
	goplugin.Serve(&goplugin.ServeConfig{
		HandshakeConfig: shared.Handshake,
		Plugins: map[string]goplugin.Plugin{
			"runner": &shared.RunnerPlugin{Impl: &runnerImpl{}},
		},
	})
}
