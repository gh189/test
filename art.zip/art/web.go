package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"syscall"
	"time"

	hclog "github.com/hashicorp/go-hclog"
	goplugin "github.com/hashicorp/go-plugin"

	"github.com/gin-gonic/gin"

	"art/shared"
)

// listPlugins scans the ./bin directory and returns each regular file (binary plugin).
func listPlugins(c *gin.Context) {
	entries, err := os.ReadDir("./bin")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to read bin directory"})
		return
	}

	type pluginInfo struct {
		Name string `json:"name"`
	}

	plugins := make([]pluginInfo, 0)
	for _, e := range entries {
		if !e.IsDir() {
			plugins = append(plugins, pluginInfo{Name: e.Name()})
		}
	}

	c.JSON(http.StatusOK, gin.H{"plugins": plugins})
}

// runPlugin launches the named binary plugin from ./bin, calls Runner.Run, and
// returns the result as JSON.
func runPlugin(c *gin.Context) {
	name := c.Param("name")
	pluginPath := fmt.Sprintf("./bin/%s", name)

	if _, err := os.Stat(pluginPath); os.IsNotExist(err) {
		c.JSON(http.StatusNotFound, gin.H{"error": fmt.Sprintf("plugin %q not found in ./bin", name)})
		return
	}

	client := goplugin.NewClient(&goplugin.ClientConfig{
		HandshakeConfig: shared.Handshake,
		Plugins:         shared.PluginMap,
		Cmd:             exec.Command(pluginPath),
		AllowedProtocols: []goplugin.Protocol{
			goplugin.ProtocolNetRPC,
		},
		Logger: hclog.New(&hclog.LoggerOptions{
			Level:  hclog.Warn,
			Output: os.Stderr,
		}),
	})
	defer client.Kill()

	rpcClient, err := client.Client()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("plugin client error: %v", err)})
		return
	}

	raw, err := rpcClient.Dispense("runner")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("dispense error: %v", err)})
		return
	}

	runner := raw.(shared.Runner)
	msg, err := runner.Run(name)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": fmt.Sprintf("run error: %v", err)})
		return
	}

	c.JSON(http.StatusOK, gin.H{"plugin": name, "result": msg})
}

func startWebServer() {
	gin.SetMode(gin.ReleaseMode)
	r := gin.Default()

	api := r.Group("/api")
	{
		api.GET("/plugins", listPlugins)
		api.POST("/plugins/:name", runPlugin)
	}

	// Serve the public directory for all unmatched routes so that the /api
	// prefix registered above is not shadowed by a catch-all wildcard.
	r.NoRoute(gin.WrapH(http.FileServer(http.Dir("./public"))))

	srv := &http.Server{
		Addr:    ":8080",
		Handler: r,
	}

	// Start the server in a background goroutine so the main goroutine
	// can block on the quit signal instead.
	go func() {
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatalf("failed to run server: %v", err)
		}
	}()
	log.Println("server listening on :8080")

	// Block until SIGINT or SIGTERM is received.
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Println("shutting down server...")

	// Give in-flight requests up to 5 seconds to complete.
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); err != nil {
		log.Fatalf("server forced to shutdown: %v", err)
	}
	log.Println("server stopped")
}
