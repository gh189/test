# Project Instructions

## Read Cookbook
Before every run, recursively find and read every `*.md` file under the `/Users/tongjie/dev/ai-cookbook` directory, then follow the instructions contained in them.

```bash
find /Users/tongjie/dev/ai-cookbook -name '*.md'
```

Read each file found and apply its guidelines throughout the task.