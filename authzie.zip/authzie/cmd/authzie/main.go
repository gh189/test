// Command authzie runs the Authzie authorization service.
package main

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/tongjie/authzie/internal/admin"
	"github.com/tongjie/authzie/internal/config"
	"github.com/tongjie/authzie/internal/db"
	"github.com/tongjie/authzie/internal/httpapi"
	"github.com/tongjie/authzie/internal/ldapsync"
	"github.com/tongjie/authzie/internal/policy"
	"github.com/tongjie/authzie/public"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, "authzie:", err)
		os.Exit(1)
	}
}

func run() error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	logger := newLogger(cfg.LogLevel)
	slog.SetDefault(logger)
	logger.Info("starting authzie", "version", config.Version, "listen", cfg.ListenAddr)

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	pool, err := db.Open(ctx, cfg.DatabaseURL, cfg.DatabaseSchema)
	if err != nil {
		return err
	}
	defer pool.Close()

	ldapClient, err := ldapsync.NewClient(cfg.LDAP)
	if err != nil {
		return err
	}

	engine := policy.NewEngine(pool, logger, cfg.LDAP.MaxStaleness)
	if err := engine.Rebuild(ctx); err != nil {
		logger.Error("initial policy snapshot failed; /readyz stays 503 until recovered", "error", err)
	}

	syncer := ldapsync.NewSyncer(cfg.LDAP, ldapClient, engine, logger)
	syncer.Start(ctx)

	router := httpapi.New(httpapi.Options{
		Config: cfg, Engine: engine, Syncer: syncer, LDAP: ldapClient,
		Sessions: admin.NewSessions(cfg.SessionTTL), Logger: logger,
		Pinger: pool.Ping, UI: public.FS(),
	})
	srv := &http.Server{
		Addr: cfg.ListenAddr, Handler: router,
		ReadHeaderTimeout: 10 * time.Second, ReadTimeout: 30 * time.Second, WriteTimeout: 60 * time.Second, IdleTimeout: 120 * time.Second,
	}
	errCh := make(chan error, 1)
	go func() {
		if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			errCh <- err
		}
	}()

	select {
	case err := <-errCh:
		return err
	case <-ctx.Done():
	}
	logger.Info("shutting down")
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	return srv.Shutdown(shutdownCtx)
}

func newLogger(level string) *slog.Logger {
	var lvl slog.Level
	switch strings.ToLower(level) {
	case "debug":
		lvl = slog.LevelDebug
	case "warn":
		lvl = slog.LevelWarn
	case "error":
		lvl = slog.LevelError
	default:
		lvl = slog.LevelInfo
	}
	return slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: lvl}))
}
