<p align="center"><img src="docs/assets/logo.svg" width="96" alt="Authzie"></p>

# Authzie

Centralized RBAC authorization service for internal business applications. Version 1.0.0.

Business services keep authentication and their own data; they ask Authzie a single question — *may subject S perform action A on resource R?* — and receive a yes/no with a reason. Administrators manage services, permissions, roles and assignments through a built-in web UI; users and groups are mirrored read-only from LDAP.

- Default deny, additive allow, no deny rules.
- Resource tree per service; assignments scoped to tenant, service or resource (+ descendants).
- Casbin RBAC with casbin-pg-adapter for PostgreSQL policy storage; authorization evaluates an immutable in-memory enforcer.
- Full audit log for every configuration change.

## How it works

![How Authzie works](docs/assets/how-it-works.png)

1. The user signs in to your application through the IdP; your backend knows the employee ID, the object and the action.
2. Your backend calls `POST /subjects/resolve` once per session to map the employee ID to a subject ID, then `POST /check` for each protected action.
3. Authzie checks access with Casbin in memory; your backend allows only on `200` + `allowed:true`.

Administrators configure services, roles and assignments in the built-in UI and can test any decision on the **Check Access** page (it shows which assignment granted access, or why access was denied); users and groups are mirrored from LDAP, and everything is persisted and audited in PostgreSQL.

## Prerequisites

These are hard deployment requirements, not recommendations.

1. **Employee ID from the IdP.** Callers must obtain the employee ID (LDAP `uid`) from a trusted IdP claim and pass it to `POST /subjects/resolve`. Never fall back to a username, e‑mail or display name when the claim is missing.
2. **Employee IDs are unique and never reused.** The ID is the permanent identity of a user; Authzie assigns a fixed subject ULID to it.
3. **One LDAP directory per tenant.** Users are read from one user base DN, groups from one group base DN. Nested groups are not expanded.
4. **Authzie is a single point of dependency.** Callers allow access only on HTTP 200 with `"allowed": true`. Timeouts, network errors and non-200 responses mean *deny*. Do not cache decisions. Recommended client timeout ≤ 2 s.
5. **PostgreSQL 14+** reachable by the service. The database user needs `CREATE` on the target schema (PostgreSQL 15+ no longer grants this on `public` by default: `GRANT ALL ON SCHEMA public TO <user>;`). Tables are created automatically on start-up.

## Deployment

One instance and one database per tenant, single replica.

```bash
AUTHZIE_LISTEN_ADDR=0.0.0.0:8080 \
AUTHZIE_DATABASE_URL='postgres://authzie:CHANGE_ME@db:5432/authzie?sslmode=require' \
AUTHZIE_LDAP_URL=ldaps://ldap.example.com:636 \
AUTHZIE_LDAP_USER_BASE_DN='ou=people,dc=example,dc=com' \
AUTHZIE_LDAP_GROUP_BASE_DN='ou=groups,dc=example,dc=com' \
./scripts/start.sh
```

`scripts/start.sh` builds `bin/authzie` and starts it. It lists every `AUTHZIE_*` variable with its default (lab values for the LDAP/database); any variable already set in the environment takes precedence.

The admin UI is served at `/`; the API at `/api/v1`. Health: `GET /healthz` (liveness), `GET /readyz` (database reachable and policy snapshot loaded).

Administrators are an allowlist of LDAP `uid`s hard-coded in `internal/admin/session.go`; changing it requires a new release.

### Environment variables

| Variable | Default | Description |
|---|---|---|
| `AUTHZIE_LISTEN_ADDR` | `127.0.0.1:8080` | HTTP listen address. |
| `AUTHZIE_DATABASE_URL` | *(required)* | PostgreSQL DSN. |
| `AUTHZIE_DATABASE_SCHEMA` | `public` | Schema for Authzie tables. Non-default schemas are created on start-up. |
| `AUTHZIE_LOG_LEVEL` | `info` | `debug`, `info`, `warn`, `error`. JSON logs on stdout. |
| `AUTHZIE_SESSION_TTL` | `12h` | Admin session lifetime. |
| `AUTHZIE_LDAP_URL` | *(required)* | `ldap://host:389` or `ldaps://host:636`. |
| `AUTHZIE_LDAP_START_TLS` | `false` | Upgrade an `ldap://` connection with StartTLS. |
| `AUTHZIE_LDAP_CA_FILE` | | PEM bundle used to verify the LDAP server certificate. |
| `AUTHZIE_LDAP_INSECURE_SKIP_VERIFY` | `false` | Skip certificate verification (test only). |
| `AUTHZIE_LDAP_BIND_DN` | | Service bind DN used for mirroring. Empty = anonymous bind. |
| `AUTHZIE_LDAP_BIND_PASSWORD` | | Password for the bind DN. |
| `AUTHZIE_LDAP_TIMEOUT` | `10s` | Connect and per-request timeout. |
| `AUTHZIE_LDAP_PAGE_SIZE` | `500` | Paged-results page size. |
| `AUTHZIE_LDAP_USER_BASE_DN` | *(required)* | Subtree searched for users. |
| `AUTHZIE_LDAP_USER_FILTER` | `(objectClass=inetOrgPerson)` | User search filter. |
| `AUTHZIE_LDAP_USER_ID_ATTR` | `uid` | Employee ID attribute. |
| `AUTHZIE_LDAP_USER_NAME_ATTR` | `displayName` | Display name attribute. |
| `AUTHZIE_LDAP_USER_DISABLED_ATTR` | | Attribute inspected to detect disabled accounts (e.g. `sambaAcctFlags`). |
| `AUTHZIE_LDAP_USER_DISABLED_REGEX` | | Regex; a match on the attribute marks the user `inactive` (e.g. `\[.*D.*\]`). |
| `AUTHZIE_LDAP_GROUP_BASE_DN` | *(required)* | Subtree searched for groups. |
| `AUTHZIE_LDAP_GROUP_FILTER` | `(objectClass=groupOfNames)` | Group search filter. |
| `AUTHZIE_LDAP_GROUP_ID_ATTR` | `cn` | Group external ID attribute. |
| `AUTHZIE_LDAP_GROUP_NAME_ATTR` | `cn` | Group display name attribute. |
| `AUTHZIE_LDAP_GROUP_MEMBER_ATTR` | `member` | Attribute holding member DNs. |
| `AUTHZIE_LDAP_SYNC_INTERVAL` | `60s` | Interval between full mirror rounds. |
| `AUTHZIE_LDAP_MAX_STALENESS` | `30m` | After this long without a successful round, user checks return `503 ldap_mirror_stale`. |
| `AUTHZIE_LDAP_MAX_SHRINK_RATIO` | `0.5` | A round whose user count drops below this fraction of the previous one is rejected. |

## Integration example

Model your service once in the UI: create a **Service** (`jira`), **Resource types** (`project`), **Permissions** (`project.issue_edit`), **Roles**, and a **Credential** with scopes `decision:check` and `subject:resolve`. Register business objects as **Resources** under the service root, either in the UI or via `POST /api/v1/services/{id}/resources` with a `resource:write` credential.

At request time:

```bash
TOKEN='authzie_01J...'   # credential token, shown once at creation

# 1. Resolve the employee ID from the IdP claim to a stable subject ID (cache per session).
curl -s https://authzie.example.com/api/v1/subjects/resolve \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"subject_type":"user","external_id":"12345678"}'
# {"subject_id":"01J5...","status":"active","request_id":"..."}

# 2. Check on every protected action.
curl -s https://authzie.example.com/api/v1/check --max-time 2 \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"subject_type":"user","subject_id":"01J5...","resource_id":"01J6...","action":"issue_edit"}'
# {"allowed":true,"reason":"permission_granted","policy_version":42,"request_id":"..."}
```

Allow only when the status is 200 **and** `allowed` is `true`. A 200 with `allowed:false` carries a `reason` (`subject_not_found`, `subject_inactive`, `resource_not_found`, `resource_inactive`, `permission_not_found`, `permission_not_granted`) for logging. Actions without a business object (e.g. *create project*) target the service root resource, whose ID is shown on the service overview page.

## Development

```bash
go build ./...
go test ./...            # unit tests only

# integration tests need a PostgreSQL and the lab LDAP
AUTHZIE_TEST_DATABASE_URL='postgres://app:secret@127.0.0.1:5432/authzie?sslmode=disable' \
AUTHZIE_TEST_LDAP_URL=ldap://127.0.0.1:389 \
go test ./...
```

RBAC uses [Casbin](https://casbin.apache.org/) and [casbin-pg-adapter](https://github.com/apache/casbin-pg-adapter). The embedded `internal/policy/model.conf` defines subject/group membership, role permissions and scope inheritance. The adapter creates `casbin_rule` in the configured Authzie database/schema; no separate database is needed.

Management tables retain object metadata, lifecycle state and audit relationships. On startup and after each management/LDAP change, Authzie projects these records into Casbin rules, saves and reloads them through the adapter, then atomically publishes the enforcer. Existing installations migrate automatically on startup. Do not edit `casbin_rule` directly: it is regenerated from management data. If rebuilding fails, checks return `503 policy_not_ready` until recovery. Authorization evaluation uses no SQL; caller credential validation still queries PostgreSQL.

Layout: `cmd/authzie` (entry point), `internal/httpapi` (routes, auth, CSRF), `internal/policy` (Casbin model, adapter, publication), `internal/store` (management SQL), `internal/ldapsync` (mirror), `internal/db/schema.sql` (management DDL), `public/` (embedded admin UI, jQuery).
