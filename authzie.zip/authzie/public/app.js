/* Authzie admin UI. jQuery 4, hash routing, no build step. */
(function ($) {
  'use strict';

  var API = '/api/v1';
  var state = { me: null, services: {}, roles: {} };

  // ---- HTTP -------------------------------------------------------------

  function api(method, path, body) {
    var opts = { method: method, url: API + path, dataType: 'json', headers: { 'X-Authzie-CSRF': '1' } };
    if (body !== undefined) { opts.contentType = 'application/json'; opts.data = JSON.stringify(body); }
    return Promise.resolve($.ajax(opts)).catch(function (xhr) {
      var err = (xhr.responseJSON) || { error_code: 'network_error', message: xhr.statusText || 'Network error' };
      err.status = xhr.status;
      if (xhr.status === 401 && path !== '/admin/login') showLogin();
      throw err;
    });
  }
  var get = function (p) { return api('GET', p); };
  var post = function (p, b) { return api('POST', p, b || {}); };
  var patch = function (p, b) { return api('PATCH', p, b); };
  var put = function (p, b) { return api('PUT', p, b); };
  var del = function (p) { return api('DELETE', p); };

  // ---- Helpers ----------------------------------------------------------

  function esc(s) { return $('<i>').text(s == null ? '' : String(s)).html(); }
  function fmtTime(s) { if (!s) return '—'; var d = new Date(s); return isNaN(d) ? esc(s) : d.toLocaleString(); }
  function badge(status, cls) { return '<span class="badge ' + esc(cls || status) + '">' + esc(status) + '</span>'; }
  function shortId(id) { return '<span class="mono" title="' + esc(id) + '">' + esc(String(id || '').slice(-8)) + '</span>'; }
  function toast(msg, cls) {
    var t = $('#toast').text(msg).attr('class', 'toast ' + (cls || '')).removeClass('hidden');
    clearTimeout(toast.timer);
    toast.timer = setTimeout(function () { t.addClass('hidden'); }, cls === 'error' ? 5000 : 2600);
  }
  function fail(err) { toast((err && err.message) || 'Request failed', 'error'); }
  function q() {
    var m = location.hash.split('?')[1] || '';
    var out = {};
    m.split('&').forEach(function (kv) { if (!kv) return; var p = kv.split('='); out[decodeURIComponent(p[0])] = decodeURIComponent(p[1] || ''); });
    return out;
  }
  function table(cols, rows, empty) {
    if (!rows.length) return '<div class="empty">' + esc(empty || 'Nothing here yet.') + '</div>';
    var h = '<table><thead><tr>' + cols.map(function (c) { return '<th' + (c.cls ? ' class="' + c.cls + '"' : '') + '>' + esc(c.label) + '</th>'; }).join('') + '</tr></thead><tbody>';
    rows.forEach(function (r) {
      h += '<tr>' + cols.map(function (c) { return '<td' + (c.cls ? ' class="' + c.cls + '"' : '') + '>' + c.render(r) + '</td>'; }).join('') + '</tr>';
    });
    return h + '</tbody></table>';
  }
  function statusActions(obj, base, reload) {
    var next = obj.status === 'active' ? 'inactive' : 'active';
    var label = obj.status === 'active' ? 'Disable' : 'Enable';
    return '<button class="btn" data-act="status" data-next="' + next + '">' + label + '</button> ' +
           '<button class="btn danger" data-act="delete">Delete</button>';
  }
  function bindRowActions($root, sel, onStatus, onDelete) {
    $root.on('click', sel + ' [data-act="status"]', function () { onStatus($(this).closest('[data-id]').data('id'), $(this).data('next')); });
    $root.on('click', sel + ' [data-act="delete"]', function () { onDelete($(this).closest('[data-id]').data('id')); });
  }

  // ---- Modal forms ------------------------------------------------------

  // fields: [{name,label,type:'text|select|textarea|checklist|checkbox|static',options:[{value,label}],required,hint,value}]
  function modal(title, fields, submitLabel, onSubmit) {
    var $f = $('#modal-form').empty();
    fields.forEach(function (f) {
      var id = 'f-' + f.name;
      var html = '';
      if (f.type === 'static') {
        html = '<label>' + esc(f.label) + '<div class="secret mono" style="margin-top:6px">' + esc(f.value) + '</div>' + (f.hint ? '<span class="hint">' + esc(f.hint) + '</span>' : '') + '</label>';
      } else if (f.type === 'select') {
        html = '<label>' + esc(f.label) + '<select name="' + f.name + '" id="' + id + '"' + (f.required ? ' required' : '') + '>' +
          (f.options || []).map(function (o) { return '<option value="' + esc(o.value) + '"' + (o.value === f.value ? ' selected' : '') + '>' + esc(o.label) + '</option>'; }).join('') +
          '</select>' + (f.hint ? '<span class="hint">' + esc(f.hint) + '</span>' : '') + '</label>';
      } else if (f.type === 'checklist') {
        html = '<label>' + esc(f.label) + '<div class="checklist" data-name="' + f.name + '">' +
          ((f.options || []).length ? f.options.map(function (o) {
            return '<label class="check"><input type="checkbox" value="' + esc(o.value) + '"' + ((f.value || []).indexOf(o.value) >= 0 ? ' checked' : '') + '> ' + esc(o.label) + '</label>';
          }).join('') : '<span class="muted">No options available.</span>') + '</div>' + (f.hint ? '<span class="hint">' + esc(f.hint) + '</span>' : '') + '</label>';
      } else if (f.type === 'checkbox') {
        html = '<label class="check"><input type="checkbox" name="' + f.name + '"' + (f.value ? ' checked' : '') + '> ' + esc(f.label) + '</label>' + (f.hint ? '<span class="hint">' + esc(f.hint) + '</span>' : '');
      } else if (f.type === 'textarea') {
        html = '<label>' + esc(f.label) + '<textarea name="' + f.name + '" rows="2">' + esc(f.value || '') + '</textarea></label>';
      } else {
        html = '<label>' + esc(f.label) + '<input name="' + f.name + '" id="' + id + '" type="' + (f.type || 'text') + '" value="' + esc(f.value || '') + '"' +
          (f.required ? ' required' : '') + (f.pattern ? ' pattern="' + f.pattern + '"' : '') + (f.placeholder ? ' placeholder="' + esc(f.placeholder) + '"' : '') + '>' +
          (f.hint ? '<span class="hint">' + esc(f.hint) + '</span>' : '') + '</label>';
      }
      $f.append(html);
    });
    $f.append('<p class="form-error"></p><div class="form-actions"><button type="button" class="btn" data-close>Cancel</button>' +
      (onSubmit ? '<button type="submit" class="btn primary">' + esc(submitLabel || 'Save') + '</button>' : '') + '</div>');
    $('#modal-title').text(title);
    $('#modal').removeClass('hidden');
    $f.find('input,select,textarea').first().trigger('focus');
    $f.off('submit').on('submit', function (e) {
      e.preventDefault();
      if (!onSubmit) return;
      var data = {};
      fields.forEach(function (f) {
        if (f.type === 'static') return;
        if (f.type === 'checklist') data[f.name] = $f.find('[data-name="' + f.name + '"] input:checked').map(function () { return this.value; }).get();
        else if (f.type === 'checkbox') data[f.name] = $f.find('[name="' + f.name + '"]').prop('checked');
        else data[f.name] = $f.find('[name="' + f.name + '"]').val();
      });
      var $btn = $f.find('[type=submit]').prop('disabled', true);
      Promise.resolve(onSubmit(data)).then(function () { closeModal(); }, function (err) {
        $f.find('.form-error').text((err && err.message) || 'Request failed');
        $btn.prop('disabled', false);
      });
    });
  }
  function closeModal() { $('#modal').addClass('hidden'); }
  function confirmDanger(title, text, onYes) {
    modal(title, [{ type: 'static', name: 'x', label: text, value: 'This cannot be undone.' }], 'Delete', function () { return onYes(); });
    $('#modal-form [type=submit]').removeClass('primary').addClass('danger');
  }

  var KEY_HINT = 'a-z, 0-9, "_" and "-"; immutable once created';
  var KEY_PATTERN = '[a-z0-9_\\-]{1,64}';

  // ---- Routing ----------------------------------------------------------

  var routes = [
    [/^#\/services\/([0-9A-Z]{26})(?:\/([a-z-]+))?/, function (m) { return viewService(m[1], m[2] || 'overview'); }],
    [/^#\/services/, viewServices],
    [/^#\/roles\/([0-9A-Z]{26})/, function (m) { return viewRole(m[1]); }],
    [/^#\/roles/, viewRoles],
    [/^#\/assignments/, viewAssignments],
    [/^#\/users/, viewUsers],
    [/^#\/groups\/([0-9A-Z]{26})/, function (m) { return viewGroup(m[1]); }],
    [/^#\/groups/, viewGroups],
    [/^#\/sync/, viewSync],
    [/^#\/check/, viewCheck],
    [/^#\/audit/, viewAudit]
  ];

  function route() {
    if (!state.me) return;
    var hash = location.hash || '#/services';
    var section = hash.split('/')[1].split('?')[0];
    $('nav a').removeClass('active').filter('[data-nav="' + section + '"]').addClass('active');
    for (var i = 0; i < routes.length; i++) {
      var m = hash.match(routes[i][0]);
      if (m) { routes[i][1](m); return; }
    }
    location.hash = '#/services';
  }

  function head(title, sub, toolbar, crumbs) {
    return (crumbs ? '<div class="crumbs">' + crumbs + '</div>' : '') +
      '<div class="page-head"><div><h1>' + esc(title) + '</h1>' + (sub ? '<div class="sub">' + sub + '</div>' : '') + '</div><div class="toolbar">' + (toolbar || '') + '</div></div>';
  }

  // ---- Services ---------------------------------------------------------

  function loadServices() {
    return get('/services?limit=500').then(function (r) {
      state.services = {};
      r.items.forEach(function (s) { state.services[s.id] = s; });
      return r.items;
    });
  }
  function loadRoles() {
    return get('/roles?limit=500').then(function (r) {
      state.roles = {};
      r.items.forEach(function (x) { state.roles[x.id] = x; });
      return r.items;
    });
  }

  function viewServices() {
    var $m = $('#main').html(head('Services', 'Business applications protected by Authzie.', '<button class="btn primary" id="new">New service</button>'));
    loadServices().then(function (items) {
      $m.append('<div class="card flush">' + table([
        { label: 'Key', render: function (s) { return '<a href="#/services/' + s.id + '" class="mono">' + esc(s.service_key) + '</a>'; } },
        { label: 'Name', render: function (s) { return esc(s.display_name); } },
        { label: 'Status', render: function (s) { return badge(s.status); } },
        { label: 'Created', render: function (s) { return fmtTime(s.created_at); } },
        { label: '', cls: 'actions', render: function (s) { return '<span data-id="' + s.id + '">' + statusActions(s) + '</span>'; } }
      ], items, 'No services yet. Create one to start modelling permissions.') + '</div>');
    }, fail);
    $m.on('click', '#new', function () {
      modal('New service', [
        { name: 'service_key', label: 'Service key', required: true, pattern: KEY_PATTERN, placeholder: 'jira', hint: KEY_HINT },
        { name: 'display_name', label: 'Display name', placeholder: 'Jira' },
        { name: 'description', label: 'Description', type: 'textarea' }
      ], 'Create', function (d) {
        return post('/services', d).then(function (s) { toast('Service created', 'ok'); location.hash = '#/services/' + s.id; });
      });
    });
    bindRowActions($m, 'td.actions', function (id, next) {
      patch('/services/' + id, { status: next }).then(viewServices, fail);
    }, function (id) {
      var s = state.services[id];
      confirmDanger('Delete service', 'Deleting "' + s.service_key + '" removes all of its resource types, permissions, resources, service accounts, credentials and related assignments.', function () {
        return del('/services/' + id).then(function () { toast('Service deleted', 'ok'); viewServices(); });
      });
    });
  }

  var serviceTabs = [['overview', 'Overview'], ['resource-types', 'Resource types'], ['permissions', 'Permissions'], ['resources', 'Resources'], ['service-accounts', 'Service accounts'], ['credentials', 'Credentials']];

  function viewService(id, tab) {
    var $m = $('#main');
    Promise.all([get('/services/' + id), get('/services/' + id + '/resource-types?limit=500')]).then(function (res) {
      var svc = res[0], types = res[1].items;
      var typeById = {};
      types.forEach(function (t) { typeById[t.id] = t; });
      var toolbar = '<span data-id="' + svc.id + '" class="svc-actions">' + statusActions(svc) + '</span>';
      $m.html(head(svc.display_name || svc.service_key, '<span class="mono">' + esc(svc.service_key) + '</span> · ' + badge(svc.status) + (svc.description ? ' · ' + esc(svc.description) : ''), toolbar,
        '<a href="#/services">Services</a> / ' + esc(svc.service_key)));
      $m.append('<div class="tabs">' + serviceTabs.map(function (t) {
        return '<a href="#/services/' + svc.id + '/' + t[0] + '" class="' + (t[0] === tab ? 'active' : '') + '">' + t[1] + '</a>';
      }).join('') + '</div><div id="tab"></div>');
      var ctx = { svc: svc, types: types, typeById: typeById, $t: $('#tab'), base: '/services/' + svc.id, hash: '#/services/' + svc.id + '/' + tab };
      ({ 'overview': tabOverview, 'resource-types': tabTypes, 'permissions': tabPermissions, 'resources': tabResources, 'service-accounts': tabAccounts, 'credentials': tabCredentials }[tab] || tabOverview)(ctx);

      bindRowActions($m, '.svc-actions', function (sid, next) {
        patch('/services/' + sid, { status: next }).then(function () { viewService(id, tab); }, fail);
      }, function (sid) {
        confirmDanger('Delete service', 'Deleting "' + svc.service_key + '" removes all of its owned objects, credentials and related assignments.', function () {
          return del('/services/' + sid).then(function () { toast('Service deleted', 'ok'); location.hash = '#/services'; });
        });
      });
    }, fail);
  }

  function tabOverview(c) {
    Promise.all([get(c.base + '/permissions?limit=1000'), get(c.base + '/resources?limit=1000'), get(c.base + '/service-accounts?limit=1000'), get(c.base + '/credentials?limit=1000')]).then(function (r) {
      var root = r[1].items.filter(function (x) { return x.external_id === 'authzie:root'; })[0];
      c.$t.html('<div class="grid-3">' +
        '<div class="card stat"><span class="muted">Resource types</span><b>' + c.types.length + '</b></div>' +
        '<div class="card stat"><span class="muted">Permissions</span><b>' + r[0].items.length + '</b></div>' +
        '<div class="card stat"><span class="muted">Resources</span><b>' + r[1].items.length + '</b></div>' +
        '<div class="card stat"><span class="muted">Service accounts</span><b>' + r[2].items.length + '</b></div>' +
        '<div class="card stat"><span class="muted">Active credentials</span><b>' + r[3].items.length + '</b></div>' +
        '</div><div class="card"><h3>Identifiers</h3><dl class="kv">' +
        '<dt>Service ID</dt><dd class="mono">' + esc(c.svc.id) + '</dd>' +
        '<dt>Root resource ID</dt><dd class="mono">' + esc(root ? root.id : '—') + ' <span class="muted">— target for actions without a business object, e.g. <code>' + esc(c.svc.service_key) + '.service_root.project_create</code></span></dd>' +
        '<dt>Created</dt><dd>' + fmtTime(c.svc.created_at) + '</dd></dl></div>');
    }, fail);
  }

  function tabTypes(c) {
    c.$t.html('<div class="toolbar" style="margin-bottom:12px"><button class="btn primary" id="new">New resource type</button></div><div class="card flush">' + table([
      { label: 'Key', render: function (t) { return '<span class="mono">' + esc(t.type_key) + '</span>' + (t.type_key === 'service_root' ? ' ' + badge('reserved', 'neutral') : ''); } },
      { label: 'Name', render: function (t) { return esc(t.display_name); } },
      { label: 'Description', render: function (t) { return esc(t.description); } },
      { label: '', cls: 'actions', render: function (t) { return t.type_key === 'service_root' ? '' : '<span data-id="' + t.id + '"><button class="btn" data-act="edit">Edit</button> <button class="btn danger" data-act="delete">Delete</button></span>'; } }
    ], c.types) + '</div>');
    c.$t.on('click', '#new', function () {
      modal('New resource type', [
        { name: 'type_key', label: 'Type key', required: true, pattern: KEY_PATTERN, placeholder: 'project', hint: KEY_HINT + '. Leaf objects (issues, test cases) are not registered; define their actions on the container type.' },
        { name: 'display_name', label: 'Display name' }, { name: 'description', label: 'Description', type: 'textarea' }
      ], 'Create', function (d) { return post(c.base + '/resource-types', d).then(function () { toast('Resource type created', 'ok'); route(); }); });
    });
    c.$t.on('click', '[data-act="edit"]', function () {
      var t = c.typeById[$(this).closest('[data-id]').data('id')];
      modal('Edit ' + t.type_key, [{ name: 'display_name', label: 'Display name', value: t.display_name }, { name: 'description', label: 'Description', type: 'textarea', value: t.description }], 'Save',
        function (d) { return patch('/resource-types/' + t.id, d).then(route); });
    });
    c.$t.on('click', '[data-act="delete"]', function () {
      var t = c.typeById[$(this).closest('[data-id]').data('id')];
      confirmDanger('Delete resource type', 'Delete "' + t.type_key + '"? This fails while resources or permissions still use it.', function () {
        return del('/resource-types/' + t.id).then(function () { toast('Resource type deleted', 'ok'); route(); });
      });
    });
  }

  function tabPermissions(c) {
    get(c.base + '/permissions?limit=1000').then(function (r) {
      c.$t.html('<div class="toolbar" style="margin-bottom:12px"><button class="btn primary" id="new">New permission</button></div><div class="card flush">' + table([
        { label: 'Permission', render: function (p) { var t = c.typeById[p.resource_type_id]; return '<span class="mono">' + esc(c.svc.service_key + '.' + (t ? t.type_key : '?') + '.' + p.action) + '</span>'; } },
        { label: 'Resource type', render: function (p) { var t = c.typeById[p.resource_type_id]; return esc(t ? t.display_name || t.type_key : '?'); } },
        { label: 'Description', render: function (p) { return esc(p.description); } },
        { label: '', cls: 'actions', render: function (p) { return '<span data-id="' + p.id + '"><button class="btn danger" data-act="delete">Delete</button></span>'; } }
      ], r.items, 'No permissions. Add one per action, e.g. project / issue_edit.') + '</div>');
      c.$t.on('click', '#new', function () {
        modal('New permission', [
          { name: 'resource_type_id', label: 'Resource type', type: 'select', required: true, options: c.types.map(function (t) { return { value: t.id, label: t.type_key + (t.type_key === 'service_root' ? ' (actions without an object)' : '') }; }) },
          { name: 'action', label: 'Action', required: true, pattern: KEY_PATTERN, placeholder: 'issue_edit', hint: KEY_HINT },
          { name: 'description', label: 'Description', type: 'textarea' }
        ], 'Create', function (d) { return post(c.base + '/permissions', d).then(function () { toast('Permission created', 'ok'); route(); }); });
      });
      c.$t.on('click', '[data-act="delete"]', function () {
        var id = $(this).closest('[data-id]').data('id');
        confirmDanger('Delete permission', 'The permission is removed from every role that contains it.', function () {
          return del('/permissions/' + id).then(function () { toast('Permission deleted', 'ok'); route(); });
        });
      });
    }, fail);
  }

  function tabResources(c) {
    get(c.base + '/resources?limit=1000').then(function (r) {
      var byParent = {}, byId = {};
      r.items.forEach(function (x) { byId[x.id] = x; (byParent[x.parent_id || ''] = byParent[x.parent_id || ''] || []).push(x); });
      function render(parent) {
        var kids = byParent[parent] || [];
        if (!kids.length) return '';
        return '<ul>' + kids.map(function (x) {
          var t = c.typeById[x.resource_type_id];
          var isRoot = x.external_id === 'authzie:root';
          return '<li><div class="node" data-id="' + x.id + '"><span class="name">' + esc(x.display_name || x.external_id) + '</span>' +
            '<span class="type">' + esc(t ? t.type_key : '?') + '</span><span class="mono muted">' + esc(x.external_id) + (x.external_key ? ' · ' + esc(x.external_key) : '') + '</span>' +
            badge(x.status) + '<span class="actions"><button class="btn" data-act="add">Add child</button> <button class="btn" data-act="edit">Edit</button>' +
            (isRoot ? '' : ' ' + statusActions(x)) + '</span></div>' + render(x.id) + '</li>';
        }).join('') + '</ul>';
      }
      c.$t.html('<p class="muted">Resources form a tree under the service root. Parent and type are fixed after creation; assignments scoped to a parent with “include descendants” cover the whole subtree while every node on the path is active.</p><div class="card tree">' + (render('') || '<div class="empty">No resources.</div>') + '</div>');
      function resourceForm(parent, existing) {
        var fields = existing ? [
          { name: 'display_name', label: 'Display name', value: existing.display_name },
          { name: 'external_key', label: 'External key', value: existing.external_key || '', hint: 'Optional mutable business key (e.g. project key). Unique per type.' },
          { name: 'description', label: 'Description', type: 'textarea', value: existing.description }
        ] : [
          { name: 'resource_type_id', label: 'Resource type', type: 'select', required: true, options: c.types.filter(function (t) { return t.type_key !== 'service_root'; }).map(function (t) { return { value: t.id, label: t.type_key }; }) },
          { name: 'external_id', label: 'External ID', required: true, hint: 'Immutable business identifier. Cannot be reused after deletion.' },
          { name: 'external_key', label: 'External key', hint: 'Optional mutable business key (e.g. PROJ).' },
          { name: 'display_name', label: 'Display name' }, { name: 'description', label: 'Description', type: 'textarea' }
        ];
        modal(existing ? 'Edit resource' : 'New resource under “' + (parent.display_name || parent.external_id) + '”', fields, existing ? 'Save' : 'Create', function (d) {
          if (existing) {
            if (d.external_key === '') delete d.external_key;
            return patch('/resources/' + existing.id, d).then(route);
          }
          d.parent_id = parent.id;
          if (!d.external_key) delete d.external_key;
          return post(c.base + '/resources', d).then(function () { toast('Resource created', 'ok'); route(); });
        });
      }
      c.$t.on('click', '[data-act="add"]', function () { resourceForm(byId[$(this).closest('[data-id]').data('id')]); });
      c.$t.on('click', '[data-act="edit"]', function () { var x = byId[$(this).closest('[data-id]').data('id')]; resourceForm(null, x); });
      bindRowActions(c.$t, '.node', function (id, next) { patch('/resources/' + id, { status: next }).then(route, fail); }, function (id) {
        var x = byId[id];
        confirmDanger('Delete resource', 'Delete "' + (x.display_name || x.external_id) + '"? Assignments scoped to it are removed; child resources are kept. Its external ID can never be reused.', function () {
          return del('/resources/' + id).then(function () { toast('Resource deleted', 'ok'); route(); });
        });
      });
    }, fail);
  }

  function tabAccounts(c) {
    get(c.base + '/service-accounts?limit=1000').then(function (r) {
      var byId = {};
      r.items.forEach(function (x) { byId[x.id] = x; });
      c.$t.html('<div class="toolbar" style="margin-bottom:12px"><button class="btn primary" id="new">New service account</button></div><div class="card flush">' + table([
        { label: 'External ID', render: function (x) { return '<span class="mono">' + esc(x.external_id) + '</span>'; } },
        { label: 'Name', render: function (x) { return esc(x.display_name); } },
        { label: 'Subject ID', render: function (x) { return '<span class="mono">' + esc(x.id) + '</span>'; } },
        { label: 'Status', render: function (x) { return badge(x.status); } },
        { label: '', cls: 'actions', render: function (x) { return '<span data-id="' + x.id + '"><a class="btn" href="#/assignments?subject_type=service_account&subject_id=' + x.id + '">Assignments</a> <a class="btn" href="#/check?service_id=' + c.svc.id + '&subject_type=service_account&subject=' + encodeURIComponent(x.external_id) + '">Check</a> ' + statusActions(x) + '</span>'; } }
      ], r.items, 'No service accounts. They let backend jobs act as their own subject.') + '</div>');
      c.$t.on('click', '#new', function () {
        modal('New service account', [
          { name: 'external_id', label: 'External ID', required: true, placeholder: 'ci-bot', hint: 'Unique within this service. Resolvable via POST /subjects/resolve.' },
          { name: 'display_name', label: 'Display name' }, { name: 'description', label: 'Description', type: 'textarea' }
        ], 'Create', function (d) { return post(c.base + '/service-accounts', d).then(function () { toast('Service account created', 'ok'); route(); }); });
      });
      bindRowActions(c.$t, 'td.actions', function (id, next) { patch('/service-accounts/' + id, { status: next }).then(route, fail); }, function (id) {
        confirmDanger('Delete service account', 'Delete "' + byId[id].external_id + "\"? Its assignments are removed.", function () {
          return del('/service-accounts/' + id).then(function () { toast('Service account deleted', 'ok'); route(); });
        });
      });
    }, fail);
  }

  var SCOPES = [['decision:check', 'decision:check — call POST /check'], ['subject:resolve', 'subject:resolve — call POST /subjects/resolve'], ['resource:read', 'resource:read — list/get this service’s resources'], ['resource:write', 'resource:write — create resources and edit metadata']];

  function tabCredentials(c) {
    get(c.base + '/credentials?limit=1000').then(function (r) {
      c.$t.html('<div class="toolbar" style="margin-bottom:12px"><button class="btn primary" id="new">New credential</button></div><div class="card flush">' + table([
        { label: 'Name', render: function (x) { return esc(x.name || '—'); } },
        { label: 'Credential ID', render: function (x) { return '<span class="mono">' + esc(x.id) + '</span>'; } },
        { label: 'Scopes', render: function (x) { return (x.scopes || []).map(function (s) { return '<span class="chip">' + esc(s) + '</span>'; }).join(''); } },
        { label: 'Created', render: function (x) { return fmtTime(x.created_at); } },
        { label: '', cls: 'actions', render: function (x) { return '<span data-id="' + x.id + '"><button class="btn danger" data-act="delete">Revoke</button></span>'; } }
      ], r.items, 'No active credentials. Create one for each backend that calls Authzie.') + '</div>');
      c.$t.on('click', '#new', function () {
        modal('New credential', [
          { name: 'name', label: 'Name', placeholder: 'jira-backend' },
          { name: 'scopes', label: 'Scopes', type: 'checklist', value: ['decision:check', 'subject:resolve'], options: SCOPES.map(function (s) { return { value: s[0], label: s[1] }; }) }
        ], 'Create', function (d) {
          if (!d.scopes.length) return Promise.reject({ message: 'Select at least one scope' });
          return post(c.base + '/credentials', d).then(function (cr) {
            route();
            setTimeout(function () {
              modal('Credential created', [{ type: 'static', name: 'token', label: 'Token — shown only once', value: cr.token, hint: 'Store it in the calling service’s secret store now. Authzie keeps only a hash.' }], null);
            }, 50);
          });
        });
      });
      c.$t.on('click', '[data-act="delete"]', function () {
        var id = $(this).closest('[data-id]').data('id');
        confirmDanger('Revoke credential', 'Requests using this credential fail with 401 immediately.', function () {
          return del('/credentials/' + id).then(function () { toast('Credential revoked', 'ok'); route(); });
        });
      });
    }, fail);
  }

  // ---- Roles ------------------------------------------------------------

  function viewRoles() {
    var $m = $('#main').html(head('Roles', 'Reusable permission sets. A role may combine permissions from several services.', '<button class="btn primary" id="new">New role</button>'));
    loadRoles().then(function (items) {
      $m.append('<div class="card flush">' + table([
        { label: 'Name', render: function (r) { return '<a href="#/roles/' + r.id + '" class="mono">' + esc(r.name) + '</a>'; } },
        { label: 'Display name', render: function (r) { return esc(r.display_name); } },
        { label: 'Status', render: function (r) { return badge(r.status); } },
        { label: '', cls: 'actions', render: function (r) { return '<span data-id="' + r.id + '">' + statusActions(r) + '</span>'; } }
      ], items, 'No roles yet.') + '</div>');
    }, fail);
    $m.on('click', '#new', function () {
      modal('New role', [
        { name: 'name', label: 'Name', required: true, pattern: KEY_PATTERN, placeholder: 'project-editor', hint: KEY_HINT },
        { name: 'display_name', label: 'Display name' }, { name: 'description', label: 'Description', type: 'textarea' }
      ], 'Create', function (d) { return post('/roles', d).then(function (r) { toast('Role created', 'ok'); location.hash = '#/roles/' + r.id; }); });
    });
    bindRowActions($m, 'td.actions', function (id, next) { patch('/roles/' + id, { status: next }).then(viewRoles, fail); }, function (id) {
      confirmDanger('Delete role', 'Delete "' + state.roles[id].name + '"? All assignments of this role are removed.', function () {
        return del('/roles/' + id).then(function () { toast('Role deleted', 'ok'); viewRoles(); });
      });
    });
  }

  // allPermissions returns [{id,label,service_key}] across all services.
  function allPermissions() {
    return loadServices().then(function (services) {
      return Promise.all(services.map(function (s) {
        return Promise.all([get('/services/' + s.id + '/resource-types?limit=1000'), get('/services/' + s.id + '/permissions?limit=1000')]).then(function (r) {
          var t = {};
          r[0].items.forEach(function (x) { t[x.id] = x.type_key; });
          return r[1].items.map(function (p) { return { id: p.id, label: s.service_key + '.' + (t[p.resource_type_id] || '?') + '.' + p.action }; });
        });
      }));
    }).then(function (lists) { return [].concat.apply([], lists).sort(function (a, b) { return a.label < b.label ? -1 : 1; }); });
  }

  function viewRole(id) {
    var $m = $('#main');
    Promise.all([get('/roles/' + id), allPermissions()]).then(function (res) {
      var role = res[0], perms = res[1], byId = {};
      perms.forEach(function (p) { byId[p.id] = p; });
      $m.html(head(role.display_name || role.name, '<span class="mono">' + esc(role.name) + '</span> · ' + badge(role.status) + (role.description ? ' · ' + esc(role.description) : ''),
        '<button class="btn" id="edit">Edit</button> <a class="btn" href="#/assignments?role_id=' + role.id + '">Assignments</a>', '<a href="#/roles">Roles</a> / ' + esc(role.name)));
      $m.append('<div class="card"><div class="page-head" style="margin-bottom:10px"><h2 style="margin:0">Permissions (' + role.permission_ids.length + ')</h2><button class="btn primary" id="perms">Edit permissions</button></div>' +
        (role.permission_ids.length ? role.permission_ids.map(function (pid) { return '<span class="chip">' + esc(byId[pid] ? byId[pid].label : pid) + '</span>'; }).join('') : '<span class="muted">This role grants nothing yet.</span>') + '</div>');
      $m.on('click', '#perms', function () {
        modal('Permissions of ' + role.name, [{ name: 'permission_ids', label: 'Select permissions', type: 'checklist', value: role.permission_ids, options: perms.map(function (p) { return { value: p.id, label: p.label }; }) }], 'Save',
          function (d) { return put('/roles/' + id + '/permissions', d).then(function () { toast('Permissions updated', 'ok'); viewRole(id); }); });
      });
      $m.on('click', '#edit', function () {
        modal('Edit role', [{ name: 'display_name', label: 'Display name', value: role.display_name }, { name: 'description', label: 'Description', type: 'textarea', value: role.description }], 'Save',
          function (d) { return patch('/roles/' + id, d).then(function () { viewRole(id); }); });
      });
    }, fail);
  }

  // ---- Assignments ------------------------------------------------------

  function viewAssignments() {
    var f = q();
    var $m = $('#main').html(head('Assignments', 'Subject + Role + Scope. Access is additive; there are no deny rules.', '<button class="btn primary" id="new">New assignment</button>'));
    var qs = Object.keys(f).map(function (k) { return k + '=' + encodeURIComponent(f[k]); }).join('&');
    Promise.all([get('/assignments?limit=500' + (qs ? '&' + qs : '')), loadRoles(), loadServices()]).then(function (res) {
      var items = res[0].items;
      var subjectIds = {}, resourceIds = {};
      items.forEach(function (a) { subjectIds[a.subject_type + ':' + a.subject_id] = true; if (a.resource_id) resourceIds[a.resource_id] = true; });
      var lookups = [];
      Object.keys(subjectIds).forEach(function (k) {
        var p = k.split(':');
        var path = p[0] === 'user' ? '/users/' + p[1] : p[0] === 'group' ? '/groups?limit=1000' : null;
        if (path) lookups.push(get(path).then(function (r) { subjectIds[k] = p[0] === 'group' ? (r.items.filter(function (g) { return g.id === p[1]; })[0] || {}) : r; }, function () {}));
      });
      Object.keys(resourceIds).forEach(function (rid) { lookups.push(get('/resources/' + rid).then(function (r) { resourceIds[rid] = r; }, function () {})); });
      Promise.all(lookups).then(function () {
        var filters = Object.keys(f).length ? '<div class="toolbar" style="margin-bottom:12px"><span class="muted">Filtered by ' + Object.keys(f).map(function (k) { return '<span class="chip">' + esc(k + '=' + f[k]) + '</span>'; }).join('') + '</span><a class="btn" href="#/assignments">Clear</a></div>' : '';
        $m.append(filters + '<div class="card flush">' + table([
          { label: 'Subject', render: function (a) {
            var s = subjectIds[a.subject_type + ':' + a.subject_id];
            var name = s && s.external_id ? esc(s.display_name || s.external_id) + ' <span class="mono muted">' + esc(s.external_id) + '</span>' : shortId(a.subject_id);
            return badge(a.subject_type.replace('_', ' '), 'neutral') + ' ' + name; } },
          { label: 'Role', render: function (a) { var r = state.roles[a.role_id]; return r ? '<a href="#/roles/' + r.id + '" class="mono">' + esc(r.name) + '</a>' : shortId(a.role_id); } },
          { label: 'Scope', render: function (a) {
            if (a.scope_type === 'tenant') return badge('tenant', 'accent');
            if (a.scope_type === 'service') { var s = state.services[a.service_id]; return badge('service', 'accent') + ' ' + (s ? '<a href="#/services/' + s.id + '" class="mono">' + esc(s.service_key) + '</a>' : shortId(a.service_id)); }
            var r = resourceIds[a.resource_id], svc = r && state.services[r.service_id];
            return badge('resource', 'accent') + ' ' + (r && r.id ? (svc ? '<span class="mono">' + esc(svc.service_key) + '</span> / ' : '') + esc(r.display_name || r.external_id) : shortId(a.resource_id)) +
              (a.include_descendants ? ' <span class="muted">+ descendants</span>' : ' <span class="muted">only</span>'); } },
          { label: 'Created', render: function (a) { return fmtTime(a.created_at); } },
          { label: '', cls: 'actions', render: function (a) { return '<span data-id="' + a.id + '"><button class="btn danger" data-act="delete">Remove</button></span>'; } }
        ], items, 'No assignments match.') + '</div>');
      });
    }, fail);
    $m.on('click', '#new', newAssignment);
    $m.on('click', '[data-act="delete"]', function () {
      var id = $(this).closest('[data-id]').data('id');
      del('/assignments/' + id).then(function () { toast('Assignment removed', 'ok'); viewAssignments(); }, fail);
    });
  }

  // newAssignment is a two-step form: pick subject & role, then scope.
  function newAssignment(preset) {
    preset = preset || q();
    var roles = Object.keys(state.roles).map(function (k) { return state.roles[k]; });
    var services = Object.keys(state.services).map(function (k) { return state.services[k]; });
    modal('New assignment', [
      { name: 'subject_type', label: 'Subject type', type: 'select', value: preset.subject_type || 'user', options: [{ value: 'user', label: 'User' }, { value: 'group', label: 'Group' }, { value: 'service_account', label: 'Service account' }] },
      { name: 'subject_id', label: 'Subject ID', required: true, value: preset.subject_id || '', hint: 'ULID. Copy it from Users, Groups or Service accounts.' },
      { name: 'role_id', label: 'Role', type: 'select', required: true, value: preset.role_id, options: roles.map(function (r) { return { value: r.id, label: r.name + (r.status !== 'active' ? ' (inactive)' : '') }; }) },
      { name: 'scope_type', label: 'Scope', type: 'select', value: preset.scope_type || 'service', options: [{ value: 'tenant', label: 'Tenant — everything' }, { value: 'service', label: 'Service — all resources of one service' }, { value: 'resource', label: 'Resource — one resource (optionally with descendants)' }] },
      { name: 'service_id', label: 'Service', type: 'select', value: preset.service_id, options: services.map(function (s) { return { value: s.id, label: s.service_key }; }), hint: 'For service scope.' },
      { name: 'resource_id', label: 'Resource ID', value: preset.resource_id || '', hint: 'For resource scope. Copy from the service’s resource tree (hover a node, use Edit to see it).' },
      { name: 'include_descendants', label: 'Include descendants', type: 'checkbox', value: true }
    ], 'Create', function (d) {
      var body = { subject_type: d.subject_type, subject_id: d.subject_id.trim(), role_id: d.role_id, scope_type: d.scope_type };
      if (d.scope_type === 'service') body.service_id = d.service_id;
      if (d.scope_type === 'resource') { body.resource_id = d.resource_id.trim(); body.include_descendants = d.include_descendants; }
      return post('/assignments', body).then(function () { toast('Assignment created', 'ok'); viewAssignments(); });
    });
    var $f = $('#modal-form');
    function sync() {
      var sc = $f.find('[name=scope_type]').val();
      $f.find('[name=service_id]').closest('label').toggle(sc === 'service');
      $f.find('[name=resource_id]').closest('label').toggle(sc === 'resource');
      $f.find('[name=include_descendants]').closest('label').toggle(sc === 'resource');
    }
    $f.find('[name=scope_type]').on('change', sync);
    sync();
  }

  // ---- Directory --------------------------------------------------------

  function viewUsers() {
    var f = q();
    var $m = $('#main').html(head('Users', 'Read-only mirror of the LDAP directory. Employee ID is the permanent external identity.',
      '<form id="search" class="toolbar"><input class="inline" name="q" placeholder="Search ID or name" value="' + esc(f.q || '') + '"><button class="btn">Search</button></form>'));
    get('/users?limit=500' + (f.q ? '&q=' + encodeURIComponent(f.q) : '')).then(function (r) {
      $m.append('<div class="card flush">' + table([
        { label: 'Employee ID', render: function (u) { return '<span class="mono">' + esc(u.external_id) + '</span>'; } },
        { label: 'Name', render: function (u) { return esc(u.display_name); } },
        { label: 'Subject ID', render: function (u) { return '<span class="mono">' + esc(u.id) + '</span>'; } },
        { label: 'Status', render: function (u) { return badge(u.status) + (u.present ? '' : ' ' + badge('missing from LDAP', 'neutral')); } },
        { label: '', cls: 'actions', render: function (u) { return '<a class="btn" href="#/assignments?subject_type=user&subject_id=' + u.id + '">Assignments</a> <a class="btn" href="#/check?subject_type=user&subject=' + encodeURIComponent(u.external_id) + '">Check</a> <button class="btn" data-assign="' + u.id + '">Assign role</button>'; } }
      ], r.items, 'No users mirrored yet. Check LDAP Sync.') + '</div>');
    }, fail);
    $m.on('submit', '#search', function (e) { e.preventDefault(); location.hash = '#/users?q=' + encodeURIComponent($(this).find('[name=q]').val()); });
    $m.on('click', '[data-assign]', function () { var id = $(this).data('assign'); Promise.all([loadRoles(), loadServices()]).then(function () { newAssignment({ subject_type: 'user', subject_id: id }); }); });
  }

  function viewGroups() {
    var f = q();
    var $m = $('#main').html(head('Groups', 'Read-only mirror of LDAP groups. Nested groups are not expanded.',
      '<form id="search" class="toolbar"><input class="inline" name="q" placeholder="Search group" value="' + esc(f.q || '') + '"><button class="btn">Search</button></form>'));
    get('/groups?limit=500' + (f.q ? '&q=' + encodeURIComponent(f.q) : '')).then(function (r) {
      $m.append('<div class="card flush">' + table([
        { label: 'Group', render: function (g) { return '<a href="#/groups/' + g.id + '" class="mono">' + esc(g.external_id) + '</a>'; } },
        { label: 'Name', render: function (g) { return esc(g.display_name); } },
        { label: 'Subject ID', render: function (g) { return '<span class="mono">' + esc(g.id) + '</span>'; } },
        { label: 'Status', render: function (g) { return badge(g.status); } },
        { label: '', cls: 'actions', render: function (g) { return '<a class="btn" href="#/assignments?subject_type=group&subject_id=' + g.id + '">Assignments</a> <button class="btn" data-assign="' + g.id + '">Assign role</button>'; } }
      ], r.items, 'No groups mirrored yet.') + '</div>');
    }, fail);
    $m.on('submit', '#search', function (e) { e.preventDefault(); location.hash = '#/groups?q=' + encodeURIComponent($(this).find('[name=q]').val()); });
    $m.on('click', '[data-assign]', function () { var id = $(this).data('assign'); Promise.all([loadRoles(), loadServices()]).then(function () { newAssignment({ subject_type: 'group', subject_id: id }); }); });
  }

  function viewGroup(id) {
    var $m = $('#main');
    Promise.all([get('/groups?limit=1000'), get('/groups/' + id + '/members?limit=1000')]).then(function (res) {
      var g = res[0].items.filter(function (x) { return x.id === id; })[0] || { external_id: id };
      $m.html(head(g.display_name || g.external_id, badge(g.status || 'unknown') + ' · <span class="mono">' + esc(g.id || id) + '</span>',
        '<a class="btn" href="#/assignments?subject_type=group&subject_id=' + id + '">Assignments</a>', '<a href="#/groups">Groups</a> / ' + esc(g.external_id)));
      $m.append('<div class="card flush">' + table([
        { label: 'Employee ID', render: function (u) { return '<span class="mono">' + esc(u.external_id) + '</span>'; } },
        { label: 'Name', render: function (u) { return esc(u.display_name); } },
        { label: 'Status', render: function (u) { return badge(u.status); } }
      ], res[1].items, 'No members within the user base DN.') + '</div>');
    }, fail);
  }

  function viewSync() {
    var $m = $('#main').html(head('LDAP Sync', 'Full mirror every interval. A round is published only when it completes successfully.', '<button class="btn primary" id="run">Sync now</button>'));
    get('/sync/ldap/status').then(function (s) {
      var sum = s.last_summary || {};
      $m.append('<div class="grid-3">' +
        '<div class="card stat"><span class="muted">Mirror</span><b>' + (s.stale ? badge('stale', 'danger') : badge('fresh', 'ok')) + '</b><span class="muted">User checks return 503 while stale (max ' + esc(s.max_staleness) + ')</span></div>' +
        '<div class="card stat"><span class="muted">Last successful sync</span><b style="font-size:16px">' + fmtTime(s.last_success_started_at) + '</b><span class="muted">interval ' + esc(s.interval) + '</span></div>' +
        '<div class="card stat"><span class="muted">Last attempt</span><b style="font-size:16px">' + fmtTime(s.last_attempt_at) + '</b>' + (s.running ? badge('running', 'accent') : (s.last_error ? badge('failed', 'danger') : badge('ok', 'ok'))) + '</div></div>' +
        (s.last_error ? '<div class="card" style="border-color:#f3c9c6"><h3>Last error</h3><div class="mono">' + esc(s.last_error) + '</div></div>' : '') +
        '<div class="card"><h3>Last successful round</h3><dl class="kv">' +
        '<dt>Users</dt><dd>' + esc(sum.users != null ? sum.users : '—') + (sum.disabled_users ? ' <span class="muted">(' + sum.disabled_users + ' disabled)</span>' : '') + '</dd>' +
        '<dt>Groups</dt><dd>' + esc(sum.groups != null ? sum.groups : '—') + '</dd>' +
        '<dt>Memberships</dt><dd>' + esc(sum.memberships != null ? sum.memberships : '—') + (sum.dangling_members ? ' <span class="muted">(' + sum.dangling_members + ' dangling references ignored)</span>' : '') + '</dd>' +
        '<dt>Status changes</dt><dd>' + esc(sum.changes ? sum.changes.length : '—') + '</dd>' +
        '<dt>Duration</dt><dd>' + esc(sum.duration_ms != null ? sum.duration_ms + ' ms' : '—') + '</dd></dl></div>');
    }, fail);
    $m.on('click', '#run', function () {
      var $b = $(this).prop('disabled', true).text('Syncing…');
      post('/sync/ldap/run').then(function () { toast('Sync completed', 'ok'); viewSync(); }, function (e) { fail(e); $b.prop('disabled', false).text('Sync now'); });
    });
  }

  // ---- Check access -----------------------------------------------------

  // viewCheck simulates POST /check as an administrator, for any service, using
  // either ULIDs or business identifiers. Query params pre-fill the form.
  function viewCheck() {
    var f = q();
    var $m = $('#main').html(head('Check Access', 'Ask the same question a business service would: may this subject perform this action on this resource?'));
    Promise.all([loadServices(), loadRoles()]).then(function (res) {
      var services = res[0].filter(function (s) { return s.status !== 'deleted'; });
      var opts = services.map(function (s) { return '<option value="' + s.id + '"' + (s.id === f.service_id ? ' selected' : '') + '>' + esc(s.service_key) + (s.status !== 'active' ? ' (inactive)' : '') + '</option>'; }).join('');
      $m.append('<div class="grid-2"><div class="card"><form id="chk">' +
        '<label>Service<select name="service_id" required>' + opts + '</select></label>' +
        '<label>Subject type<select name="subject_type"><option value="user"' + (f.subject_type === 'service_account' ? '' : ' selected') + '>User</option><option value="service_account"' + (f.subject_type === 'service_account' ? ' selected' : '') + '>Service account</option></select></label>' +
        '<label>Subject<input name="subject" required value="' + esc(f.subject || '') + '" placeholder="employee ID, service account external ID or subject ULID"><span class="hint">Employee ID for users; external ID within the service for service accounts. A 26-char ULID is used as-is.</span></label>' +
        '<label>Resource<input name="resource" required value="' + esc(f.resource || '') + '" placeholder="external ID or resource ULID"><span class="hint">Business identifier registered under the service, or its ULID. Use <code>authzie:root</code> for actions without an object.</span></label>' +
        '<label>Action<input name="action" required list="actions" value="' + esc(f.action || '') + '" placeholder="issue_edit"><datalist id="actions"></datalist></label>' +
        '<div class="form-actions"><button type="submit" class="btn primary">Check</button></div></form></div>' +
        '<div id="result" class="card"><div class="empty">The decision appears here.</div></div></div>');
      var $form = $('#chk');
      function loadActions() {
        var sid = $form.find('[name=service_id]').val();
        if (!sid) return;
        Promise.all([get('/services/' + sid + '/resource-types?limit=1000'), get('/services/' + sid + '/permissions?limit=1000')]).then(function (r) {
          var t = {};
          r[0].items.forEach(function (x) { t[x.id] = x.type_key; });
          var seen = {};
          $('#actions').html(r[1].items.filter(function (p) { if (seen[p.action]) return false; seen[p.action] = true; return true; })
            .map(function (p) { return '<option value="' + esc(p.action) + '">' + esc((t[p.resource_type_id] || '?') + '.' + p.action) + '</option>'; }).join(''));
        }, function () {});
      }
      $form.on('change', '[name=service_id]', loadActions);
      loadActions();
      $form.on('submit', function (e) {
        e.preventDefault();
        var v = {};
        $form.serializeArray().forEach(function (x) { v[x.name] = x.value.trim(); });
        var body = { service_id: v.service_id, subject_type: v.subject_type, action: v.action };
        body[/^[0-9A-Z]{26}$/.test(v.subject) ? 'subject_id' : 'subject_external_id'] = v.subject;
        body[/^[0-9A-Z]{26}$/.test(v.resource) ? 'resource_id' : 'resource_external_id'] = v.resource;
        var $btn = $form.find('[type=submit]').prop('disabled', true);
        $('#result').html('<div class="empty">Checking…</div>');
        post('/admin/check', body).then(function (d) { renderDecision(d, v); }, function (err) {
          $('#result').html('<div class="decision deny"><b>' + esc(err.status === 503 ? 'UNAVAILABLE' : 'ERROR') + '</b><span class="mono">' + esc(err.error_code || '') + '</span></div><p class="muted">' + esc(err.message || '') + '</p>' +
            (err.status === 404 ? '<p class="muted">A business service would receive <code>allowed:false</code> here — the subject or resource is not known to Authzie.</p>' : ''));
        }).finally(function () { $btn.prop('disabled', false); });
        history.replaceState(null, '', '#/check?' + Object.keys(v).map(function (k) { return k + '=' + encodeURIComponent(v[k]); }).join('&'));
      });
      function renderDecision(d, v) {
        var svc = state.services[v.service_id] || {};
        var subj = d.subject || {}, r = d.resource || {};
        var h = '<div class="decision ' + (d.allowed ? 'allow' : 'deny') + '"><b>' + (d.allowed ? 'ALLOW' : 'DENY') + '</b><span class="mono">' + esc(d.reason) + '</span></div>';
        h += '<dl class="kv"><dt>Subject</dt><dd>' + badge(subj.type ? subj.type.replace('_', ' ') : v.subject_type, 'neutral') + ' ' + (subj.external_id ? esc(subj.display_name || subj.external_id) + ' <span class="mono muted">' + esc(subj.external_id) + '</span>' : '<span class="mono">' + esc(subj.id || '') + '</span>') + (subj.status ? ' ' + badge(subj.status) : '') + '</dd>' +
          '<dt>Resource</dt><dd><span class="mono">' + esc(svc.service_key || '') + '</span> / ' + (r.external_id ? esc(r.display_name || r.external_id) + ' <span class="mono muted">' + esc(r.external_id) + '</span>' : '<span class="mono">' + esc(r.id || '') + '</span>') + (r.status ? ' ' + badge(r.status) : '') + '</dd>' +
          '<dt>Action</dt><dd class="mono">' + esc(v.action) + '</dd><dt>Policy version</dt><dd>' + esc(d.policy_version) + '</dd></dl>';
        var m = d.matched_assignment;
        if (m) {
          var role = state.roles[m.role_id];
          var via = m.subject_type === 'group' ? 'via group membership' : 'direct assignment';
          var scope = m.scope_type === 'tenant' ? 'tenant' : m.scope_type === 'service' ? 'service' : 'resource' + (m.include_descendants ? ' + descendants' : ' only');
          h += '<h3>Granted by</h3><p>' + badge(m.subject_type.replace('_', ' '), 'neutral') + ' <span class="mono" id="granted-subject">' + esc(m.subject_id) + '</span> <span class="muted">(' + via + ')</span><br>Role ' + (role ? '<a href="#/roles/' + role.id + '" class="mono">' + esc(role.name) + '</a>' : shortId(m.role_id)) + ' · scope ' + badge(scope, 'accent') + ' · <a href="#/assignments?subject_type=' + m.subject_type + '&subject_id=' + m.subject_id + '">view assignments</a></p>';
          if (m.subject_type === 'group') {
            get('/groups?limit=1000').then(function (g) {
              var grp = g.items.filter(function (x) { return x.id === m.subject_id; })[0];
              if (grp) $('#granted-subject').html('<a href="#/groups/' + grp.id + '">' + esc(grp.display_name || grp.external_id) + '</a>');
            }, function () {});
          }
        } else if (!d.allowed) {
          var hints = {
            permission_not_granted: 'No active assignment grants a role containing this permission for this subject (or its groups) at a scope covering the resource.',
            permission_not_found: 'The action is not defined as a permission on this resource’s type. Add it under the service’s Permissions tab.',
            subject_not_found: 'The subject is unknown to Authzie.',
            subject_inactive: 'The subject is disabled or was removed from LDAP.',
            resource_not_found: 'The resource does not belong to this service.',
            resource_inactive: 'The resource or its service is disabled.'
          };
          h += '<p class="muted">' + esc(hints[d.reason] || '') + '</p>';
          if (subj.id) h += '<p><a href="#/assignments?subject_type=' + esc(subj.type) + '&subject_id=' + esc(subj.id) + '">View this subject’s assignments</a></p>';
        }
        $('#result').html(h);
      }
      if (f.subject && f.resource && f.action) $form.trigger('submit');
    }, fail);
  }

  // ---- Audit ------------------------------------------------------------

  function viewAudit() {
    var f = q();
    var $m = $('#main').html(head('Audit Log', 'Every configuration change, LDAP round and administrator login.',
      '<form id="filter" class="toolbar"><input class="inline" name="object_type" placeholder="object type" value="' + esc(f.object_type || '') + '">' +
      '<input class="inline" name="object_id" placeholder="object id" value="' + esc(f.object_id || '') + '">' +
      '<input class="inline" name="actor_id" placeholder="actor" value="' + esc(f.actor_id || '') + '"><button class="btn">Filter</button></form>'));
    var qs = Object.keys(f).filter(function (k) { return f[k]; }).map(function (k) { return k + '=' + encodeURIComponent(f[k]); }).join('&');
    get('/audit-logs?limit=200' + (qs ? '&' + qs : '')).then(function (r) {
      $m.append('<div class="card flush">' + table([
        { label: 'Time', render: function (a) { return fmtTime(a.created_at); } },
        { label: 'Actor', render: function (a) { return badge(a.actor_type, 'neutral') + ' <span class="mono">' + esc(a.actor_id) + '</span>'; } },
        { label: 'Action', render: function (a) { return '<span class="mono">' + esc(a.action) + '</span>'; } },
        { label: 'Object', render: function (a) { return esc(a.object_type) + ' ' + shortId(a.object_id); } },
        { label: 'Change', render: function (a) { return '<details><summary class="muted" style="cursor:pointer">before / after</summary><pre class="mono" style="white-space:pre-wrap;max-width:520px">' + esc(JSON.stringify({ before: a.before, after: a.after }, null, 1)) + '</pre></details>'; } },
        { label: 'Request', render: function (a) { return shortId(a.request_id); } }
      ], r.items, 'No audit entries match.') + '</div>');
    }, fail);
    $m.on('submit', '#filter', function (e) {
      e.preventDefault();
      var p = $(this).serializeArray().filter(function (x) { return x.value; }).map(function (x) { return x.name + '=' + encodeURIComponent(x.value); }).join('&');
      location.hash = '#/audit' + (p ? '?' + p : '');
    });
  }

  // ---- Auth & boot ------------------------------------------------------

  function showLogin() {
    state.me = null;
    $('#app').addClass('hidden');
    $('#login').removeClass('hidden');
    $('#login-form [name=uid]').trigger('focus');
  }
  function showApp(me) {
    state.me = me;
    $('#me').text(me.uid);
    $('#login').addClass('hidden');
    $('#app').removeClass('hidden');
    route();
  }

  $('#login-form').on('submit', function (e) {
    e.preventDefault();
    var $f = $(this), $btn = $f.find('[type=submit]').prop('disabled', true);
    $('#login-error').text('');
    post('/admin/login', { uid: $f.find('[name=uid]').val().trim(), password: $f.find('[name=password]').val() }).then(function (me) {
      $f.find('[name=password]').val('');
      showApp(me);
    }, function (err) {
      var msg = err.status === 403 ? 'This account is not an Authzie administrator.' : err.status === 401 ? 'Invalid employee ID or password.' : err.status === 503 ? 'LDAP directory is unreachable.' : err.message;
      $('#login-error').text(msg);
    }).finally(function () { $btn.prop('disabled', false); });
  });
  $('#logout').on('click', function () { post('/admin/logout').finally(showLogin); });
  $('#modal').on('click', '[data-close]', closeModal).on('click', function (e) { if (e.target === this) closeModal(); });
  $(document).on('keydown', function (e) { if (e.key === 'Escape') closeModal(); });
  $(window).on('hashchange', function () { $('#main').off(); route(); });

  get('/admin/me').then(showApp, showLogin);
})(jQuery);
