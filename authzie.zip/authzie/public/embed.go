// Package public embeds the administration UI.
package public

import (
	"embed"
	"io/fs"
	"net/http"
)

//go:embed index.html app.js style.css logo.svg vendor/*
var files embed.FS

// FS returns the UI as an http.FileSystem.
func FS() http.FileSystem {
	sub, err := fs.Sub(files, ".")
	if err != nil {
		panic(err)
	}
	return http.FS(sub)
}
