// Package ldapsync mirrors users and groups from LDAP and authenticates administrators.
package ldapsync

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"fmt"
	"net"
	"net/url"
	"os"
	"strings"

	"github.com/go-ldap/ldap/v3"

	"github.com/tongjie/authzie/internal/config"
)

var (
	ErrInvalidCredentials = errors.New("invalid_credentials")
	ErrUnavailable        = errors.New("ldap_unavailable")
)

// Client opens short-lived LDAP connections using the configured transport settings.
type Client struct {
	cfg config.LDAPConfig
	tls *tls.Config
}

func NewClient(cfg config.LDAPConfig) (*Client, error) {
	u, err := url.Parse(cfg.URL)
	if err != nil || (u.Scheme != "ldap" && u.Scheme != "ldaps") {
		return nil, fmt.Errorf("AUTHZIE_LDAP_URL must be ldap:// or ldaps://")
	}
	tc := &tls.Config{ServerName: u.Hostname(), InsecureSkipVerify: cfg.InsecureSkipVerify, MinVersion: tls.VersionTLS12} //nolint:gosec
	if cfg.CAFile != "" {
		pem, err := os.ReadFile(cfg.CAFile)
		if err != nil {
			return nil, fmt.Errorf("read AUTHZIE_LDAP_CA_FILE: %w", err)
		}
		pool := x509.NewCertPool()
		if !pool.AppendCertsFromPEM(pem) {
			return nil, fmt.Errorf("AUTHZIE_LDAP_CA_FILE contains no certificates")
		}
		tc.RootCAs = pool
	}
	return &Client{cfg: cfg, tls: tc}, nil
}

// connect dials and performs the configured read-only bind (or anonymous if none).
func (c *Client) connect(_ context.Context) (*ldap.Conn, error) {
	conn, err := ldap.DialURL(c.cfg.URL, ldap.DialWithTLSConfig(c.tls), ldap.DialWithDialer(&net.Dialer{Timeout: c.cfg.Timeout}))
	if err != nil {
		return nil, fmt.Errorf("%w: %v", ErrUnavailable, err)
	}
	conn.SetTimeout(c.cfg.Timeout)
	if c.cfg.StartTLS && !strings.HasPrefix(c.cfg.URL, "ldaps://") {
		if err := conn.StartTLS(c.tls); err != nil {
			conn.Close()
			return nil, fmt.Errorf("%w: starttls: %v", ErrUnavailable, err)
		}
	}
	if c.cfg.BindDN != "" {
		if err := conn.Bind(c.cfg.BindDN, c.cfg.BindPassword); err != nil {
			conn.Close()
			return nil, fmt.Errorf("%w: service bind: %v", ErrUnavailable, err)
		}
	}
	return conn, nil
}

// Authenticate finds the user by ID attribute and verifies the password with a bind.
// It returns the canonical ID attribute value on success.
func (c *Client) Authenticate(ctx context.Context, uid, password string) (string, error) {
	if uid == "" || password == "" {
		return "", ErrInvalidCredentials
	}
	conn, err := c.connect(ctx)
	if err != nil {
		return "", err
	}
	defer conn.Close()

	filter := fmt.Sprintf("(&%s(%s=%s))", c.cfg.UserFilter, c.cfg.UserIDAttr, ldap.EscapeFilter(uid))
	res, err := conn.Search(ldap.NewSearchRequest(c.cfg.UserBaseDN, ldap.ScopeWholeSubtree, ldap.NeverDerefAliases,
		2, 0, false, filter, []string{c.cfg.UserIDAttr}, nil))
	if err != nil {
		return "", fmt.Errorf("%w: search: %v", ErrUnavailable, err)
	}
	if len(res.Entries) != 1 {
		return "", ErrInvalidCredentials
	}
	entry := res.Entries[0]
	if err := conn.Bind(entry.DN, password); err != nil {
		if ldap.IsErrorWithCode(err, ldap.LDAPResultInvalidCredentials) {
			return "", ErrInvalidCredentials
		}
		return "", fmt.Errorf("%w: bind: %v", ErrUnavailable, err)
	}
	return entry.GetAttributeValue(c.cfg.UserIDAttr), nil
}

// normDN lowercases a DN for comparison. LDAP DNs are case-insensitive in practice.
func normDN(dn string) string {
	parsed, err := ldap.ParseDN(dn)
	if err != nil {
		return strings.ToLower(strings.TrimSpace(dn))
	}
	return strings.ToLower(parsed.String())
}
