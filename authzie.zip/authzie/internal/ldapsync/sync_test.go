package ldapsync

import (
	"context"
	"log/slog"
	"os"
	"regexp"
	"testing"
	"time"

	"github.com/tongjie/authzie/internal/config"
	"github.com/tongjie/authzie/internal/policy"
	"github.com/tongjie/authzie/internal/store"
	"github.com/tongjie/authzie/internal/testutil"
)

func TestShrankTooMuch(t *testing.T) {
	cases := []struct {
		prev, cur int
		ratio     float64
		want      bool
	}{
		{0, 0, 0.5, false}, {0, 10, 0.5, false}, {100, 50, 0.5, false}, {100, 49, 0.5, true},
		{100, 100, 0, false}, {100, 99, 0, true}, {100, 0, 1, false}, {10, 9, 0.5, false},
	}
	for _, c := range cases {
		if got := shrankTooMuch(c.prev, c.cur, c.ratio); got != c.want {
			t.Errorf("shrankTooMuch(%d,%d,%v)=%v want %v", c.prev, c.cur, c.ratio, got, c.want)
		}
	}
}

func TestNormDN(t *testing.T) {
	a := normDN("UID=45020897, CN=Users,DC=lab,DC=local")
	b := normDN("uid=45020897,cn=users,dc=lab,dc=local")
	if a != b {
		t.Fatalf("DNs should normalize equal: %q vs %q", a, b)
	}
}

// labConfig mirrors docs/dev-1.0.0.md §4.1. Requires AUTHZIE_TEST_LDAP_URL.
func labConfig(t *testing.T) config.LDAPConfig {
	url := os.Getenv("AUTHZIE_TEST_LDAP_URL")
	if url == "" {
		t.Skip("AUTHZIE_TEST_LDAP_URL not set; skipping LDAP integration test")
	}
	return config.LDAPConfig{
		URL: url, Timeout: 10 * time.Second, PageSize: 500,
		UserBaseDN: "cn=users,dc=lab,dc=local", UserFilter: "(objectClass=inetOrgPerson)", UserIDAttr: "uid", UserNameAttr: "displayName",
		UserDisabledAttr: "sambaAcctFlags", UserDisabledRegex: regexp.MustCompile(`\[.*D.*\]`),
		GroupBaseDN: "cn=groups,dc=lab,dc=local", GroupFilter: "(objectClass=posixGroup)", GroupIDAttr: "cn", GroupNameAttr: "cn", GroupMemberAttr: "member",
		SyncInterval: time.Minute, MaxStaleness: 30 * time.Minute, MaxShrinkRatio: 0.5,
	}
}

func TestLabDirectorySync(t *testing.T) {
	cfg := labConfig(t)
	pool := testutil.OpenSchema(t)
	log := slog.New(slog.NewTextHandler(os.Stderr, nil))
	engine := policy.NewEngine(pool, log, cfg.MaxStaleness)
	if err := engine.Rebuild(context.Background()); err != nil {
		t.Fatal(err)
	}
	client, err := NewClient(cfg)
	if err != nil {
		t.Fatal(err)
	}
	syncer := NewSyncer(cfg, client, engine, log)
	ctx := context.Background()
	if err := syncer.Run(ctx); err != nil {
		t.Fatalf("sync: %v", err)
	}
	if engine.LDAPStale() {
		t.Fatal("mirror should be fresh after a successful sync")
	}
	adminUser, err := store.GetUserByExternalID(ctx, pool, "45020897")
	if err != nil {
		t.Fatalf("admin user not mirrored: %v", err)
	}
	if _, err := store.GetUserByExternalID(ctx, pool, "12345678"); err != nil {
		t.Fatalf("regular user not mirrored: %v", err)
	}
	groups, err := store.ListGroups(ctx, pool, "jira-dev", store.Page{})
	if err != nil || len(groups) != 1 {
		t.Fatalf("jira-dev group not mirrored: %v %d", err, len(groups))
	}
	members, err := store.ListGroupMembers(ctx, pool, groups[0].ID, store.Page{})
	if err != nil {
		t.Fatal(err)
	}
	found := false
	for _, m := range members {
		if m.ID == adminUser.ID {
			found = true
		}
	}
	if !found {
		t.Fatalf("admin should be a member of jira-dev, members=%d", len(members))
	}
	st, err := syncer.Status(ctx)
	if err != nil || st.LastSuccessStartedAt == nil || st.LastError != "" {
		t.Fatalf("status: %v %+v", err, st)
	}

	// second run is idempotent: no changes recorded
	if err := syncer.Run(ctx); err != nil {
		t.Fatal(err)
	}
	logs, err := store.ListAudit(ctx, pool, store.AuditFilter{ObjectType: "ldap_mirror"}, store.Page{})
	if err != nil || len(logs) != 2 {
		t.Fatalf("expected 2 ldap audit rows, got %d (%v)", len(logs), err)
	}
	if sum, ok := logs[0].After.(map[string]any); !ok || len(sum["changes"].([]any)) != 0 {
		t.Fatalf("second sync should record no changes: %v", logs[0].After)
	}
}

func TestLabAuthenticate(t *testing.T) {
	cfg := labConfig(t)
	client, err := NewClient(cfg)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := client.Authenticate(context.Background(), "45020897", "definitely-wrong-password"); err != ErrInvalidCredentials {
		t.Fatalf("expected invalid credentials, got %v", err)
	}
	if _, err := client.Authenticate(context.Background(), "nobody-here", "x"); err != ErrInvalidCredentials {
		t.Fatalf("unknown user should be invalid credentials, got %v", err)
	}
	if pw := os.Getenv("AUTHZIE_TEST_LDAP_ADMIN_PASSWORD"); pw != "" {
		uid, err := client.Authenticate(context.Background(), "45020897", pw)
		if err != nil || uid != "45020897" {
			t.Fatalf("admin bind failed: %v %q", err, uid)
		}
	}
}
