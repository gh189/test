package ldapsync

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"strings"
	"sync"
	"time"

	"github.com/go-ldap/ldap/v3"

	"github.com/tongjie/authzie/internal/config"
	"github.com/tongjie/authzie/internal/id"
	"github.com/tongjie/authzie/internal/policy"
	"github.com/tongjie/authzie/internal/store"
)

var ErrSyncInProgress = errors.New("sync_in_progress")

// Summary is the per-round audit record.
type Summary struct {
	StartedAt       time.Time            `json:"started_at"`
	DurationMS      int64                `json:"duration_ms"`
	Users           int                  `json:"users"`
	DisabledUsers   int                  `json:"disabled_users"`
	Groups          int                  `json:"groups"`
	Memberships     int                  `json:"memberships"`
	DanglingMembers int                  `json:"dangling_members"`
	Changes         []store.MirrorChange `json:"changes"`
}

// Status is returned by GET /sync/ldap/status.
type Status struct {
	Running              bool       `json:"running"`
	Stale                bool       `json:"stale"`
	LastSuccessStartedAt *time.Time `json:"last_success_started_at"`
	LastAttemptAt        *time.Time `json:"last_attempt_at"`
	LastError            string     `json:"last_error"`
	LastSummary          any        `json:"last_summary"`
	MaxStaleness         string     `json:"max_staleness"`
	Interval             string     `json:"interval"`
}

// Syncer runs the periodic full mirror.
type Syncer struct {
	cfg    config.LDAPConfig
	client *Client
	engine *policy.Engine
	log    *slog.Logger

	mu      sync.Mutex
	running bool
}

func NewSyncer(cfg config.LDAPConfig, client *Client, engine *policy.Engine, log *slog.Logger) *Syncer {
	return &Syncer{cfg: cfg, client: client, engine: engine, log: log}
}

// Start runs one sync immediately and then on every interval until ctx is done.
func (s *Syncer) Start(ctx context.Context) {
	go func() {
		s.runLogged(ctx)
		t := time.NewTicker(s.cfg.SyncInterval)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
				s.runLogged(ctx)
			}
		}
	}()
}

func (s *Syncer) runLogged(ctx context.Context) {
	if err := s.Run(ctx); err != nil && !errors.Is(err, ErrSyncInProgress) {
		s.log.Error("ldap sync failed", "error", err)
	}
}

// Status reports current sync state.
func (s *Syncer) Status(ctx context.Context) (*Status, error) {
	st, err := store.GetLDAPSyncState(ctx, s.engine.DB())
	if err != nil {
		return nil, err
	}
	s.mu.Lock()
	running := s.running
	s.mu.Unlock()
	return &Status{
		Running: running, Stale: s.engine.LDAPStale(),
		LastSuccessStartedAt: st.LastSuccessStartedAt, LastAttemptAt: st.LastAttemptAt,
		LastError: st.LastError, LastSummary: st.LastSummary,
		MaxStaleness: s.cfg.MaxStaleness.String(), Interval: s.cfg.SyncInterval.String(),
	}, nil
}

// Run performs one full synchronization. Only one run may be active at a time.
func (s *Syncer) Run(ctx context.Context) error {
	s.mu.Lock()
	if s.running {
		s.mu.Unlock()
		return ErrSyncInProgress
	}
	s.running = true
	s.mu.Unlock()
	defer func() {
		s.mu.Lock()
		s.running = false
		s.mu.Unlock()
	}()

	startedAt := time.Now()
	sum, err := s.runOnce(ctx, startedAt)
	if err != nil {
		if rerr := store.RecordLDAPFailure(ctx, s.engine.DB(), startedAt, err.Error()); rerr != nil {
			s.log.Error("record ldap failure", "error", rerr)
		}
		return err
	}
	s.log.Info("ldap sync completed", "users", sum.Users, "groups", sum.Groups,
		"memberships", sum.Memberships, "dangling", sum.DanglingMembers, "changes", len(sum.Changes), "duration_ms", sum.DurationMS)
	return nil
}

func (s *Syncer) runOnce(ctx context.Context, startedAt time.Time) (*Summary, error) {
	users, groups, sum, err := s.fetch(ctx)
	if err != nil {
		return nil, err
	}
	prev, err := store.CountActiveUsers(ctx, s.engine.DB())
	if err != nil {
		return nil, err
	}
	if shrankTooMuch(prev, len(users), s.cfg.MaxShrinkRatio) {
		return nil, fmt.Errorf("result set shrank from %d to %d users, exceeding AUTHZIE_LDAP_MAX_SHRINK_RATIO; keeping previous mirror", prev, len(users))
	}

	sum.StartedAt = startedAt
	_, err = s.engine.Write(ctx, policy.Actor{Type: "system", ID: "ldap-sync"}, "", func(w *policy.Writer) error {
		changes, err := store.ApplyMirror(ctx, w.Tx, users, groups, id.New)
		if err != nil {
			return err
		}
		if changes == nil {
			changes = []store.MirrorChange{}
		}
		sum.Changes = changes
		sum.DurationMS = time.Since(startedAt).Milliseconds()
		if err := store.RecordLDAPSuccess(ctx, w.Tx, startedAt, sum); err != nil {
			return err
		}
		return w.Audit("ldap.sync", "ldap_mirror", "ldap", nil, sum)
	})
	if err != nil {
		return nil, err
	}
	return sum, nil
}

// fetch reads users and groups, validating required attributes and uniqueness.
func (s *Syncer) fetch(ctx context.Context) ([]store.MirrorUser, []store.MirrorGroup, *Summary, error) {
	conn, err := s.client.connect(ctx)
	if err != nil {
		return nil, nil, nil, err
	}
	defer conn.Close()
	c := s.cfg
	sum := &Summary{}

	userAttrs := []string{c.UserIDAttr, c.UserNameAttr}
	if c.UserDisabledAttr != "" {
		userAttrs = append(userAttrs, c.UserDisabledAttr)
	}
	ures, err := conn.SearchWithPaging(ldap.NewSearchRequest(c.UserBaseDN, ldap.ScopeWholeSubtree, ldap.NeverDerefAliases,
		0, 0, false, c.UserFilter, userAttrs, nil), c.PageSize)
	if err != nil {
		return nil, nil, nil, fmt.Errorf("%w: user search: %v", ErrUnavailable, err)
	}
	users := make([]store.MirrorUser, 0, len(ures.Entries))
	seen := map[string]bool{}
	dnToID := map[string]string{}
	for _, e := range ures.Entries {
		uid := strings.TrimSpace(e.GetAttributeValue(c.UserIDAttr))
		if uid == "" {
			return nil, nil, nil, fmt.Errorf("user %s lacks required attribute %s", e.DN, c.UserIDAttr)
		}
		if seen[uid] {
			return nil, nil, nil, fmt.Errorf("duplicate user id %q in LDAP", uid)
		}
		seen[uid] = true
		name := e.GetAttributeValue(c.UserNameAttr)
		if name == "" {
			name = uid
		}
		disabled := false
		if c.UserDisabledAttr != "" && c.UserDisabledRegex != nil {
			for _, v := range e.GetAttributeValues(c.UserDisabledAttr) {
				if c.UserDisabledRegex.MatchString(v) {
					disabled = true
					break
				}
			}
		}
		if disabled {
			sum.DisabledUsers++
		}
		users = append(users, store.MirrorUser{ExternalID: uid, DN: e.DN, DisplayName: name, Disabled: disabled})
		dnToID[normDN(e.DN)] = uid
	}
	sum.Users = len(users)

	gres, err := conn.SearchWithPaging(ldap.NewSearchRequest(c.GroupBaseDN, ldap.ScopeWholeSubtree, ldap.NeverDerefAliases,
		0, 0, false, c.GroupFilter, []string{c.GroupIDAttr, c.GroupNameAttr, c.GroupMemberAttr}, nil), c.PageSize)
	if err != nil {
		return nil, nil, nil, fmt.Errorf("%w: group search: %v", ErrUnavailable, err)
	}
	groups := make([]store.MirrorGroup, 0, len(gres.Entries))
	gseen := map[string]bool{}
	for _, e := range gres.Entries {
		gid := strings.TrimSpace(e.GetAttributeValue(c.GroupIDAttr))
		if gid == "" {
			return nil, nil, nil, fmt.Errorf("group %s lacks required attribute %s", e.DN, c.GroupIDAttr)
		}
		if gseen[gid] {
			return nil, nil, nil, fmt.Errorf("duplicate group id %q in LDAP", gid)
		}
		gseen[gid] = true
		name := e.GetAttributeValue(c.GroupNameAttr)
		if name == "" {
			name = gid
		}
		g := store.MirrorGroup{ExternalID: gid, DN: e.DN, DisplayName: name}
		for _, m := range e.GetAttributeValues(c.GroupMemberAttr) {
			if uid, ok := dnToID[normDN(m)]; ok {
				g.MemberIDs = append(g.MemberIDs, uid)
				sum.Memberships++
			} else {
				sum.DanglingMembers++
			}
		}
		groups = append(groups, g)
	}
	sum.Groups = len(groups)
	return users, groups, sum, nil
}

// shrankTooMuch reports whether the user count dropped by more than ratio since the last mirror.
func shrankTooMuch(prev, cur int, ratio float64) bool {
	return prev > 0 && float64(cur) < float64(prev)*(1-ratio)
}
