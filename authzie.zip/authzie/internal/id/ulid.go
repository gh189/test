// Package id generates and validates ULID identifiers.
package id

import (
	"crypto/rand"
	"sync"
	"time"

	"github.com/oklog/ulid/v2"
)

var (
	mu      sync.Mutex
	entropy = ulid.Monotonic(rand.Reader, 0)
)

// New returns a new lowercase-insensitive ULID string.
func New() string {
	mu.Lock()
	defer mu.Unlock()
	return ulid.MustNew(ulid.Timestamp(time.Now()), entropy).String()
}

// Valid reports whether s is a well-formed ULID.
func Valid(s string) bool {
	_, err := ulid.ParseStrict(s)
	return err == nil
}
