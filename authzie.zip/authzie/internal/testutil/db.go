// Package testutil provides an isolated PostgreSQL schema per integration test.
package testutil

import (
	"context"
	"fmt"
	"os"
	"strings"
	"testing"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/tongjie/authzie/internal/db"
	"github.com/tongjie/authzie/internal/id"
)

// OpenSchema returns a pool whose search_path points at a fresh schema. The schema is
// dropped when the test finishes. Tests are skipped when AUTHZIE_TEST_DATABASE_URL is unset.
func OpenSchema(t testing.TB) *pgxpool.Pool {
	t.Helper()
	dsn := os.Getenv("AUTHZIE_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("AUTHZIE_TEST_DATABASE_URL not set; skipping integration test")
	}
	ctx := context.Background()
	schema := "t_" + strings.ToLower(id.New())

	cfg, err := pgxpool.ParseConfig(dsn)
	if err != nil {
		t.Fatalf("parse dsn: %v", err)
	}
	cfg.AfterConnect = func(ctx context.Context, conn *pgx.Conn) error {
		_, err := conn.Exec(ctx, fmt.Sprintf(`SET search_path TO %s`, schema))
		return err
	}
	admin, err := pgxpool.New(ctx, dsn)
	if err != nil {
		t.Fatalf("connect: %v", err)
	}
	if _, err := admin.Exec(ctx, fmt.Sprintf(`CREATE SCHEMA %s`, schema)); err != nil {
		t.Fatalf("create schema: %v", err)
	}
	pool, err := pgxpool.NewWithConfig(ctx, cfg)
	if err != nil {
		t.Fatalf("connect schema pool: %v", err)
	}
	if _, err := pool.Exec(ctx, db.Schema); err != nil {
		t.Fatalf("apply schema: %v", err)
	}
	t.Cleanup(func() {
		pool.Close()
		_, _ = admin.Exec(ctx, fmt.Sprintf(`DROP SCHEMA %s CASCADE`, schema))
		admin.Close()
	})
	return pool
}
