// Package db opens the PostgreSQL pool and applies the embedded schema.
package db

import (
	"context"
	_ "embed"
	"fmt"
	"regexp"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

//go:embed schema.sql
var Schema string

var schemaName = regexp.MustCompile(`^[a-z_][a-z0-9_]{0,62}$`)

// Open connects to PostgreSQL, pins every connection's search_path to schema and applies
// the embedded DDL idempotently. Non-default schemas are created if missing; "public"
// always exists, so it is only used (the database user needs CREATE on it).
func Open(ctx context.Context, dsn, schema string) (*pgxpool.Pool, error) {
	if !schemaName.MatchString(schema) {
		return nil, fmt.Errorf("invalid schema name %q", schema)
	}
	cfg, err := pgxpool.ParseConfig(dsn)
	if err != nil {
		return nil, fmt.Errorf("parse AUTHZIE_DATABASE_URL: %w", err)
	}
	cfg.AfterConnect = func(ctx context.Context, conn *pgx.Conn) error {
		_, err := conn.Exec(ctx, "SET search_path TO "+schema)
		return err
	}
	if schema != "public" {
		// Bootstrap with a plain connection so the schema exists before AfterConnect runs.
		boot, err := pgx.ConnectConfig(ctx, cfg.ConnConfig)
		if err != nil {
			return nil, fmt.Errorf("connect database: %w", err)
		}
		_, err = boot.Exec(ctx, "CREATE SCHEMA IF NOT EXISTS "+schema)
		boot.Close(ctx)
		if err != nil {
			return nil, fmt.Errorf("create schema %s: %w", schema, err)
		}
	}

	pool, err := pgxpool.NewWithConfig(ctx, cfg)
	if err != nil {
		return nil, fmt.Errorf("open database: %w", err)
	}
	if _, err := pool.Exec(ctx, Schema); err != nil {
		pool.Close()
		return nil, fmt.Errorf("apply schema in %q (the database user needs CREATE on it, e.g. GRANT ALL ON SCHEMA %s TO <user>): %w", schema, schema, err)
	}
	return pool, nil
}
