-- Authzie 1.0.0 schema. Applied idempotently at startup.

CREATE TABLE IF NOT EXISTS services (
    id            TEXT PRIMARY KEY,
    service_key   TEXT NOT NULL,
    display_name  TEXT NOT NULL DEFAULT '',
    description   TEXT NOT NULL DEFAULT '',
    status        TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','deleted')),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS services_key_live ON services (service_key) WHERE status <> 'deleted';

CREATE TABLE IF NOT EXISTS resource_types (
    id            TEXT PRIMARY KEY,
    service_id    TEXT NOT NULL REFERENCES services(id) ON DELETE CASCADE,
    type_key      TEXT NOT NULL,
    display_name  TEXT NOT NULL DEFAULT '',
    description   TEXT NOT NULL DEFAULT '',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (service_id, type_key)
);

CREATE TABLE IF NOT EXISTS permissions (
    id               TEXT PRIMARY KEY,
    service_id       TEXT NOT NULL REFERENCES services(id) ON DELETE CASCADE,
    resource_type_id TEXT NOT NULL REFERENCES resource_types(id) ON DELETE RESTRICT,
    action           TEXT NOT NULL,
    description      TEXT NOT NULL DEFAULT '',
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (service_id, resource_type_id, action)
);

CREATE TABLE IF NOT EXISTS resources (
    id               TEXT PRIMARY KEY,
    service_id       TEXT NOT NULL REFERENCES services(id) ON DELETE CASCADE,
    resource_type_id TEXT NOT NULL REFERENCES resource_types(id) ON DELETE RESTRICT,
    parent_id        TEXT REFERENCES resources(id) ON DELETE RESTRICT,
    external_id      TEXT NOT NULL,
    external_key     TEXT,
    display_name     TEXT NOT NULL DEFAULT '',
    description      TEXT NOT NULL DEFAULT '',
    status           TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','deleted')),
    depth            INT  NOT NULL DEFAULT 0,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    -- external_id is permanently unique per service, even after deletion.
    UNIQUE (service_id, external_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS resources_ext_key_live
    ON resources (service_id, resource_type_id, external_key)
    WHERE status <> 'deleted' AND external_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS resources_parent ON resources (parent_id);

CREATE TABLE IF NOT EXISTS roles (
    id            TEXT PRIMARY KEY,
    name          TEXT NOT NULL,
    display_name  TEXT NOT NULL DEFAULT '',
    description   TEXT NOT NULL DEFAULT '',
    status        TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','deleted')),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS roles_name_live ON roles (name) WHERE status <> 'deleted';

CREATE TABLE IF NOT EXISTS role_permissions (
    role_id       TEXT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id TEXT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

-- LDAP mirror. external_id is permanent so the same employee ID always maps to the same internal ID.
CREATE TABLE IF NOT EXISTS users (
    id            TEXT PRIMARY KEY,
    external_id   TEXT NOT NULL UNIQUE,
    dn            TEXT NOT NULL DEFAULT '',
    display_name  TEXT NOT NULL DEFAULT '',
    status        TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
    present       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS groups (
    id            TEXT PRIMARY KEY,
    external_id   TEXT NOT NULL UNIQUE,
    dn            TEXT NOT NULL DEFAULT '',
    display_name  TEXT NOT NULL DEFAULT '',
    status        TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS group_members (
    group_id TEXT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
    user_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    PRIMARY KEY (group_id, user_id)
);

CREATE TABLE IF NOT EXISTS service_accounts (
    id            TEXT PRIMARY KEY,
    service_id    TEXT NOT NULL REFERENCES services(id) ON DELETE CASCADE,
    external_id   TEXT NOT NULL,
    display_name  TEXT NOT NULL DEFAULT '',
    description   TEXT NOT NULL DEFAULT '',
    status        TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','deleted')),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS service_accounts_ext_live
    ON service_accounts (service_id, external_id) WHERE status <> 'deleted';

CREATE TABLE IF NOT EXISTS credentials (
    id            TEXT PRIMARY KEY,
    service_id    TEXT NOT NULL REFERENCES services(id) ON DELETE CASCADE,
    name          TEXT NOT NULL DEFAULT '',
    secret_hash   BYTEA NOT NULL,
    scopes        TEXT[] NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    revoked_at    TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS assignments (
    id                  TEXT PRIMARY KEY,
    subject_type        TEXT NOT NULL CHECK (subject_type IN ('user','group','service_account')),
    subject_id          TEXT NOT NULL,
    role_id             TEXT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    scope_type          TEXT NOT NULL CHECK (scope_type IN ('tenant','service','resource')),
    -- Scope-irrelevant fields are normalized to '' / FALSE so the unique index never relies on NULL.
    service_id          TEXT NOT NULL DEFAULT '',
    resource_id         TEXT NOT NULL DEFAULT '',
    include_descendants BOOLEAN NOT NULL DEFAULT FALSE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (subject_type, subject_id, role_id, scope_type, service_id, resource_id, include_descendants)
);
CREATE INDEX IF NOT EXISTS assignments_subject ON assignments (subject_type, subject_id);

CREATE TABLE IF NOT EXISTS audit_logs (
    id           TEXT PRIMARY KEY,
    actor_type   TEXT NOT NULL,
    actor_id     TEXT NOT NULL,
    action       TEXT NOT NULL,
    object_type  TEXT NOT NULL,
    object_id    TEXT NOT NULL,
    before       JSONB,
    after        JSONB,
    request_id   TEXT NOT NULL DEFAULT '',
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS audit_logs_created ON audit_logs (created_at DESC);
CREATE INDEX IF NOT EXISTS audit_logs_object ON audit_logs (object_type, object_id);

-- Single-row tables for policy revision and LDAP sync state.
CREATE TABLE IF NOT EXISTS policy_state (
    id       INT PRIMARY KEY CHECK (id = 1),
    revision BIGINT NOT NULL DEFAULT 0
);
INSERT INTO policy_state (id, revision) VALUES (1, 0) ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS ldap_sync_state (
    id                      INT PRIMARY KEY CHECK (id = 1),
    last_success_started_at TIMESTAMPTZ,
    last_attempt_at         TIMESTAMPTZ,
    last_error              TEXT NOT NULL DEFAULT '',
    last_summary            JSONB
);
INSERT INTO ldap_sync_state (id) VALUES (1) ON CONFLICT DO NOTHING;
