// Package config loads Authzie settings from AUTHZIE_* environment variables.
package config

import (
	"fmt"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"
)

const Version = "1.0.0"

// Config holds all runtime settings. Only environment variables are supported.
type Config struct {
	ListenAddr     string
	DatabaseURL    string
	DatabaseSchema string
	LogLevel       string
	SessionTTL     time.Duration

	LDAP LDAPConfig
}

// LDAPConfig describes the read-only LDAP mirror and admin bind settings.
type LDAPConfig struct {
	URL                string
	StartTLS           bool
	CAFile             string
	InsecureSkipVerify bool
	BindDN             string
	BindPassword       string
	Timeout            time.Duration
	PageSize           uint32

	UserBaseDN        string
	UserFilter        string
	UserIDAttr        string
	UserNameAttr      string
	UserDisabledAttr  string
	UserDisabledRegex *regexp.Regexp

	GroupBaseDN     string
	GroupFilter     string
	GroupIDAttr     string
	GroupNameAttr   string
	GroupMemberAttr string

	SyncInterval   time.Duration
	MaxStaleness   time.Duration
	MaxShrinkRatio float64
}

// Load reads configuration from the environment and validates required values.
func Load() (*Config, error) {
	var errs []string
	get := func(key, def string) string {
		if v, ok := os.LookupEnv("AUTHZIE_" + key); ok {
			return v
		}
		return def
	}
	required := func(key string) string {
		v := get(key, "")
		if strings.TrimSpace(v) == "" {
			errs = append(errs, "AUTHZIE_"+key+" is required")
		}
		return v
	}
	duration := func(key string, def time.Duration) time.Duration {
		v := get(key, "")
		if v == "" {
			return def
		}
		d, err := time.ParseDuration(v)
		if err != nil {
			errs = append(errs, "AUTHZIE_"+key+": invalid duration")
		}
		return d
	}
	boolean := func(key string, def bool) bool {
		v := get(key, "")
		if v == "" {
			return def
		}
		b, err := strconv.ParseBool(v)
		if err != nil {
			errs = append(errs, "AUTHZIE_"+key+": invalid boolean")
		}
		return b
	}

	c := &Config{
		ListenAddr:     get("LISTEN_ADDR", "127.0.0.1:8080"),
		DatabaseURL:    required("DATABASE_URL"),
		DatabaseSchema: get("DATABASE_SCHEMA", "public"),
		LogLevel:       get("LOG_LEVEL", "info"),
		SessionTTL:     duration("SESSION_TTL", 12*time.Hour),
	}
	l := &c.LDAP
	l.URL = required("LDAP_URL")
	l.StartTLS = boolean("LDAP_START_TLS", false)
	l.CAFile = get("LDAP_CA_FILE", "")
	l.InsecureSkipVerify = boolean("LDAP_INSECURE_SKIP_VERIFY", false)
	l.BindDN = get("LDAP_BIND_DN", "")
	l.BindPassword = get("LDAP_BIND_PASSWORD", "")
	l.Timeout = duration("LDAP_TIMEOUT", 10*time.Second)
	if ps, err := strconv.ParseUint(get("LDAP_PAGE_SIZE", "500"), 10, 32); err != nil || ps == 0 {
		errs = append(errs, "AUTHZIE_LDAP_PAGE_SIZE: invalid positive integer")
	} else {
		l.PageSize = uint32(ps)
	}

	l.UserBaseDN = required("LDAP_USER_BASE_DN")
	l.UserFilter = get("LDAP_USER_FILTER", "(objectClass=inetOrgPerson)")
	l.UserIDAttr = get("LDAP_USER_ID_ATTR", "uid")
	l.UserNameAttr = get("LDAP_USER_NAME_ATTR", "displayName")
	l.UserDisabledAttr = get("LDAP_USER_DISABLED_ATTR", "")
	if re := get("LDAP_USER_DISABLED_REGEX", ""); re != "" {
		r, err := regexp.Compile(re)
		if err != nil {
			errs = append(errs, "AUTHZIE_LDAP_USER_DISABLED_REGEX: "+err.Error())
		}
		l.UserDisabledRegex = r
	}

	l.GroupBaseDN = required("LDAP_GROUP_BASE_DN")
	l.GroupFilter = get("LDAP_GROUP_FILTER", "(objectClass=groupOfNames)")
	l.GroupIDAttr = get("LDAP_GROUP_ID_ATTR", "cn")
	l.GroupNameAttr = get("LDAP_GROUP_NAME_ATTR", "cn")
	l.GroupMemberAttr = get("LDAP_GROUP_MEMBER_ATTR", "member")

	l.SyncInterval = duration("LDAP_SYNC_INTERVAL", 60*time.Second)
	l.MaxStaleness = duration("LDAP_MAX_STALENESS", 30*time.Minute)
	if f, err := strconv.ParseFloat(get("LDAP_MAX_SHRINK_RATIO", "0.5"), 64); err != nil || f < 0 || f > 1 {
		errs = append(errs, "AUTHZIE_LDAP_MAX_SHRINK_RATIO: must be between 0 and 1")
	} else {
		l.MaxShrinkRatio = f
	}

	if len(errs) > 0 {
		return nil, fmt.Errorf("invalid configuration:\n  %s", strings.Join(errs, "\n  "))
	}
	return c, nil
}
