package policy

import (
	"context"
	"fmt"
	"log/slog"
	"sync"
	"sync/atomic"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/tongjie/authzie/internal/id"
	"github.com/tongjie/authzie/internal/store"
)

// Actor identifies who performs a write, for audit purposes.
type Actor struct {
	Type string // admin | credential | system
	ID   string
}

// Writer is passed to write callbacks to record audit entries in the same transaction.
type Writer struct {
	Tx        pgx.Tx
	actor     Actor
	requestID string
	ctx       context.Context
}

// Audit records one configuration change. Never pass credential secrets or hashes.
func (w *Writer) Audit(action, objectType, objectID string, before, after any) error {
	return store.InsertAudit(w.ctx, w.Tx, &store.AuditLog{
		ID: id.New(), ActorType: w.actor.Type, ActorID: w.actor.ID, Action: action,
		ObjectType: objectType, ObjectID: objectID, Before: before, After: after, RequestID: w.requestID,
	})
}

// Engine owns the current snapshot and serializes all policy writes behind one lock.
type Engine struct {
	pool         *pgxpool.Pool
	log          *slog.Logger
	maxStaleness time.Duration
	now          func() time.Time

	writeMu  sync.Mutex
	snap     atomic.Pointer[Snapshot]
	notReady atomic.Bool
	retryMu  sync.Mutex
	retrying bool
}

// NewEngine creates an engine without a snapshot; call Rebuild or Start.
func NewEngine(pool *pgxpool.Pool, log *slog.Logger, maxStaleness time.Duration) *Engine {
	e := &Engine{pool: pool, log: log, maxStaleness: maxStaleness, now: time.Now}
	e.notReady.Store(true)
	return e
}

// Ready reports whether a snapshot is published and no rebuild failure is outstanding.
func (e *Engine) Ready() bool { return !e.notReady.Load() && e.snap.Load() != nil }

// Revision returns the published policy version (0 when none).
func (e *Engine) Revision() int64 {
	if s := e.snap.Load(); s != nil {
		return s.Revision
	}
	return 0
}

// LDAPStale reports whether the user mirror is too old to trust.
func (e *Engine) LDAPStale() bool {
	s := e.snap.Load()
	if s == nil || s.LDAPSyncedAt == nil {
		return true
	}
	return e.now().Sub(*s.LDAPSyncedAt) > e.maxStaleness
}

// Check answers an authorization request. Errors map to 5xx; a Decision maps to 200.
func (e *Engine) Check(_ context.Context, req Request) (Decision, error) {
	s := e.snap.Load()
	if e.notReady.Load() || s == nil {
		return Decision{}, ErrNotReady
	}
	if req.SubjectType == store.SubjectUser && (s.LDAPSyncedAt == nil || e.now().Sub(*s.LDAPSyncedAt) > e.maxStaleness) {
		return Decision{}, ErrLDAPStale
	}
	return s.Check(req)
}

// Rebuild loads a fresh snapshot from the database and publishes it atomically.
func (e *Engine) Rebuild(ctx context.Context) error {
	e.writeMu.Lock()
	defer e.writeMu.Unlock()
	return e.rebuild(ctx)
}

// rebuild is called under writeMu, including by writes and background recovery.
func (e *Engine) rebuild(ctx context.Context) error {
	err := e.load(ctx)
	if err != nil {
		e.notReady.Store(true)
		e.scheduleRetry()
		return fmt.Errorf("load policy: %w", err)
	}
	e.notReady.Store(false)
	return nil
}

func (e *Engine) load(ctx context.Context) error {
	adapter, err := openAdapter(ctx, e.pool)
	if err != nil {
		return err
	}
	defer adapter.Close()
	tx, err := e.pool.BeginTx(ctx, pgx.TxOptions{IsoLevel: pgx.RepeatableRead, AccessMode: pgx.ReadOnly})
	if err != nil {
		return err
	}
	defer tx.Rollback(context.Background()) //nolint:errcheck
	d, err := store.LoadDump(ctx, tx)
	if err != nil {
		return err
	}
	if err := tx.Commit(ctx); err != nil {
		return err
	}
	s, err := build(d, adapter)
	if err != nil {
		return err
	}
	e.snap.Store(s)
	return nil
}

func (e *Engine) scheduleRetry() {
	e.retryMu.Lock()
	defer e.retryMu.Unlock()
	if e.retrying {
		return
	}
	e.retrying = true
	go func() {
		for {
			time.Sleep(5 * time.Second)
			e.writeMu.Lock()
			err := e.rebuild(context.Background())
			e.writeMu.Unlock()
			if err == nil {
				e.retryMu.Lock()
				e.retrying = false
				e.retryMu.Unlock()
				e.log.Info("policy snapshot rebuilt after retry")
				return
			}
			e.log.Error("policy snapshot rebuild retry failed", "error", err)
		}
	}()
}

// Write runs fn inside a transaction under the global write lock, bumps the revision,
// commits, then rebuilds and publishes the snapshot. It returns the new policy version.
func (e *Engine) Write(ctx context.Context, actor Actor, requestID string, fn func(w *Writer) error) (int64, error) {
	e.writeMu.Lock()
	defer e.writeMu.Unlock()

	tx, err := e.pool.Begin(ctx)
	if err != nil {
		return 0, err
	}
	defer tx.Rollback(context.Background()) //nolint:errcheck

	w := &Writer{Tx: tx, actor: actor, requestID: requestID, ctx: ctx}
	if err := fn(w); err != nil {
		return 0, err
	}
	rev, err := store.BumpRevision(ctx, tx)
	if err != nil {
		return 0, err
	}
	if err := tx.Commit(ctx); err != nil {
		return 0, err
	}
	if err := e.rebuild(context.Background()); err != nil {
		e.log.Error("policy snapshot rebuild failed; serving 503 until recovered", "error", err)
	}
	return rev, nil
}

// Read runs fn with the pool for read-only queries outside the write lock.
func (e *Engine) DB() store.Q { return e.pool }

// Ctx returns the transaction's context.
func (w *Writer) Ctx() context.Context { return w.ctx }
