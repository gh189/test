package policy

import (
	"testing"
	"time"

	"github.com/tongjie/authzie/internal/store"
)

// fixture builds a small tenant:
//
//	service jira (active) with types project, issue-less; permission project.issue_edit
//	resources: root -> projA -> compA ; root -> projB
//	service wiki (active) with root and permission space.page_edit
//	users: alice(active), bob(inactive); groups: dev(active, alice), qa(inactive, alice)
//	service account: bot (jira)
//	role editor: {issue_edit}; role viewer: {} ; role disabledRole (inactive) {issue_edit}
type fixture struct {
	d *store.Dump
}

func ptr(s string) *string { return &s }

func newFixture() *fixture {
	now := time.Now()
	d := &store.Dump{Revision: 7, LDAPSyncedAt: &now}
	d.Services = []store.Service{{ID: "jira", ServiceKey: "jira", Status: "active"}, {ID: "wiki", ServiceKey: "wiki", Status: "active"}}
	d.Permissions = []store.Permission{
		{ID: "p_edit", ServiceID: "jira", ResourceTypeID: "rt_proj", Action: "issue_edit"},
		{ID: "p_view", ServiceID: "jira", ResourceTypeID: "rt_proj", Action: "issue_view"},
		{ID: "p_comp", ServiceID: "jira", ResourceTypeID: "rt_comp", Action: "issue_edit"},
		{ID: "p_create", ServiceID: "jira", ResourceTypeID: "rt_root", Action: "project_create"},
		{ID: "w_edit", ServiceID: "wiki", ResourceTypeID: "wt_space", Action: "page_edit"},
	}
	d.Resources = []store.Resource{
		{ID: "root", ServiceID: "jira", ResourceTypeID: "rt_root", ExternalID: "authzie:root", Status: "active"},
		{ID: "projA", ServiceID: "jira", ResourceTypeID: "rt_proj", ParentID: ptr("root"), Status: "active"},
		{ID: "compA", ServiceID: "jira", ResourceTypeID: "rt_comp", ParentID: ptr("projA"), Status: "active"},
		{ID: "projB", ServiceID: "jira", ResourceTypeID: "rt_proj", ParentID: ptr("root"), Status: "active"},
		{ID: "wroot", ServiceID: "wiki", ResourceTypeID: "wt_root", ExternalID: "authzie:root", Status: "active"},
		{ID: "space", ServiceID: "wiki", ResourceTypeID: "wt_space", ParentID: ptr("wroot"), Status: "active"},
	}
	d.Roles = []store.Role{
		{ID: "editor", Name: "editor", Status: "active"}, {ID: "viewer", Name: "viewer", Status: "active"},
		{ID: "off", Name: "off", Status: "inactive"}, {ID: "compeditor", Name: "compeditor", Status: "active"},
	}
	d.RolePermissions = []store.RolePermission{
		{RoleID: "editor", PermissionID: "p_edit"}, {RoleID: "editor", PermissionID: "w_edit"},
		{RoleID: "viewer", PermissionID: "p_view"}, {RoleID: "off", PermissionID: "p_edit"},
		{RoleID: "compeditor", PermissionID: "p_comp"},
	}
	d.Users = []store.User{{ID: "alice", ExternalID: "1", Status: "active"}, {ID: "bob", ExternalID: "2", Status: "inactive"}}
	d.Groups = []store.Group{{ID: "dev", Status: "active"}, {ID: "qa", Status: "inactive"}}
	d.GroupMembers = []store.GroupMember{{GroupID: "dev", UserID: "alice"}, {GroupID: "qa", UserID: "alice"}}
	d.ServiceAccounts = []store.ServiceAccount{{ID: "bot", ServiceID: "jira", Status: "active"}}
	return &fixture{d: d}
}

func (f *fixture) assign(subjType, subj, role, scope, svc, res string, desc bool) {
	f.d.Assignments = append(f.d.Assignments, store.Assignment{
		ID: subj + role + scope + res, SubjectType: subjType, SubjectID: subj, RoleID: role,
		ScopeType: scope, ServiceID: svc, ResourceID: res, IncludeDescendants: desc,
	})
}

func (f *fixture) setStatus(kind, id, status string) {
	switch kind {
	case "service":
		for i := range f.d.Services {
			if f.d.Services[i].ID == id {
				f.d.Services[i].Status = status
			}
		}
	case "resource":
		for i := range f.d.Resources {
			if f.d.Resources[i].ID == id {
				f.d.Resources[i].Status = status
			}
		}
	case "role":
		for i := range f.d.Roles {
			if f.d.Roles[i].ID == id {
				f.d.Roles[i].Status = status
			}
		}
	case "user":
		for i := range f.d.Users {
			if f.d.Users[i].ID == id {
				f.d.Users[i].Status = status
			}
		}
	case "group":
		for i := range f.d.Groups {
			if f.d.Groups[i].ID == id {
				f.d.Groups[i].Status = status
			}
		}
	case "service_account":
		for i := range f.d.ServiceAccounts {
			if f.d.ServiceAccounts[i].ID == id {
				f.d.ServiceAccounts[i].Status = status
			}
		}
	}
}

func req(subjType, subj, res, action string) Request {
	return Request{ServiceID: "jira", SubjectType: subjType, SubjectID: subj, ResourceID: res, Action: action}
}

func expect(t *testing.T, s *Snapshot, r Request, allowed bool, reason string) {
	t.Helper()
	d, err := s.Check(r)
	if err != nil {
		t.Fatal(err)
	}
	if d.Allowed != allowed || d.Reason != reason {
		t.Fatalf("%+v: got allowed=%v reason=%s, want allowed=%v reason=%s", r, d.Allowed, d.Reason, allowed, reason)
	}
	if d.PolicyVersion != 7 {
		t.Fatalf("policy_version = %d, want 7", d.PolicyVersion)
	}
}

func mustBuild(t *testing.T, d *store.Dump) *Snapshot {
	t.Helper()
	s, err := build(d, nil)
	if err != nil {
		t.Fatal(err)
	}
	return s
}

func TestDefaultDeny(t *testing.T) {
	f := newFixture()
	s := mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "projA", "issue_edit"), false, ReasonPermissionNotGranted)
	expect(t, s, req("service_account", "bot", "projA", "issue_edit"), false, ReasonPermissionNotGranted)
}

func TestPreChecks(t *testing.T) {
	f := newFixture()
	f.assign("user", "alice", "editor", "tenant", "", "", false)
	s := mustBuild(t, f.d)

	expect(t, s, req("user", "nobody", "projA", "issue_edit"), false, ReasonSubjectNotFound)
	expect(t, s, req("group", "dev", "projA", "issue_edit"), false, ReasonSubjectNotFound) // groups cannot check
	expect(t, s, req("user", "bob", "projA", "issue_edit"), false, ReasonSubjectInactive)
	expect(t, s, req("user", "alice", "missing", "issue_edit"), false, ReasonResourceNotFound)
	expect(t, s, req("user", "alice", "space", "page_edit"), false, ReasonResourceNotFound) // other service's resource
	expect(t, s, req("user", "alice", "projA", "nope"), false, ReasonPermissionNotFound)
	expect(t, s, req("user", "alice", "compA", "issue_view"), false, ReasonPermissionNotFound) // action on wrong type

	f.setStatus("resource", "projA", "inactive")
	s = mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "projA", "issue_edit"), false, ReasonResourceInactive)
}

func TestScopes(t *testing.T) {
	// tenant scope covers everything, including another service.
	f := newFixture()
	f.assign("user", "alice", "editor", "tenant", "", "", false)
	s := mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "projA", "issue_edit"), true, ReasonGranted)
	expect(t, s, req("user", "alice", "projB", "issue_edit"), true, ReasonGranted)
	wiki := Request{ServiceID: "wiki", SubjectType: "user", SubjectID: "alice", ResourceID: "space", Action: "page_edit"}
	expect(t, s, wiki, true, ReasonGranted)

	// service scope isolates services.
	f = newFixture()
	f.assign("user", "alice", "editor", "service", "jira", "", false)
	s = mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "projB", "issue_edit"), true, ReasonGranted)
	expect(t, s, wiki, false, ReasonPermissionNotGranted)

	// resource scope without descendants: exact match only.
	f = newFixture()
	f.assign("user", "alice", "editor", "resource", "", "projA", false)
	f.assign("user", "alice", "compeditor", "resource", "", "projA", false)
	s = mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "projA", "issue_edit"), true, ReasonGranted)
	expect(t, s, req("user", "alice", "compA", "issue_edit"), false, ReasonPermissionNotGranted)
	expect(t, s, req("user", "alice", "projB", "issue_edit"), false, ReasonPermissionNotGranted)

	// resource scope with descendants.
	f = newFixture()
	f.assign("user", "alice", "compeditor", "resource", "", "projA", true)
	f.assign("user", "alice", "editor", "resource", "", "root", true)
	s = mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "compA", "issue_edit"), true, ReasonGranted)
	expect(t, s, req("user", "alice", "projB", "issue_edit"), true, ReasonGranted)
}

func TestGroupsMerge(t *testing.T) {
	f := newFixture()
	f.assign("group", "dev", "viewer", "service", "jira", "", false)
	f.assign("user", "alice", "editor", "resource", "", "projA", false)
	s := mustBuild(t, f.d)
	// direct + group assignments are merged
	expect(t, s, req("user", "alice", "projA", "issue_edit"), true, ReasonGranted)
	expect(t, s, req("user", "alice", "projB", "issue_view"), true, ReasonGranted)
	expect(t, s, req("user", "alice", "projB", "issue_edit"), false, ReasonPermissionNotGranted)

	// inactive group grants nothing
	f = newFixture()
	f.assign("group", "qa", "editor", "tenant", "", "", false)
	s = mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "projA", "issue_edit"), false, ReasonPermissionNotGranted)

	// removed from group -> deny
	f = newFixture()
	f.assign("group", "dev", "editor", "tenant", "", "", false)
	f.d.GroupMembers = nil
	s = mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "projA", "issue_edit"), false, ReasonPermissionNotGranted)
}

func TestInactiveObjectsSuspend(t *testing.T) {
	f := newFixture()
	f.assign("user", "alice", "off", "tenant", "", "", false)
	s := mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "projA", "issue_edit"), false, ReasonPermissionNotGranted)
	f.setStatus("role", "off", "active")
	s = mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "projA", "issue_edit"), true, ReasonGranted)

	// role without the permission
	f = newFixture()
	f.assign("user", "alice", "viewer", "tenant", "", "", false)
	s = mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "projA", "issue_edit"), false, ReasonPermissionNotGranted)

	// inactive service
	f = newFixture()
	f.assign("user", "alice", "editor", "tenant", "", "", false)
	f.setStatus("service", "jira", "inactive")
	s = mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "projA", "issue_edit"), false, ReasonResourceInactive)

	// inactive service account / its service
	f = newFixture()
	f.assign("service_account", "bot", "editor", "tenant", "", "", false)
	s = mustBuild(t, f.d)
	expect(t, s, req("service_account", "bot", "projA", "issue_edit"), true, ReasonGranted)
	f.setStatus("service_account", "bot", "inactive")
	s = mustBuild(t, f.d)
	expect(t, s, req("service_account", "bot", "projA", "issue_edit"), false, ReasonSubjectInactive)
}

func TestParentInactiveBlocksInheritanceOnly(t *testing.T) {
	f := newFixture()
	f.assign("user", "alice", "compeditor", "resource", "", "root", true)   // via projA (inactive)
	f.assign("user", "alice", "compeditor", "resource", "", "compA", false) // direct
	f.setStatus("resource", "projA", "inactive")
	s := mustBuild(t, f.d)
	// direct still allowed
	expect(t, s, req("user", "alice", "compA", "issue_edit"), true, ReasonGranted)

	f = newFixture()
	f.assign("user", "alice", "compeditor", "resource", "", "root", true)
	f.setStatus("resource", "projA", "inactive")
	s = mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "compA", "issue_edit"), false, ReasonPermissionNotGranted)

	// tenant/service scopes unaffected by the inactive parent
	f = newFixture()
	f.assign("user", "alice", "compeditor", "service", "jira", "", false)
	f.setStatus("resource", "projA", "inactive")
	s = mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "compA", "issue_edit"), true, ReasonGranted)

	// deleted parent (absent from snapshot) breaks the chain too
	f = newFixture()
	f.assign("user", "alice", "compeditor", "resource", "", "root", true)
	f.d.Resources = f.d.Resources[:1:1]
	f.d.Resources = append(f.d.Resources, store.Resource{ID: "compA", ServiceID: "jira", ResourceTypeID: "rt_comp", ParentID: ptr("projA"), Status: "active"})
	s = mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "compA", "issue_edit"), false, ReasonPermissionNotGranted)
}

func TestRootResourceActions(t *testing.T) {
	f := newFixture()
	f.d.Roles = append(f.d.Roles, store.Role{ID: "pm", Status: "active"})
	f.d.RolePermissions = append(f.d.RolePermissions, store.RolePermission{RoleID: "pm", PermissionID: "p_create"})
	f.assign("user", "alice", "pm", "service", "jira", "", false)
	s := mustBuild(t, f.d)
	expect(t, s, req("user", "alice", "root", "project_create"), true, ReasonGranted)
	expect(t, s, req("user", "alice", "projA", "project_create"), false, ReasonPermissionNotFound)
}

func TestEngineStalenessAndReadiness(t *testing.T) {
	e := NewEngine(nil, nil, 30*time.Minute)
	if _, err := e.Check(nil, req("user", "alice", "projA", "issue_edit")); err != ErrNotReady {
		t.Fatalf("expected ErrNotReady, got %v", err)
	}

	f := newFixture()
	f.assign("service_account", "bot", "editor", "tenant", "", "", false)
	f.assign("user", "alice", "editor", "tenant", "", "", false)
	old := time.Now().Add(-31 * time.Minute)
	f.d.LDAPSyncedAt = &old
	e.snap.Store(mustBuild(t, f.d))
	e.notReady.Store(false)

	if _, err := e.Check(nil, req("user", "alice", "projA", "issue_edit")); err != ErrLDAPStale {
		t.Fatalf("expected ErrLDAPStale, got %v", err)
	}
	d, err := e.Check(nil, req("service_account", "bot", "projA", "issue_edit"))
	if err != nil || !d.Allowed {
		t.Fatalf("service account should not be affected by staleness: %v %+v", err, d)
	}

	f.d.LDAPSyncedAt = nil
	e.snap.Store(mustBuild(t, f.d))
	if _, err := e.Check(nil, req("user", "alice", "projA", "issue_edit")); err != ErrLDAPStale {
		t.Fatalf("never synced should be stale, got %v", err)
	}

	fresh := time.Now()
	f.d.LDAPSyncedAt = &fresh
	e.snap.Store(mustBuild(t, f.d))
	if d, err := e.Check(nil, req("user", "alice", "projA", "issue_edit")); err != nil || !d.Allowed {
		t.Fatalf("fresh mirror should allow: %v %+v", err, d)
	}
}
