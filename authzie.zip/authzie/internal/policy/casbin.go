package policy

import (
	_ "embed"

	"github.com/casbin/casbin/v3"
	"github.com/casbin/casbin/v3/model"
	"github.com/casbin/casbin/v3/persist"
	defaultrolemanager "github.com/casbin/casbin/v3/rbac/default-role-manager"

	"github.com/tongjie/authzie/internal/store"
)

//go:embed model.conf
var modelText string

func subjectName(typ, id string) string { return typ + ":" + id }

// compilePolicy maps management records to Casbin relations. Scope inheritance is
// evaluated by g3, including the break at an inactive or deleted parent.
func compilePolicy(d *store.Dump, adapter persist.Adapter) (*casbin.Enforcer, error) {
	m, err := model.NewModelFromString(modelText)
	if err != nil {
		return nil, err
	}
	add := func(ptype string, values ...string) {
		if err == nil {
			err = m.AddPolicy(ptype[:1], ptype, values)
		}
	}
	groups := map[string]bool{}
	for _, group := range d.Groups {
		groups[group.ID] = group.Status == store.StatusActive
	}
	for _, member := range d.GroupMembers {
		if groups[member.GroupID] {
			add("g", subjectName(store.SubjectUser, member.UserID), subjectName(store.SubjectGroup, member.GroupID))
		}
	}
	roles := map[string]bool{}
	for _, role := range d.Roles {
		roles[role.ID] = role.Status == store.StatusActive
	}
	for _, permission := range d.RolePermissions {
		if roles[permission.RoleID] {
			add("g2", "role:"+permission.RoleID, "permission:"+permission.PermissionID)
		}
	}
	for _, service := range d.Services {
		if service.Status == store.StatusActive {
			add("g3", "service:"+service.ID, "tenant")
		}
	}
	resources := map[string]store.Resource{}
	for _, resource := range d.Resources {
		resources[resource.ID] = resource
	}
	for _, resource := range d.Resources {
		if resource.Status != store.StatusActive {
			continue
		}
		add("g3", "resource:"+resource.ID, "service:"+resource.ServiceID)
		add("g3", "resource:"+resource.ID, "tree:"+resource.ID)
		if resource.ParentID != nil {
			parent, ok := resources[*resource.ParentID]
			if ok && parent.Status == store.StatusActive && parent.ServiceID == resource.ServiceID {
				add("g3", "tree:"+resource.ID, "tree:"+parent.ID)
			}
		}
	}
	for _, assignment := range d.Assignments {
		var scope string
		switch assignment.ScopeType {
		case store.ScopeTenant:
			scope = "tenant"
		case store.ScopeService:
			scope = "service:" + assignment.ServiceID
		case store.ScopeResource:
			scope = "resource:" + assignment.ResourceID
			if assignment.IncludeDescendants {
				scope = "tree:" + assignment.ResourceID
			}
		default:
			continue
		}
		add("p", subjectName(assignment.SubjectType, assignment.SubjectID), "role:"+assignment.RoleID, scope, assignment.ID)
	}
	if err != nil {
		return nil, err
	}
	if adapter != nil {
		if err := adapter.SavePolicy(m); err != nil {
			return nil, err
		}
		m.ClearPolicy()
		if err := adapter.LoadPolicy(m); err != nil {
			return nil, err
		}
	}
	e, err := casbin.NewEnforcer(m)
	if err != nil {
		return nil, err
	}
	// Casbin's default depth is 10; Authzie supports deeper resource trees.
	e.SetNamedRoleManager("g3", defaultrolemanager.NewRoleManager(store.MaxDepth+2))
	if err := e.BuildRoleLinks(); err != nil {
		return nil, err
	}
	return e, nil
}
