// Package policy publishes immutable Casbin policies and authorization metadata.
package policy

import (
	"errors"
	"fmt"
	"time"

	"github.com/casbin/casbin/v3"
	"github.com/casbin/casbin/v3/persist"
	"github.com/tongjie/authzie/internal/store"
)

var (
	ErrNotReady  = errors.New("policy_not_ready")
	ErrLDAPStale = errors.New("ldap_mirror_stale")
)

// Deny reasons returned with HTTP 200.
const (
	ReasonGranted              = "permission_granted"
	ReasonSubjectNotFound      = "subject_not_found"
	ReasonSubjectInactive      = "subject_inactive"
	ReasonResourceNotFound     = "resource_not_found"
	ReasonResourceInactive     = "resource_inactive"
	ReasonPermissionNotFound   = "permission_not_found"
	ReasonPermissionNotGranted = "permission_not_granted"
)

// Request is a single authorization question. ServiceID is taken from the caller's credential.
type Request struct {
	ServiceID   string
	SubjectType string
	SubjectID   string
	ResourceID  string
	Action      string
}

// Decision is the answer to a Request.
type Decision struct {
	Allowed       bool   `json:"allowed"`
	Reason        string `json:"reason"`
	PolicyVersion int64  `json:"policy_version"`
	// MatchedAssignment is the first assignment that granted access (nil on deny).
	MatchedAssignment *store.Assignment `json:"matched_assignment,omitempty"`
}

type permKey struct {
	serviceID, typeID, action string
}

type resource struct {
	serviceID string
	typeID    string
	active    bool
}

type serviceAccount struct {
	serviceID string
	active    bool
}

// Snapshot is immutable once built.
type Snapshot struct {
	Revision        int64
	LDAPSyncedAt    *time.Time
	services        map[string]bool // id -> active
	permissions     map[permKey]string
	resources       map[string]*resource
	users           map[string]bool // id -> active
	serviceAccounts map[string]*serviceAccount
	assignments     map[string]store.Assignment // explanation metadata, keyed by assignment ID
	enforcer        *casbin.Enforcer
}

// build constructs a Casbin policy, optionally persists and reloads it through the adapter.
// Published enforcers are never mutated; checks require no database access.
func build(d *store.Dump, adapter persist.Adapter) (*Snapshot, error) {
	s := &Snapshot{
		Revision:        d.Revision,
		LDAPSyncedAt:    d.LDAPSyncedAt,
		services:        make(map[string]bool, len(d.Services)),
		permissions:     make(map[permKey]string, len(d.Permissions)),
		resources:       make(map[string]*resource, len(d.Resources)),
		users:           make(map[string]bool, len(d.Users)),
		serviceAccounts: make(map[string]*serviceAccount, len(d.ServiceAccounts)),
		assignments:     make(map[string]store.Assignment, len(d.Assignments)),
	}
	for _, v := range d.Services {
		s.services[v.ID] = v.Status == store.StatusActive
	}
	for _, v := range d.Permissions {
		s.permissions[permKey{v.ServiceID, v.ResourceTypeID, v.Action}] = v.ID
	}
	for _, v := range d.Resources {
		r := &resource{serviceID: v.ServiceID, typeID: v.ResourceTypeID, active: v.Status == store.StatusActive}
		s.resources[v.ID] = r
	}
	for _, v := range d.Users {
		s.users[v.ID] = v.Status == store.StatusActive
	}
	for _, v := range d.ServiceAccounts {
		s.serviceAccounts[v.ID] = &serviceAccount{serviceID: v.ServiceID, active: v.Status == store.StatusActive}
	}
	for _, a := range d.Assignments {
		s.assignments[a.ID] = a
	}
	var err error
	s.enforcer, err = compilePolicy(d, adapter)
	if err != nil {
		return nil, fmt.Errorf("build Casbin policy: %w", err)
	}
	return s, nil
}

// Check evaluates a request against the snapshot. Default deny, additive allow.
// LDAP staleness is evaluated by the caller (Engine) because it depends on wall-clock time.
func (s *Snapshot) Check(req Request) (Decision, error) {
	d := Decision{PolicyVersion: s.Revision}

	switch req.SubjectType {
	case store.SubjectUser:
		active, ok := s.users[req.SubjectID]
		if !ok {
			d.Reason = ReasonSubjectNotFound
			return d, nil
		}
		if !active {
			d.Reason = ReasonSubjectInactive
			return d, nil
		}
	case store.SubjectServiceAccount:
		sa, ok := s.serviceAccounts[req.SubjectID]
		if !ok {
			d.Reason = ReasonSubjectNotFound
			return d, nil
		}
		if !sa.active || !s.services[sa.serviceID] {
			d.Reason = ReasonSubjectInactive
			return d, nil
		}
	default:
		d.Reason = ReasonSubjectNotFound
		return d, nil
	}

	res, ok := s.resources[req.ResourceID]
	if !ok || res.serviceID != req.ServiceID {
		d.Reason = ReasonResourceNotFound
		return d, nil
	}
	if !res.active || !s.services[res.serviceID] {
		d.Reason = ReasonResourceInactive
		return d, nil
	}

	permID, ok := s.permissions[permKey{req.ServiceID, res.typeID, req.Action}]
	if !ok {
		d.Reason = ReasonPermissionNotFound
		return d, nil
	}

	allowed, rule, err := s.enforcer.EnforceEx(subjectName(req.SubjectType, req.SubjectID), "resource:"+req.ResourceID, "permission:"+permID)
	if err != nil {
		return Decision{}, fmt.Errorf("enforce Casbin policy: %w", err)
	}
	d.Reason = ReasonPermissionNotGranted
	if allowed {
		if len(rule) != 4 {
			return Decision{}, errors.New("Casbin returned an invalid assignment rule")
		}
		matched, ok := s.assignments[rule[3]]
		if !ok {
			return Decision{}, errors.New("Casbin returned an unknown assignment")
		}
		d.Allowed, d.Reason, d.MatchedAssignment = true, ReasonGranted, &matched
	}
	return d, nil
}
