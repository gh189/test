package policy

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"testing"

	"github.com/casbin/casbin/v3"
	"github.com/casbin/casbin/v3/model"
	"github.com/casbin/casbin/v3/persist"

	"github.com/tongjie/authzie/internal/store"
	"github.com/tongjie/authzie/internal/testutil"
)

func TestDeepResourceScope(t *testing.T) {
	f := newFixture()
	parent := "root"
	for depth := 1; depth < store.MaxDepth; depth++ {
		id := fmt.Sprintf("depth%d", depth)
		f.d.Resources = append(f.d.Resources, store.Resource{
			ID: id, ServiceID: "jira", ResourceTypeID: "rt_comp", ParentID: ptr(parent), Status: "active",
		})
		parent = id
	}
	f.assign("group", "dev", "compeditor", "resource", "", "root", true)
	s := mustBuild(t, f.d)
	r := req("user", "alice", parent, "issue_edit")
	expect(t, s, r, true, ReasonGranted)
	d, err := s.Check(r)
	if err != nil || d.MatchedAssignment == nil || d.MatchedAssignment.ID != f.d.Assignments[0].ID {
		t.Fatalf("missing group assignment explanation: %+v, %v", d, err)
	}
	f.setStatus("resource", "depth15", "inactive")
	expect(t, mustBuild(t, f.d), r, false, ReasonPermissionNotGranted)
	f.setStatus("resource", "depth15", "active")
	expect(t, mustBuild(t, f.d), r, true, ReasonGranted)
}

func TestConcurrentCasbinChecks(t *testing.T) {
	f := newFixture()
	f.assign("group", "dev", "editor", "resource", "", "projA", true)
	s := mustBuild(t, f.d)
	var wg sync.WaitGroup
	for range 16 {
		wg.Go(func() {
			for range 50 {
				for _, resource := range []string{"projA", "projB"} {
					d, err := s.Check(req("user", "alice", resource, "issue_edit"))
					if err != nil || d.Allowed != (resource == "projA") {
						t.Errorf("concurrent check: %+v, %v", d, err)
						return
					}
				}
			}
		})
	}
	wg.Wait()
}

type failingAdapter struct {
	persist.Adapter
	saveErr, loadErr error
}

func (a failingAdapter) SavePolicy(model.Model) error { return a.saveErr }
func (a failingAdapter) LoadPolicy(model.Model) error { return a.loadErr }

func TestAdapterErrorsPreventPublication(t *testing.T) {
	failure := errors.New("database unavailable")
	for _, adapter := range []failingAdapter{{saveErr: failure}, {loadErr: failure}} {
		if s, err := build(newFixture().d, adapter); s != nil || !errors.Is(err, failure) {
			t.Fatalf("adapter failure must reject the snapshot: %v, %v", s, err)
		}
	}
}

func TestPostgresCasbinPolicy(t *testing.T) {
	pool := testutil.OpenSchema(t)
	ctx := context.Background()
	adapter, err := openAdapter(ctx, pool)
	if err != nil {
		t.Fatal(err)
	}
	defer adapter.Close()
	f := newFixture()
	f.assign("group", "dev", "editor", "resource", "", "projA", true)
	s, err := build(f.d, adapter)
	if err != nil {
		t.Fatal(err)
	}
	expect(t, s, req("user", "alice", "projA", "issue_edit"), true, ReasonGranted)
	expect(t, s, req("user", "alice", "projB", "issue_edit"), false, ReasonPermissionNotGranted)
	var count int
	if err := pool.QueryRow(ctx, "SELECT count(*) FROM casbin_rule WHERE ptype='p'").Scan(&count); err != nil || count != 1 {
		t.Fatalf("policy must be persisted in the isolated Authzie schema: count=%d, %v", count, err)
	}
	// Load with a fresh adapter/enforcer: PostgreSQL alone restores the RBAC rules.
	restored, err := openAdapter(ctx, pool)
	if err != nil {
		t.Fatal(err)
	}
	defer restored.Close()
	checkRestored := func(want bool) {
		t.Helper()
		m, err := model.NewModelFromString(modelText)
		if err != nil {
			t.Fatal(err)
		}
		e, err := casbin.NewEnforcer(m, restored)
		if err != nil {
			t.Fatal(err)
		}
		allowed, err := e.Enforce("user:alice", "resource:projA", "permission:p_edit")
		if err != nil || allowed != want {
			t.Fatalf("restored policy: allowed=%v, want %v, %v", allowed, want, err)
		}
	}
	checkRestored(true)
	// A failed replacement must roll back the adapter's whole SavePolicy transaction.
	if _, err := pool.Exec(ctx, "ALTER TABLE casbin_rule ADD CONSTRAINT reject_policy CHECK (ptype <> 'p') NOT VALID"); err != nil {
		t.Fatal(err)
	}
	if _, err := build(f.d, adapter); err == nil {
		t.Fatal("expected policy persistence failure")
	}
	checkRestored(true)
	if _, err := pool.Exec(ctx, "ALTER TABLE casbin_rule DROP CONSTRAINT reject_policy"); err != nil {
		t.Fatal(err)
	}
	f.d.Assignments = nil
	if _, err := build(f.d, adapter); err != nil {
		t.Fatal(err)
	}
	checkRestored(false)
	if _, err := build(&store.Dump{}, adapter); err != nil {
		t.Fatal(err)
	}
	if err := pool.QueryRow(ctx, "SELECT count(*) FROM casbin_rule").Scan(&count); err != nil || count != 0 {
		t.Fatalf("empty policy must clear old rules: count=%d, %v", count, err)
	}
}
