package policy

import (
	"context"
	"net"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	pgadapter "github.com/apache/casbin-pg-adapter"
	"github.com/go-pg/pg/v10"
	"github.com/jackc/pgx/v5/pgxpool"
)

// openAdapter uses Authzie's existing database and schema. NewAdapter would
// create a separate database named "casbin", so use NewAdapterByDB instead.
// The caller closes the adapter after rebuilding; checks only use its loaded policy.
func openAdapter(ctx context.Context, pool *pgxpool.Pool) (*pgadapter.Adapter, error) {
	conn, err := pool.Acquire(ctx)
	if err != nil {
		return nil, err
	}
	defer conn.Release()
	var schema string
	if err := conn.QueryRow(ctx, "SELECT current_schema()").Scan(&schema); err != nil {
		return nil, err
	}
	cfg := conn.Conn().Config()
	opts := &pg.Options{
		Addr: net.JoinHostPort(cfg.Host, strconv.Itoa(int(cfg.Port))),
		User: cfg.User, Password: cfg.Password, Database: cfg.Database,
		TLSConfig: cfg.TLSConfig, DialTimeout: cfg.ConnectTimeout,
		ReadTimeout: 30 * time.Second, WriteTimeout: 30 * time.Second, PoolSize: 1,
		OnConnect: func(ctx context.Context, cn *pg.Conn) error {
			_, err := cn.ExecContext(ctx, "SET search_path TO ?", pg.Ident(schema))
			return err
		},
	}
	if strings.HasPrefix(cfg.Host, "/") {
		opts.Network = "unix"
		opts.Addr = filepath.Join(cfg.Host, ".s.PGSQL."+strconv.Itoa(int(cfg.Port)))
	}
	db := pg.Connect(opts).WithContext(ctx)
	adapter, err := pgadapter.NewAdapterByDB(db)
	if err != nil {
		db.Close()
		return nil, err
	}
	return adapter, nil
}
