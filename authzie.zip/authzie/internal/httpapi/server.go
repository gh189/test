// Package httpapi wires the Gin router, middleware and handlers.
package httpapi

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"

	"github.com/tongjie/authzie/internal/admin"
	"github.com/tongjie/authzie/internal/config"
	"github.com/tongjie/authzie/internal/id"
	"github.com/tongjie/authzie/internal/ldapsync"
	"github.com/tongjie/authzie/internal/policy"
	"github.com/tongjie/authzie/internal/store"
)

const (
	sessionCookie = "authzie_session"
	csrfHeader    = "X-Authzie-CSRF"

	ScopeCheck          = "decision:check"
	ScopeResourceRead   = "resource:read"
	ScopeResourceWrite  = "resource:write"
	ScopeSubjectResolve = "subject:resolve"
)

var validScopes = map[string]bool{ScopeCheck: true, ScopeResourceRead: true, ScopeResourceWrite: true, ScopeSubjectResolve: true}

// Authenticator verifies an administrator's LDAP credentials and returns the canonical uid.
type Authenticator interface {
	Authenticate(ctx context.Context, uid, password string) (string, error)
}

// SyncRunner exposes the LDAP mirror to the API.
type SyncRunner interface {
	Run(ctx context.Context) error
	Status(ctx context.Context) (*ldapsync.Status, error)
}

// Server bundles dependencies for handlers.
type Server struct {
	cfg      *config.Config
	engine   *policy.Engine
	syncer   SyncRunner
	ldap     Authenticator
	sessions *admin.Sessions
	log      *slog.Logger
	pinger   func(context.Context) error
	ui       http.FileSystem
}

// Options are the injectable dependencies of the HTTP server.
type Options struct {
	Config   *config.Config
	Engine   *policy.Engine
	Syncer   SyncRunner
	LDAP     Authenticator
	Sessions *admin.Sessions
	Logger   *slog.Logger
	Pinger   func(context.Context) error
	UI       http.FileSystem
}

// New builds the router.
func New(o Options) *gin.Engine {
	s := &Server{cfg: o.Config, engine: o.Engine, syncer: o.Syncer, ldap: o.LDAP, sessions: o.Sessions,
		log: o.Logger, pinger: o.Pinger, ui: o.UI}

	gin.SetMode(gin.ReleaseMode)
	r := gin.New()
	r.Use(s.requestID(), s.recovery(), s.logging())

	r.GET("/healthz", func(c *gin.Context) { c.JSON(200, gin.H{"status": "ok", "version": config.Version}) })
	r.GET("/readyz", s.readyz)

	if s.ui != nil {
		r.GET("/", func(c *gin.Context) { c.FileFromFS("/", s.ui) })
		r.StaticFS("/ui", s.ui)
	}

	api := r.Group("/api/v1", s.contentRules())

	// Administrator authentication.
	api.POST("/admin/login", s.adminLogin)
	api.POST("/admin/logout", s.adminLogout)
	api.GET("/admin/me", s.requireAdmin(), s.adminMe)

	// Business credential endpoints.
	api.POST("/check", s.requireCredential(ScopeCheck), s.check)
	api.POST("/subjects/resolve", s.requireCredential(ScopeSubjectResolve), s.resolveSubject)

	// Resources: admin session or business credential (same service, no status changes).
	res := api.Group("", s.requireAdminOrCredential())
	res.GET("/services/:id/resources", s.listResources)
	res.POST("/services/:id/resources", s.createResource)
	res.GET("/resources/:id", s.getResource)
	res.PATCH("/resources/:id", s.patchResource)

	// Management: admin only.
	m := api.Group("", s.requireAdmin())
	m.POST("/admin/check", s.adminCheck)
	m.GET("/services", s.listServices)
	m.POST("/services", s.createService)
	m.GET("/services/:id", s.getService)
	m.PATCH("/services/:id", s.patchService)
	m.DELETE("/services/:id", s.deleteService)

	m.GET("/services/:id/resource-types", s.listResourceTypes)
	m.POST("/services/:id/resource-types", s.createResourceType)
	m.PATCH("/resource-types/:id", s.patchResourceType)
	m.DELETE("/resource-types/:id", s.deleteResourceType)

	m.GET("/services/:id/permissions", s.listPermissions)
	m.POST("/services/:id/permissions", s.createPermission)
	m.DELETE("/permissions/:id", s.deletePermission)

	m.DELETE("/resources/:id", s.deleteResource)

	m.GET("/roles", s.listRoles)
	m.POST("/roles", s.createRole)
	m.GET("/roles/:id", s.getRole)
	m.PATCH("/roles/:id", s.patchRole)
	m.DELETE("/roles/:id", s.deleteRole)
	m.PUT("/roles/:id/permissions", s.setRolePermissions)

	m.GET("/assignments", s.listAssignments)
	m.POST("/assignments", s.createAssignment)
	m.DELETE("/assignments/:id", s.deleteAssignment)

	m.GET("/services/:id/service-accounts", s.listServiceAccounts)
	m.POST("/services/:id/service-accounts", s.createServiceAccount)
	m.PATCH("/service-accounts/:id", s.patchServiceAccount)
	m.DELETE("/service-accounts/:id", s.deleteServiceAccount)

	m.GET("/services/:id/credentials", s.listCredentials)
	m.POST("/services/:id/credentials", s.createCredential)
	m.DELETE("/credentials/:id", s.deleteCredential)

	m.GET("/users", s.listUsers)
	m.GET("/users/:id", s.getUser)
	m.GET("/groups", s.listGroups)
	m.GET("/groups/:id/members", s.listGroupMembers)

	m.GET("/audit-logs", s.listAuditLogs)
	m.GET("/sync/ldap/status", s.ldapStatus)
	m.POST("/sync/ldap/run", s.ldapRun)

	r.NoRoute(func(c *gin.Context) { fail(c, 404, "not_found", "route not found") })
	return r
}

// ---- response helpers ----

func requestID(c *gin.Context) string { return c.GetString("request_id") }

func fail(c *gin.Context, status int, code, msg string) {
	c.AbortWithStatusJSON(status, gin.H{"error_code": code, "message": msg, "request_id": requestID(c)})
}

func ok(c *gin.Context, status int, v any) {
	c.Header("X-Request-ID", requestID(c))
	c.JSON(status, v)
}

func list(c *gin.Context, items any) {
	ok(c, 200, gin.H{"items": items, "request_id": requestID(c)})
}

// failErr maps store/policy errors to HTTP responses.
func failErr(c *gin.Context, err error) {
	switch {
	case errors.Is(err, store.ErrNotFound):
		fail(c, 404, "not_found", "object not found")
	case errors.Is(err, store.ErrAlreadyExists):
		fail(c, 409, "already_exists", "an object with the same natural key already exists")
	case errors.Is(err, store.ErrObjectDeleted):
		fail(c, 409, "object_deleted", "an object with this external_id was deleted and cannot be recreated")
	case errors.Is(err, store.ErrObjectInUse):
		fail(c, 409, "object_in_use", "object is still referenced by other objects")
	case errors.Is(err, store.ErrInvalid):
		fail(c, 400, "invalid_request", err.Error())
	case errors.Is(err, policy.ErrNotReady):
		fail(c, 503, "policy_not_ready", "policy snapshot is not ready")
	case errors.Is(err, policy.ErrLDAPStale):
		fail(c, 503, "ldap_mirror_stale", "LDAP mirror is stale; user decisions are unavailable")
	case errors.Is(err, ldapsync.ErrSyncInProgress):
		fail(c, 409, "sync_in_progress", "an LDAP sync is already running")
	case errors.Is(err, ldapsync.ErrUnavailable):
		fail(c, 503, "ldap_unavailable", "LDAP directory is unreachable")
	case errors.Is(err, context.DeadlineExceeded):
		fail(c, 503, "internal_error", "upstream timeout")
	default:
		slog.Default().Error("internal error", "request_id", requestID(c), "error", err)
		fail(c, 500, "internal_error", "internal error")
	}
}

// bind decodes a JSON body strictly (unknown fields rejected, max 1 MiB).
func bind(c *gin.Context, v any) bool {
	dec := json.NewDecoder(io.LimitReader(c.Request.Body, 1<<20))
	dec.DisallowUnknownFields()
	if err := dec.Decode(v); err != nil {
		fail(c, 400, "invalid_request", "invalid JSON body: "+err.Error())
		return false
	}
	return true
}

func page(c *gin.Context) store.Page {
	l, _ := strconv.Atoi(c.Query("limit"))
	o, _ := strconv.Atoi(c.Query("offset"))
	return store.Page{Limit: l, Offset: o}
}

func pathID(c *gin.Context) (string, bool) {
	v := c.Param("id")
	if !id.Valid(v) {
		fail(c, 404, "not_found", "object not found")
		return "", false
	}
	return v, true
}

// patchBody is the common PATCH payload. Only these fields are mutable.
type patchBody struct {
	DisplayName *string `json:"display_name"`
	Description *string `json:"description"`
	ExternalKey *string `json:"external_key"`
	Status      *string `json:"status"`
}

func (p patchBody) toPatch(c *gin.Context, allowStatus, allowExternalKey bool) (store.StatusPatch, bool) {
	if p.Status != nil {
		if !allowStatus {
			fail(c, 403, "forbidden", "status changes require an administrator session")
			return store.StatusPatch{}, false
		}
		if *p.Status != store.StatusActive && *p.Status != store.StatusInactive {
			fail(c, 400, "invalid_request", "status must be 'active' or 'inactive'; use DELETE to delete")
			return store.StatusPatch{}, false
		}
	}
	if p.ExternalKey != nil && !allowExternalKey {
		fail(c, 400, "invalid_request", "external_key is not supported on this object")
		return store.StatusPatch{}, false
	}
	if p.DisplayName == nil && p.Description == nil && p.ExternalKey == nil && p.Status == nil {
		fail(c, 400, "invalid_request", "no mutable fields provided")
		return store.StatusPatch{}, false
	}
	return store.StatusPatch{DisplayName: p.DisplayName, Description: p.Description, ExternalKey: p.ExternalKey, Status: p.Status}, true
}

// actor returns the audit actor for the current principal.
func actor(c *gin.Context) policy.Actor {
	p := principalOf(c)
	switch p.kind {
	case kindAdmin:
		return policy.Actor{Type: "admin", ID: p.uid}
	case kindCredential:
		return policy.Actor{Type: "credential", ID: p.cred.ID}
	}
	return policy.Actor{Type: "anonymous", ID: ""}
}

// write is a shorthand for engine.Write with the request's actor and ID.
func (s *Server) write(c *gin.Context, fn func(w *policy.Writer) error) (int64, error) {
	ctx, cancel := context.WithTimeout(c.Request.Context(), 30*time.Second)
	defer cancel()
	return s.engine.Write(ctx, actor(c), requestID(c), fn)
}

func trimPtr(p *string) *string {
	if p == nil {
		return nil
	}
	v := strings.TrimSpace(*p)
	return &v
}

// errAlreadyGone signals a DELETE on an object that no longer exists (idempotent 200).
var errAlreadyGone = errors.New("already_gone")

func errInvalid(msg string) error { return fmt.Errorf("%w: %s", store.ErrInvalid, msg) }

var errForbidden = errors.New("forbidden")
