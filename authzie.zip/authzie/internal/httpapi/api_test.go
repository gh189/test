package httpapi

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/tongjie/authzie/internal/admin"
	"github.com/tongjie/authzie/internal/config"
	"github.com/tongjie/authzie/internal/id"
	"github.com/tongjie/authzie/internal/ldapsync"
	"github.com/tongjie/authzie/internal/policy"
	"github.com/tongjie/authzie/internal/store"
	"github.com/tongjie/authzie/internal/testutil"
)

// fakeLDAP authenticates a fixed set of uid/password pairs.
type fakeLDAP struct {
	users map[string]string
	down  bool
}

func (f *fakeLDAP) Authenticate(_ context.Context, uid, pw string) (string, error) {
	if f.down {
		return "", ldapsync.ErrUnavailable
	}
	if p, ok := f.users[uid]; ok && p == pw {
		return uid, nil
	}
	return "", ldapsync.ErrInvalidCredentials
}

type fakeSync struct{ running bool }

func (f *fakeSync) Run(context.Context) error {
	if f.running {
		return ldapsync.ErrSyncInProgress
	}
	return nil
}
func (f *fakeSync) Status(context.Context) (*ldapsync.Status, error) { return &ldapsync.Status{}, nil }

type harness struct {
	t        *testing.T
	r        *gin.Engine
	engine   *policy.Engine
	sessions *admin.Sessions
	ldap     *fakeLDAP
	logs     *bytes.Buffer
	cookie   string
	pool     *pgxpool.Pool
}

type resp struct {
	code int
	body map[string]any
	raw  string
}

func (r resp) str(k string) string {
	v, _ := r.body[k].(string)
	return v
}

func (r resp) items() []any {
	v, _ := r.body["items"].([]any)
	return v
}

func newHarness(t *testing.T) *harness {
	t.Helper()
	pool := testutil.OpenSchema(t)
	logs := &bytes.Buffer{}
	logger := slog.New(slog.NewJSONHandler(logs, nil))
	engine := policy.NewEngine(pool, logger, 30*time.Minute)
	if err := engine.Rebuild(context.Background()); err != nil {
		t.Fatal(err)
	}
	ldap := &fakeLDAP{users: map[string]string{"45020897": "admin-pw", "12345678": "user-pw"}}
	sessions := admin.NewSessions(time.Hour)
	cfg := &config.Config{SessionTTL: time.Hour}
	cfg.LDAP.Timeout = time.Second
	r := New(Options{Config: cfg, Engine: engine, Syncer: &fakeSync{}, LDAP: ldap, Sessions: sessions, Logger: logger,
		Pinger: pool.Ping})
	return &harness{t: t, r: r, engine: engine, sessions: sessions, ldap: ldap, logs: logs, pool: pool}
}

// mirror seeds the LDAP mirror directly and publishes a fresh sync time.
func (h *harness) mirror(users []store.MirrorUser, groups []store.MirrorGroup) {
	h.t.Helper()
	_, err := h.engine.Write(context.Background(), policy.Actor{Type: "system", ID: "test"}, "", func(w *policy.Writer) error {
		if _, err := store.ApplyMirror(w.Ctx(), w.Tx, users, groups, id.New); err != nil {
			return err
		}
		return store.RecordLDAPSuccess(w.Ctx(), w.Tx, time.Now(), nil)
	})
	if err != nil {
		h.t.Fatal(err)
	}
}

func (h *harness) login() {
	h.t.Helper()
	res := h.do("POST", "/api/v1/admin/login", map[string]any{"uid": "45020897", "password": "admin-pw"}, "")
	if res.code != 200 {
		h.t.Fatalf("login failed: %d %s", res.code, res.raw)
	}
}

// do performs a request. auth is "" (use admin cookie if any), "bearer:<token>" or "none".
func (h *harness) do(method, path string, body any, auth string) resp {
	h.t.Helper()
	var rd io.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		rd = bytes.NewReader(b)
	}
	req := httptest.NewRequest(method, path, rd)
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	switch {
	case strings.HasPrefix(auth, "bearer:"):
		req.Header.Set("Authorization", "Bearer "+strings.TrimPrefix(auth, "bearer:"))
	case auth == "nocsrf":
		if h.cookie != "" {
			req.Header.Set("Cookie", h.cookie)
		}
	case auth == "none":
	default:
		if h.cookie != "" {
			req.Header.Set("Cookie", h.cookie)
		}
		if method != "GET" {
			req.Header.Set(csrfHeader, "1")
		}
	}
	rec := httptest.NewRecorder()
	h.r.ServeHTTP(rec, req)
	for _, c := range rec.Result().Cookies() {
		if c.Name == sessionCookie {
			if c.MaxAge < 0 {
				h.cookie = ""
			} else {
				h.cookie = sessionCookie + "=" + c.Value
			}
		}
	}
	out := resp{code: rec.Code, raw: rec.Body.String()}
	_ = json.Unmarshal(rec.Body.Bytes(), &out.body)
	return out
}

func (h *harness) must(res resp, code int) resp {
	h.t.Helper()
	if res.code != code {
		h.t.Fatalf("expected %d, got %d: %s", code, res.code, res.raw)
	}
	return res
}

// tenant creates the standard fixture used by most tests.
type tenant struct {
	serviceID, rootID, rootTypeID, projTypeID, compTypeID string
	permEdit, permView, permCreate                        string
	projA, compA, projB                                   string
	roleEditor                                            string
	botID, token                                          string
}

func (h *harness) tenant(key string) *tenant {
	h.t.Helper()
	tn := &tenant{}
	svc := h.must(h.do("POST", "/api/v1/services", map[string]any{"service_key": key, "display_name": "Jira"}, ""), 201)
	tn.serviceID, tn.rootID, tn.rootTypeID = svc.str("id"), svc.str("root_resource_id"), svc.str("root_resource_type_id")
	base := "/api/v1/services/" + tn.serviceID
	tn.projTypeID = h.must(h.do("POST", base+"/resource-types", map[string]any{"type_key": "project"}, ""), 201).str("id")
	tn.compTypeID = h.must(h.do("POST", base+"/resource-types", map[string]any{"type_key": "component"}, ""), 201).str("id")
	tn.permEdit = h.must(h.do("POST", base+"/permissions", map[string]any{"resource_type_id": tn.projTypeID, "action": "issue_edit"}, ""), 201).str("id")
	tn.permView = h.must(h.do("POST", base+"/permissions", map[string]any{"resource_type_id": tn.projTypeID, "action": "issue_view"}, ""), 201).str("id")
	tn.permCreate = h.must(h.do("POST", base+"/permissions", map[string]any{"resource_type_id": tn.rootTypeID, "action": "project_create"}, ""), 201).str("id")
	tn.projA = h.must(h.do("POST", base+"/resources", map[string]any{"resource_type_id": tn.projTypeID, "external_id": "10001", "external_key": "PROJA"}, ""), 201).str("id")
	tn.compA = h.must(h.do("POST", base+"/resources", map[string]any{"resource_type_id": tn.compTypeID, "external_id": "20001", "parent_id": tn.projA}, ""), 201).str("id")
	tn.projB = h.must(h.do("POST", base+"/resources", map[string]any{"resource_type_id": tn.projTypeID, "external_id": "10002"}, ""), 201).str("id")
	tn.roleEditor = h.must(h.do("POST", "/api/v1/roles", map[string]any{"name": key + "-editor", "permission_ids": []string{tn.permEdit}}, ""), 201).str("id")
	tn.botID = h.must(h.do("POST", base+"/service-accounts", map[string]any{"external_id": "ci-bot"}, ""), 201).str("id")
	cred := h.must(h.do("POST", base+"/credentials", map[string]any{"name": "backend", "scopes": []string{ScopeCheck, ScopeResourceRead, ScopeResourceWrite, ScopeSubjectResolve}}, ""), 201)
	tn.token = cred.str("token")
	return tn
}

func (h *harness) check(token, subjType, subj, res, action string) resp {
	h.t.Helper()
	return h.do("POST", "/api/v1/check", map[string]any{"subject_type": subjType, "subject_id": subj, "resource_id": res, "action": action}, "bearer:"+token)
}

func (h *harness) expectDecision(res resp, allowed bool, reason string) {
	h.t.Helper()
	if res.code != 200 {
		h.t.Fatalf("check: expected 200, got %d %s", res.code, res.raw)
	}
	if res.body["allowed"] != allowed || res.str("reason") != reason {
		h.t.Fatalf("check: got allowed=%v reason=%s, want %v %s", res.body["allowed"], res.str("reason"), allowed, reason)
	}
}

func (h *harness) assign(body map[string]any) string {
	h.t.Helper()
	return h.must(h.do("POST", "/api/v1/assignments", body, ""), 201).str("id")
}

// ---- Tests ----

func TestAdminAuthAndCSRF(t *testing.T) {
	h := newHarness(t)

	h.must(h.do("GET", "/api/v1/services", nil, "none"), 401)
	h.must(h.do("POST", "/api/v1/admin/login", map[string]any{"uid": "45020897", "password": "admin-pw"}, "nocsrf"), 403)
	h.must(h.do("POST", "/api/v1/admin/login", map[string]any{"uid": "45020897", "password": "wrong"}, ""), 401)
	res := h.must(h.do("POST", "/api/v1/admin/login", map[string]any{"uid": "12345678", "password": "user-pw"}, ""), 403)
	if res.str("error_code") != "forbidden" {
		t.Fatalf("expected forbidden, got %s", res.raw)
	}
	h.ldap.down = true
	h.must(h.do("POST", "/api/v1/admin/login", map[string]any{"uid": "45020897", "password": "admin-pw"}, ""), 503)
	h.ldap.down = false

	h.login()
	me := h.must(h.do("GET", "/api/v1/admin/me", nil, ""), 200)
	if me.str("uid") != "45020897" {
		t.Fatalf("me: %s", me.raw)
	}
	h.must(h.do("POST", "/api/v1/services", map[string]any{"service_key": "x"}, "nocsrf"), 403)

	// wrong content type
	req := httptest.NewRequest("POST", "/api/v1/services", strings.NewReader(`{"service_key":"x"}`))
	req.Header.Set("Cookie", h.cookie)
	req.Header.Set(csrfHeader, "1")
	req.Header.Set("Content-Type", "text/plain")
	rec := httptest.NewRecorder()
	h.r.ServeHTTP(rec, req)
	if rec.Code != 415 {
		t.Fatalf("expected 415, got %d", rec.Code)
	}

	h.must(h.do("POST", "/api/v1/admin/logout", nil, ""), 200)
	h.must(h.do("GET", "/api/v1/admin/me", nil, ""), 401)

	// login events are audited by uid; the password never appears in logs
	h.login()
	audit := h.must(h.do("GET", "/api/v1/audit-logs?object_type=admin_session", nil, ""), 200)
	if len(audit.items()) < 3 {
		t.Fatalf("expected login audit entries, got %s", audit.raw)
	}
	if strings.Contains(h.logs.String(), "admin-pw") {
		t.Fatal("password leaked into logs")
	}
}

func TestEndToEndDecisions(t *testing.T) {
	h := newHarness(t)
	h.login()
	tn := h.tenant("jira")
	h.mirror([]store.MirrorUser{{ExternalID: "45020897", DN: "uid=45020897,cn=users", DisplayName: "Admin"},
		{ExternalID: "12345678", DN: "uid=12345678,cn=users", DisplayName: "User"}},
		[]store.MirrorGroup{{ExternalID: "jira-dev", DN: "cn=jira-dev,cn=groups", MemberIDs: []string{"45020897", "12345678"}}})

	// resolve subject
	res := h.must(h.do("POST", "/api/v1/subjects/resolve", map[string]any{"subject_type": "user", "external_id": "12345678"}, "bearer:"+tn.token), 200)
	userID := res.str("subject_id")
	h.must(h.do("POST", "/api/v1/subjects/resolve", map[string]any{"subject_type": "user", "external_id": "99999999"}, "bearer:"+tn.token), 404)
	bot := h.must(h.do("POST", "/api/v1/subjects/resolve", map[string]any{"subject_type": "service_account", "external_id": "ci-bot"}, "bearer:"+tn.token), 200)
	if bot.str("subject_id") != tn.botID {
		t.Fatal("service account resolve mismatch")
	}

	// default deny
	h.expectDecision(h.check(tn.token, "user", userID, tn.projA, "issue_edit"), false, policy.ReasonPermissionNotGranted)
	h.expectDecision(h.check(tn.token, "user", userID, tn.projA, "unknown"), false, policy.ReasonPermissionNotFound)
	h.expectDecision(h.check(tn.token, "user", userID, id.New(), "issue_edit"), false, policy.ReasonResourceNotFound)

	// resource scope with descendants on projA
	aid := h.assign(map[string]any{"subject_type": "user", "subject_id": userID, "role_id": tn.roleEditor, "scope_type": "resource", "resource_id": tn.projA})
	h.expectDecision(h.check(tn.token, "user", userID, tn.projA, "issue_edit"), true, policy.ReasonGranted)
	h.expectDecision(h.check(tn.token, "user", userID, tn.projB, "issue_edit"), false, policy.ReasonPermissionNotGranted)
	h.expectDecision(h.check(tn.token, "user", userID, tn.projA, "issue_view"), false, policy.ReasonPermissionNotGranted)

	// duplicate assignment -> 409
	h.must(h.do("POST", "/api/v1/assignments", map[string]any{"subject_type": "user", "subject_id": userID, "role_id": tn.roleEditor, "scope_type": "resource", "resource_id": tn.projA}, ""), 409)

	// revoke assignment -> deny immediately
	h.must(h.do("DELETE", "/api/v1/assignments/"+aid, nil, ""), 200)
	h.must(h.do("DELETE", "/api/v1/assignments/"+aid, nil, ""), 200) // idempotent
	h.expectDecision(h.check(tn.token, "user", userID, tn.projA, "issue_edit"), false, policy.ReasonPermissionNotGranted)

	// group assignment at service scope
	groups := h.must(h.do("GET", "/api/v1/groups", nil, ""), 200)
	groupID := groups.items()[0].(map[string]any)["id"].(string)
	members := h.must(h.do("GET", "/api/v1/groups/"+groupID+"/members", nil, ""), 200)
	if len(members.items()) != 2 {
		t.Fatalf("expected 2 members: %s", members.raw)
	}
	gaid := h.assign(map[string]any{"subject_type": "group", "subject_id": groupID, "role_id": tn.roleEditor, "scope_type": "service", "service_id": tn.serviceID})
	h.expectDecision(h.check(tn.token, "user", userID, tn.projB, "issue_edit"), true, policy.ReasonGranted)

	// disable role -> deny; enable -> allow
	h.must(h.do("PATCH", "/api/v1/roles/"+tn.roleEditor, map[string]any{"status": "inactive"}, ""), 200)
	h.expectDecision(h.check(tn.token, "user", userID, tn.projB, "issue_edit"), false, policy.ReasonPermissionNotGranted)
	h.must(h.do("PATCH", "/api/v1/roles/"+tn.roleEditor, map[string]any{"status": "active"}, ""), 200)
	h.expectDecision(h.check(tn.token, "user", userID, tn.projB, "issue_edit"), true, policy.ReasonGranted)

	// remove permission from role -> deny
	h.must(h.do("PUT", "/api/v1/roles/"+tn.roleEditor+"/permissions", map[string]any{"permission_ids": []string{tn.permView}}, ""), 200)
	h.expectDecision(h.check(tn.token, "user", userID, tn.projB, "issue_edit"), false, policy.ReasonPermissionNotGranted)
	h.expectDecision(h.check(tn.token, "user", userID, tn.projB, "issue_view"), true, policy.ReasonGranted)
	h.must(h.do("PUT", "/api/v1/roles/"+tn.roleEditor+"/permissions", map[string]any{"permission_ids": []string{tn.permEdit}}, ""), 200)

	// delete permission -> role loses it
	h.must(h.do("DELETE", "/api/v1/permissions/"+tn.permEdit, nil, ""), 200)
	h.expectDecision(h.check(tn.token, "user", userID, tn.projB, "issue_edit"), false, policy.ReasonPermissionNotFound)
	role := h.must(h.do("GET", "/api/v1/roles/"+tn.roleEditor, nil, ""), 200)
	if ids, _ := role.body["permission_ids"].([]any); len(ids) != 0 {
		t.Fatalf("permission should be removed from role: %s", role.raw)
	}

	// user removed from group -> deny; disabled user -> subject_inactive; reappears with same ID
	h.mirror([]store.MirrorUser{{ExternalID: "45020897"}, {ExternalID: "12345678"}}, []store.MirrorGroup{{ExternalID: "jira-dev", MemberIDs: []string{"45020897"}}})
	tn.permEdit = h.must(h.do("POST", "/api/v1/services/"+tn.serviceID+"/permissions", map[string]any{"resource_type_id": tn.projTypeID, "action": "issue_edit"}, ""), 201).str("id")
	h.must(h.do("PUT", "/api/v1/roles/"+tn.roleEditor+"/permissions", map[string]any{"permission_ids": []string{tn.permEdit}}, ""), 200)
	h.expectDecision(h.check(tn.token, "user", userID, tn.projB, "issue_edit"), false, policy.ReasonPermissionNotGranted)
	h.assign(map[string]any{"subject_type": "user", "subject_id": userID, "role_id": tn.roleEditor, "scope_type": "tenant"})
	h.expectDecision(h.check(tn.token, "user", userID, tn.projB, "issue_edit"), true, policy.ReasonGranted)

	h.mirror([]store.MirrorUser{{ExternalID: "45020897"}, {ExternalID: "12345678", Disabled: true}}, nil)
	h.expectDecision(h.check(tn.token, "user", userID, tn.projB, "issue_edit"), false, policy.ReasonSubjectInactive)
	h.mirror([]store.MirrorUser{{ExternalID: "45020897"}}, nil) // vanished
	h.expectDecision(h.check(tn.token, "user", userID, tn.projB, "issue_edit"), false, policy.ReasonSubjectInactive)
	h.must(h.do("POST", "/api/v1/subjects/resolve", map[string]any{"subject_type": "user", "external_id": "12345678"}, "bearer:"+tn.token), 200)
	h.mirror([]store.MirrorUser{{ExternalID: "45020897"}, {ExternalID: "12345678"}}, nil) // reappears
	again := h.must(h.do("POST", "/api/v1/subjects/resolve", map[string]any{"subject_type": "user", "external_id": "12345678"}, "bearer:"+tn.token), 200)
	if again.str("subject_id") != userID {
		t.Fatal("reappearing employee must keep the same internal ID")
	}
	h.expectDecision(h.check(tn.token, "user", userID, tn.projB, "issue_edit"), true, policy.ReasonGranted)

	// new employee ID does not inherit anything
	h.mirror([]store.MirrorUser{{ExternalID: "45020897"}, {ExternalID: "12345678"}, {ExternalID: "88888888", DisplayName: "User"}}, nil)
	newID := h.must(h.do("POST", "/api/v1/subjects/resolve", map[string]any{"subject_type": "user", "external_id": "88888888"}, "bearer:"+tn.token), 200).str("subject_id")
	h.expectDecision(h.check(tn.token, "user", newID, tn.projB, "issue_edit"), false, policy.ReasonPermissionNotGranted)

	// service account with tenant scope; disable and delete the account
	h.assign(map[string]any{"subject_type": "service_account", "subject_id": tn.botID, "role_id": tn.roleEditor, "scope_type": "tenant"})
	h.expectDecision(h.check(tn.token, "service_account", tn.botID, tn.projA, "issue_edit"), true, policy.ReasonGranted)
	h.must(h.do("PATCH", "/api/v1/service-accounts/"+tn.botID, map[string]any{"status": "inactive"}, ""), 200)
	h.expectDecision(h.check(tn.token, "service_account", tn.botID, tn.projA, "issue_edit"), false, policy.ReasonSubjectInactive)
	h.must(h.do("DELETE", "/api/v1/service-accounts/"+tn.botID, nil, ""), 200)
	h.expectDecision(h.check(tn.token, "service_account", tn.botID, tn.projA, "issue_edit"), false, policy.ReasonSubjectNotFound)
	if n := len(h.must(h.do("GET", "/api/v1/assignments?subject_id="+tn.botID, nil, ""), 200).items()); n != 0 {
		t.Fatalf("assignments of deleted service account must be removed, got %d", n)
	}
	_ = gaid
}

func TestResourceTreeRules(t *testing.T) {
	h := newHarness(t)
	h.login()
	tn := h.tenant("jira")
	other := h.tenant("wiki")
	h.mirror([]store.MirrorUser{{ExternalID: "12345678"}}, nil)
	userID := h.must(h.do("POST", "/api/v1/subjects/resolve", map[string]any{"subject_type": "user", "external_id": "12345678"}, "bearer:"+tn.token), 200).str("subject_id")

	base := "/api/v1/services/" + tn.serviceID
	// cross-service parent rejected
	h.must(h.do("POST", base+"/resources", map[string]any{"resource_type_id": tn.projTypeID, "external_id": "x1", "parent_id": other.rootID}, ""), 400)
	// type from another service rejected
	h.must(h.do("POST", base+"/resources", map[string]any{"resource_type_id": other.projTypeID, "external_id": "x2"}, ""), 400)
	// root type cannot be instantiated, root cannot be deleted or disabled
	h.must(h.do("POST", base+"/resources", map[string]any{"resource_type_id": tn.rootTypeID, "external_id": "x3"}, ""), 400)
	h.must(h.do("DELETE", "/api/v1/resources/"+tn.rootID, nil, ""), 400)
	h.must(h.do("PATCH", "/api/v1/resources/"+tn.rootID, map[string]any{"status": "inactive"}, ""), 400)
	h.must(h.do("DELETE", "/api/v1/resource-types/"+tn.rootTypeID, nil, ""), 409)
	// duplicate external_key
	h.must(h.do("POST", base+"/resources", map[string]any{"resource_type_id": tn.projTypeID, "external_id": "x4", "external_key": "PROJA"}, ""), 409)
	// depth limit
	parent := tn.projA
	for i := 0; i < store.MaxDepth; i++ {
		res := h.do("POST", base+"/resources", map[string]any{"resource_type_id": tn.compTypeID, "external_id": fmt.Sprintf("d%d", i), "parent_id": parent}, "")
		if res.code == 400 {
			if i < 20 {
				t.Fatalf("depth limit hit too early at %d", i)
			}
			break
		}
		h.must(res, 201)
		parent = res.str("id")
		if i == store.MaxDepth-1 {
			t.Fatal("depth limit never enforced")
		}
	}

	// parent inactive blocks inherited scope but not direct or service scope
	compPerm := h.must(h.do("POST", base+"/permissions", map[string]any{"resource_type_id": tn.compTypeID, "action": "issue_edit"}, ""), 201).str("id")
	compRole := h.must(h.do("POST", "/api/v1/roles", map[string]any{"name": "comp-editor", "permission_ids": []string{compPerm}}, ""), 201).str("id")
	inherited := h.assign(map[string]any{"subject_type": "user", "subject_id": userID, "role_id": compRole, "scope_type": "resource", "resource_id": tn.rootID})
	h.expectDecision(h.check(tn.token, "user", userID, tn.compA, "issue_edit"), true, policy.ReasonGranted)
	h.must(h.do("PATCH", "/api/v1/resources/"+tn.projA, map[string]any{"status": "inactive"}, ""), 200)
	h.expectDecision(h.check(tn.token, "user", userID, tn.compA, "issue_edit"), false, policy.ReasonPermissionNotGranted)
	h.expectDecision(h.check(tn.token, "user", userID, tn.projA, "issue_edit"), false, policy.ReasonResourceInactive)
	direct := h.assign(map[string]any{"subject_type": "user", "subject_id": userID, "role_id": compRole, "scope_type": "resource", "resource_id": tn.compA, "include_descendants": false})
	h.expectDecision(h.check(tn.token, "user", userID, tn.compA, "issue_edit"), true, policy.ReasonGranted)
	h.must(h.do("DELETE", "/api/v1/assignments/"+direct, nil, ""), 200)
	h.assign(map[string]any{"subject_type": "user", "subject_id": userID, "role_id": compRole, "scope_type": "service", "service_id": tn.serviceID})
	h.expectDecision(h.check(tn.token, "user", userID, tn.compA, "issue_edit"), true, policy.ReasonGranted)
	_ = inherited

	// delete resource: children stay, scoped assignments are removed, external_id cannot be recreated
	h.must(h.do("PATCH", "/api/v1/resources/"+tn.projA, map[string]any{"status": "active"}, ""), 200)
	scoped := h.assign(map[string]any{"subject_type": "user", "subject_id": userID, "role_id": tn.roleEditor, "scope_type": "resource", "resource_id": tn.projA})
	h.must(h.do("DELETE", "/api/v1/resources/"+tn.projA, nil, ""), 200)
	h.must(h.do("GET", "/api/v1/resources/"+tn.projA, nil, ""), 404)
	h.must(h.do("GET", "/api/v1/resources/"+tn.compA, nil, ""), 200)
	h.must(h.do("GET", "/api/v1/assignments/"+scoped, nil, ""), 404)
	res := h.do("POST", base+"/resources", map[string]any{"resource_type_id": tn.projTypeID, "external_id": "10001"}, "")
	if res.code != 409 || res.str("error_code") != "object_deleted" {
		t.Fatalf("expected 409 object_deleted, got %d %s", res.code, res.raw)
	}
	// other natural keys can be recreated with a new ID and no inherited assignments
	h.assign(map[string]any{"subject_type": "user", "subject_id": userID, "role_id": tn.roleEditor, "scope_type": "tenant"})
	h.must(h.do("DELETE", "/api/v1/roles/"+tn.roleEditor, nil, ""), 200)
	newRole := h.must(h.do("POST", "/api/v1/roles", map[string]any{"name": "jira-editor"}, ""), 201).str("id")
	if newRole == tn.roleEditor {
		t.Fatal("recreated role must get a new ID")
	}
	if n := len(h.must(h.do("GET", "/api/v1/assignments?role_id="+newRole, nil, ""), 200).items()); n != 0 {
		t.Fatalf("recreated role must not inherit assignments, got %d", n)
	}
	// resource type in use -> 409; permission delete then type delete works
	h.must(h.do("DELETE", "/api/v1/resource-types/"+tn.compTypeID, nil, ""), 409)

	// lookup by external_id
	found := h.must(h.do("GET", base+"/resources?external_id=10002", nil, "bearer:"+tn.token), 200)
	if len(found.items()) != 1 {
		t.Fatalf("expected one resource, got %s", found.raw)
	}
}

func TestCredentialBoundaries(t *testing.T) {
	h := newHarness(t)
	h.login()
	jira := h.tenant("jira")
	wiki := h.tenant("wiki")
	h.mirror([]store.MirrorUser{{ExternalID: "12345678"}}, nil)
	userID := h.must(h.do("POST", "/api/v1/subjects/resolve", map[string]any{"subject_type": "user", "external_id": "12345678"}, "bearer:"+jira.token), 200).str("subject_id")
	h.assign(map[string]any{"subject_type": "user", "subject_id": userID, "role_id": jira.roleEditor, "scope_type": "tenant"})

	// no / malformed / unknown credential
	h.must(h.do("POST", "/api/v1/check", map[string]any{}, "none"), 401)
	h.must(h.do("POST", "/api/v1/check", map[string]any{}, "bearer:garbage"), 401)
	fakeTok := "authzie_" + id.New() + ".secret"
	h.must(h.check(fakeTok, "user", userID, jira.projA, "issue_edit"), 401)
	idPart, _, _ := strings.Cut(strings.TrimPrefix(jira.token, "authzie_"), ".")
	h.must(h.check("authzie_"+idPart+".wrongsecret", "user", userID, jira.projA, "issue_edit"), 401)

	// cross-service: wiki credential sees jira resource as not found; cannot manage jira resources
	h.expectDecision(h.check(wiki.token, "user", userID, jira.projA, "issue_edit"), false, policy.ReasonResourceNotFound)
	h.must(h.do("GET", "/api/v1/services/"+jira.serviceID+"/resources", nil, "bearer:"+wiki.token), 403)
	h.must(h.do("GET", "/api/v1/resources/"+jira.projA, nil, "bearer:"+wiki.token), 404)
	h.must(h.do("PATCH", "/api/v1/resources/"+jira.projA, map[string]any{"display_name": "x"}, "bearer:"+wiki.token), 403)

	// business credential: may create/patch metadata, not status/delete, not roles/assignments
	base := "/api/v1/services/" + jira.serviceID
	created := h.must(h.do("POST", base+"/resources", map[string]any{"resource_type_id": jira.projTypeID, "external_id": "30001", "external_key": "NEW"}, "bearer:"+jira.token), 201)
	if created.str("parent_id") != jira.rootID {
		t.Fatalf("resource should default to the service root parent: %s", created.raw)
	}
	h.must(h.do("PATCH", "/api/v1/resources/"+created.str("id"), map[string]any{"display_name": "Renamed", "external_key": "NEW2"}, "bearer:"+jira.token), 200)
	h.must(h.do("PATCH", "/api/v1/resources/"+created.str("id"), map[string]any{"status": "inactive"}, "bearer:"+jira.token), 403)
	h.must(h.do("PATCH", "/api/v1/resources/"+jira.rootID, map[string]any{"display_name": "hack"}, "bearer:"+jira.token), 403)
	h.must(h.do("DELETE", "/api/v1/resources/"+created.str("id"), nil, "bearer:"+jira.token), 401)
	h.must(h.do("POST", "/api/v1/roles", map[string]any{"name": "r"}, "bearer:"+jira.token), 401)
	h.must(h.do("POST", "/api/v1/assignments", map[string]any{}, "bearer:"+jira.token), 401)
	h.must(h.do("GET", "/api/v1/services", nil, "bearer:"+jira.token), 401)

	// scope enforcement
	limited := h.must(h.do("POST", base+"/credentials", map[string]any{"name": "ro", "scopes": []string{ScopeResourceRead}}, ""), 201).str("token")
	h.must(h.check(limited, "user", userID, jira.projA, "issue_edit"), 403)
	h.must(h.do("POST", base+"/resources", map[string]any{"resource_type_id": jira.projTypeID, "external_id": "30002"}, "bearer:"+limited), 403)
	h.must(h.do("GET", base+"/resources", nil, "bearer:"+limited), 200)
	h.must(h.do("POST", base+"/credentials", map[string]any{"name": "bad", "scopes": []string{"nope"}}, ""), 400)

	// credential listing never exposes secrets; revoke -> 401
	creds := h.must(h.do("GET", base+"/credentials", nil, ""), 200)
	if strings.Contains(creds.raw, "secret_hash") || strings.Contains(creds.raw, "token") {
		t.Fatalf("credential listing leaks secret material: %s", creds.raw)
	}
	credID := creds.items()[0].(map[string]any)["id"].(string)
	h.must(h.do("DELETE", "/api/v1/credentials/"+credID, nil, ""), 200)
	if strings.HasPrefix(jira.token, "authzie_"+credID+".") {
		h.must(h.check(jira.token, "user", userID, jira.projA, "issue_edit"), 401)
	} else {
		h.must(h.check(limited, "user", userID, jira.projA, "issue_edit"), 401)
	}

	// disabling the service rejects its credentials; deleting the service cascades
	h.must(h.do("PATCH", base, map[string]any{"status": "inactive"}, ""), 200)
	remaining := jira.token
	if strings.HasPrefix(jira.token, "authzie_"+credID+".") {
		remaining = limited
	}
	h.must(h.do("GET", base+"/resources", nil, "bearer:"+remaining), 403)
	h.must(h.do("PATCH", base, map[string]any{"status": "active"}, ""), 200)
	h.must(h.do("DELETE", base, nil, ""), 200)
	h.must(h.do("GET", base+"/resources", nil, "bearer:"+remaining), 401)
	h.must(h.do("GET", base, nil, ""), 404)
	if n := len(h.must(h.do("GET", "/api/v1/assignments?subject_id="+userID, nil, ""), 200).items()); n != 1 {
		t.Fatalf("tenant assignment should survive service deletion, got %d", n)
	}
	// service key can be reused with a new ID
	again := h.must(h.do("POST", "/api/v1/services", map[string]any{"service_key": "jira"}, ""), 201)
	if again.str("id") == jira.serviceID {
		t.Fatal("recreated service must get a new ID")
	}

	// secrets and hashes never reach logs or audit
	secret := strings.SplitN(jira.token, ".", 2)[1]
	if strings.Contains(h.logs.String(), secret) {
		t.Fatal("credential secret leaked into logs")
	}
	audit := h.must(h.do("GET", "/api/v1/audit-logs?object_type=credential", nil, ""), 200)
	if strings.Contains(audit.raw, secret) || strings.Contains(audit.raw, "secret_hash") {
		t.Fatal("credential secret leaked into audit log")
	}
}

func TestStalenessReadinessAndRecovery(t *testing.T) {
	h := newHarness(t)
	h.login()
	tn := h.tenant("jira")

	// never synced -> user 503, service account fine
	h.must(h.check(tn.token, "user", id.New(), tn.projA, "issue_edit"), 503)
	h.must(h.do("POST", "/api/v1/subjects/resolve", map[string]any{"subject_type": "user", "external_id": "1"}, "bearer:"+tn.token), 503)
	h.expectDecision(h.check(tn.token, "service_account", tn.botID, tn.projA, "issue_edit"), false, policy.ReasonPermissionNotGranted)
	h.must(h.do("GET", "/readyz", nil, "none"), 200)

	h.mirror([]store.MirrorUser{{ExternalID: "12345678"}}, nil)
	userID := h.must(h.do("POST", "/api/v1/subjects/resolve", map[string]any{"subject_type": "user", "external_id": "12345678"}, "bearer:"+tn.token), 200).str("subject_id")
	h.assign(map[string]any{"subject_type": "user", "subject_id": userID, "role_id": tn.roleEditor, "scope_type": "tenant"})
	h.expectDecision(h.check(tn.token, "user", userID, tn.projA, "issue_edit"), true, policy.ReasonGranted)

	// restart: a fresh engine on the same database restores the same decisions
	engine2 := policy.NewEngine(h.pool, slog.Default(), 30*time.Minute)
	if _, err := engine2.Check(context.Background(), policy.Request{}); !errors.Is(err, policy.ErrNotReady) {
		t.Fatalf("engine without snapshot must report not ready, got %v", err)
	}
	if err := engine2.Rebuild(context.Background()); err != nil {
		t.Fatal(err)
	}
	d, err := engine2.Check(context.Background(), policy.Request{ServiceID: tn.serviceID, SubjectType: "user", SubjectID: userID, ResourceID: tn.projA, Action: "issue_edit"})
	if err != nil || !d.Allowed || d.PolicyVersion != h.engine.Revision() {
		t.Fatalf("restarted engine: %v %+v (want version %d)", err, d, h.engine.Revision())
	}

	// a stale mirror (tiny max staleness) makes user checks unavailable but not service accounts
	stale := policy.NewEngine(h.pool, slog.Default(), time.Nanosecond)
	if err := stale.Rebuild(context.Background()); err != nil {
		t.Fatal(err)
	}
	time.Sleep(time.Millisecond)
	if _, err := stale.Check(context.Background(), policy.Request{ServiceID: tn.serviceID, SubjectType: "user", SubjectID: userID, ResourceID: tn.projA, Action: "issue_edit"}); !errors.Is(err, policy.ErrLDAPStale) {
		t.Fatalf("expected ldap_mirror_stale, got %v", err)
	}
	if _, err := stale.Check(context.Background(), policy.Request{ServiceID: tn.serviceID, SubjectType: "service_account", SubjectID: tn.botID, ResourceID: tn.projA, Action: "issue_edit"}); err != nil {
		t.Fatalf("service account check must ignore staleness: %v", err)
	}
}

// audit failure must roll back the business write
func TestAuditFailureRollsBack(t *testing.T) {
	h := newHarness(t)
	h.login()
	svcID := h.must(h.do("POST", "/api/v1/services", map[string]any{"service_key": "jira"}, ""), 201).str("id")
	rev := h.engine.Revision()
	_, err := h.engine.Write(context.Background(), policy.Actor{Type: "admin", ID: "t"}, "", func(w *policy.Writer) error {
		if _, err := store.UpdateService(w.Ctx(), w.Tx, svcID, store.StatusPatch{Status: strPtr("inactive")}); err != nil {
			return err
		}
		return errors.New("audit sink failed")
	})
	if err == nil {
		t.Fatal("expected write error")
	}
	svc := h.must(h.do("GET", "/api/v1/services/"+svcID, nil, ""), 200)
	if svc.str("status") != "active" {
		t.Fatal("failed write was not rolled back")
	}
	if h.engine.Revision() != rev {
		t.Fatal("revision must not advance on failed write")
	}
}

func strPtr(s string) *string { return &s }

func TestAdminCheck(t *testing.T) {
	h := newHarness(t)
	h.login()
	tn := h.tenant("jira")
	h.mirror([]store.MirrorUser{{ExternalID: "12345678", DN: "uid=12345678,cn=users", DisplayName: "User"}}, nil)
	userID := h.must(h.do("POST", "/api/v1/subjects/resolve", map[string]any{"subject_type": "user", "external_id": "12345678"}, "bearer:"+tn.token), 200).str("subject_id")
	aid := h.assign(map[string]any{"subject_type": "user", "subject_id": userID, "role_id": tn.roleEditor, "scope_type": "resource", "resource_id": tn.projA})

	// by external IDs: allowed, with resolved objects and matched assignment
	body := map[string]any{"service_id": tn.serviceID, "subject_type": "user", "subject_external_id": "12345678", "resource_external_id": "10001", "action": "issue_edit"}
	res := h.must(h.do("POST", "/api/v1/admin/check", body, ""), 200)
	if res.body["allowed"] != true || res.str("reason") != policy.ReasonGranted {
		t.Fatalf("expected allow: %s", res.raw)
	}
	if m, _ := res.body["matched_assignment"].(map[string]any); m["id"] != aid {
		t.Fatalf("matched assignment mismatch: %s", res.raw)
	}
	if subj, _ := res.body["subject"].(map[string]any); subj["id"] != userID || subj["display_name"] != "User" {
		t.Fatalf("subject not resolved: %s", res.raw)
	}

	// by ULIDs: denied, no matched assignment
	body = map[string]any{"service_id": tn.serviceID, "subject_type": "user", "subject_id": userID, "resource_id": tn.projB, "action": "issue_edit"}
	res = h.must(h.do("POST", "/api/v1/admin/check", body, ""), 200)
	if res.body["allowed"] != false || res.body["matched_assignment"] != nil {
		t.Fatalf("expected deny: %s", res.raw)
	}

	// unknown external IDs -> 404; wrong service -> 404; credential cannot use it -> 401
	body["subject_external_id"], body["subject_id"] = "99999999", ""
	h.must(h.do("POST", "/api/v1/admin/check", body, ""), 404)
	body["subject_id"], body["resource_id"], body["resource_external_id"] = userID, "", "nope"
	h.must(h.do("POST", "/api/v1/admin/check", body, ""), 404)
	body["service_id"] = id.New()
	h.must(h.do("POST", "/api/v1/admin/check", body, ""), 404)
	h.must(h.do("POST", "/api/v1/admin/check", body, "bearer:"+tn.token), 401)

	// business /check response is unchanged (no matched_assignment)
	res = h.check(tn.token, "user", userID, tn.projA, "issue_edit")
	if _, has := res.body["matched_assignment"]; has {
		t.Fatalf("/check must not expose matched_assignment: %s", res.raw)
	}
}

func TestHealthAndRequestID(t *testing.T) {
	h := newHarness(t)
	req := httptest.NewRequest("GET", "/healthz", nil)
	req.Header.Set("X-Request-ID", "abc-123")
	rec := httptest.NewRecorder()
	h.r.ServeHTTP(rec, req)
	if rec.Code != 200 || rec.Header().Get("X-Request-ID") != "abc-123" {
		t.Fatalf("healthz: %d %v", rec.Code, rec.Header())
	}
	res := h.do("GET", "/api/v1/nope", nil, "none")
	if res.code != 404 || res.str("request_id") == "" {
		t.Fatalf("404 body must carry request_id: %s", res.raw)
	}
	h.must(h.do("POST", "/api/v1/sync/ldap/run", nil, "none"), 401)
	h.login()
	h.must(h.do("POST", "/api/v1/sync/ldap/run", nil, ""), 200)
	h.must(h.do("GET", "/api/v1/sync/ldap/status", nil, ""), 200)
}
