package httpapi

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"strings"

	"github.com/gin-gonic/gin"

	"github.com/tongjie/authzie/internal/id"
	"github.com/tongjie/authzie/internal/policy"
	"github.com/tongjie/authzie/internal/store"
)

// ---- Services ----

func (s *Server) listServices(c *gin.Context) {
	items, err := store.ListServices(c.Request.Context(), s.engine.DB(), page(c))
	if err != nil {
		failErr(c, err)
		return
	}
	list(c, items)
}

func (s *Server) getService(c *gin.Context) {
	sid, okID := pathID(c)
	if !okID {
		return
	}
	svc, err := store.GetService(c.Request.Context(), s.engine.DB(), sid)
	if err != nil {
		failErr(c, err)
		return
	}
	ok(c, 200, svc)
}

func (s *Server) createService(c *gin.Context) {
	var body struct {
		ServiceKey  string `json:"service_key"`
		DisplayName string `json:"display_name"`
		Description string `json:"description"`
	}
	if !bind(c, &body) {
		return
	}
	body.ServiceKey = strings.TrimSpace(body.ServiceKey)
	if err := store.ValidateKey(body.ServiceKey); err != nil {
		failErr(c, err)
		return
	}
	svc := &store.Service{ID: id.New(), ServiceKey: body.ServiceKey, DisplayName: body.DisplayName, Description: body.Description, Status: store.StatusActive}
	if svc.DisplayName == "" {
		svc.DisplayName = svc.ServiceKey
	}
	// Service, its reserved root type and root resource are created in one transaction.
	rt := &store.ResourceType{ID: id.New(), ServiceID: svc.ID, TypeKey: store.RootTypeKey, DisplayName: "Service root"}
	root := &store.Resource{ID: id.New(), ServiceID: svc.ID, ResourceTypeID: rt.ID, ExternalID: store.RootExternalID, DisplayName: svc.DisplayName + " root"}
	_, err := s.write(c, func(w *policy.Writer) error {
		if err := store.CreateService(w.Ctx(), w.Tx, svc); err != nil {
			return err
		}
		if err := store.CreateResourceType(w.Ctx(), w.Tx, rt); err != nil {
			return err
		}
		if err := store.CreateResource(w.Ctx(), w.Tx, root); err != nil {
			return err
		}
		if err := w.Audit("service.create", "service", svc.ID, nil, svc); err != nil {
			return err
		}
		if err := w.Audit("resource_type.create", "resource_type", rt.ID, nil, rt); err != nil {
			return err
		}
		return w.Audit("resource.create", "resource", root.ID, nil, root)
	})
	if err != nil {
		failErr(c, err)
		return
	}
	out, err := store.GetService(c.Request.Context(), s.engine.DB(), svc.ID)
	if err != nil {
		failErr(c, err)
		return
	}
	ok(c, 201, gin.H{"id": out.ID, "service_key": out.ServiceKey, "display_name": out.DisplayName, "description": out.Description,
		"status": out.Status, "created_at": out.CreatedAt, "updated_at": out.UpdatedAt, "root_resource_id": root.ID, "root_resource_type_id": rt.ID})
}

func (s *Server) patchService(c *gin.Context) {
	sid, okID := pathID(c)
	if !okID {
		return
	}
	var body patchBody
	if !bind(c, &body) {
		return
	}
	p, okP := body.toPatch(c, true, false)
	if !okP {
		return
	}
	var out *store.Service
	_, err := s.write(c, func(w *policy.Writer) error {
		before, err := store.GetService(w.Ctx(), w.Tx, sid)
		if err != nil {
			return err
		}
		if out, err = store.UpdateService(w.Ctx(), w.Tx, sid, p); err != nil {
			return err
		}
		return w.Audit("service.update", "service", sid, before, out)
	})
	if err != nil {
		failErr(c, err)
		return
	}
	ok(c, 200, out)
}

func (s *Server) deleteService(c *gin.Context) {
	sid, okID := pathID(c)
	if !okID {
		return
	}
	s.deleteWith(c, "service", sid, func(w *policy.Writer) (any, error) {
		before, err := store.GetService(w.Ctx(), w.Tx, sid)
		if err != nil {
			return nil, err
		}
		return before, store.DeleteService(w.Ctx(), w.Tx, sid)
	})
}

// deleteWith runs a delete; deleting an already-deleted/missing object returns 200.
func (s *Server) deleteWith(c *gin.Context, objectType, objectID string, fn func(w *policy.Writer) (any, error)) {
	_, err := s.write(c, func(w *policy.Writer) error {
		before, err := fn(w)
		if err != nil {
			if err == store.ErrNotFound {
				return errAlreadyGone
			}
			return err
		}
		return w.Audit(objectType+".delete", objectType, objectID, before, nil)
	})
	if err != nil && err != errAlreadyGone {
		failErr(c, err)
		return
	}
	ok(c, 200, gin.H{"id": objectID, "status": "deleted", "request_id": requestID(c)})
}

// ---- Resource types ----

func (s *Server) listResourceTypes(c *gin.Context) {
	sid, okID := pathID(c)
	if !okID {
		return
	}
	if _, err := store.GetService(c.Request.Context(), s.engine.DB(), sid); err != nil {
		failErr(c, err)
		return
	}
	items, err := store.ListResourceTypes(c.Request.Context(), s.engine.DB(), sid, page(c))
	if err != nil {
		failErr(c, err)
		return
	}
	list(c, items)
}

func (s *Server) createResourceType(c *gin.Context) {
	sid, okID := pathID(c)
	if !okID {
		return
	}
	var body struct {
		TypeKey     string `json:"type_key"`
		DisplayName string `json:"display_name"`
		Description string `json:"description"`
	}
	if !bind(c, &body) {
		return
	}
	body.TypeKey = strings.TrimSpace(body.TypeKey)
	if err := store.ValidateKey(body.TypeKey); err != nil {
		failErr(c, err)
		return
	}
	if body.TypeKey == store.RootTypeKey {
		fail(c, 400, "invalid_request", store.RootTypeKey+" is reserved")
		return
	}
	rt := &store.ResourceType{ID: id.New(), ServiceID: sid, TypeKey: body.TypeKey, DisplayName: body.DisplayName, Description: body.Description}
	if rt.DisplayName == "" {
		rt.DisplayName = rt.TypeKey
	}
	_, err := s.write(c, func(w *policy.Writer) error {
		if _, err := store.GetService(w.Ctx(), w.Tx, sid); err != nil {
			return err
		}
		if err := store.CreateResourceType(w.Ctx(), w.Tx, rt); err != nil {
			return err
		}
		return w.Audit("resource_type.create", "resource_type", rt.ID, nil, rt)
	})
	if err != nil {
		failErr(c, err)
		return
	}
	s.reply(c, 201, func() (any, error) { return store.GetResourceType(c.Request.Context(), s.engine.DB(), rt.ID) })
}

func (s *Server) patchResourceType(c *gin.Context) {
	rid, okID := pathID(c)
	if !okID {
		return
	}
	var body patchBody
	if !bind(c, &body) {
		return
	}
	p, okP := body.toPatch(c, false, false)
	if !okP {
		return
	}
	var out *store.ResourceType
	_, err := s.write(c, func(w *policy.Writer) error {
		before, err := store.GetResourceType(w.Ctx(), w.Tx, rid)
		if err != nil {
			return err
		}
		if out, err = store.UpdateResourceType(w.Ctx(), w.Tx, rid, p); err != nil {
			return err
		}
		return w.Audit("resource_type.update", "resource_type", rid, before, out)
	})
	if err != nil {
		failErr(c, err)
		return
	}
	ok(c, 200, out)
}

func (s *Server) deleteResourceType(c *gin.Context) {
	rid, okID := pathID(c)
	if !okID {
		return
	}
	s.deleteWith(c, "resource_type", rid, func(w *policy.Writer) (any, error) {
		before, err := store.GetResourceType(w.Ctx(), w.Tx, rid)
		if err != nil {
			return nil, err
		}
		if before.TypeKey == store.RootTypeKey {
			return nil, store.ErrObjectInUse
		}
		return before, store.DeleteResourceType(w.Ctx(), w.Tx, rid)
	})
}

// ---- Permissions ----

func (s *Server) listPermissions(c *gin.Context) {
	sid, okID := pathID(c)
	if !okID {
		return
	}
	if _, err := store.GetService(c.Request.Context(), s.engine.DB(), sid); err != nil {
		failErr(c, err)
		return
	}
	items, err := store.ListPermissions(c.Request.Context(), s.engine.DB(), sid, page(c))
	if err != nil {
		failErr(c, err)
		return
	}
	list(c, items)
}

func (s *Server) createPermission(c *gin.Context) {
	sid, okID := pathID(c)
	if !okID {
		return
	}
	var body struct {
		ResourceTypeID string `json:"resource_type_id"`
		Action         string `json:"action"`
		Description    string `json:"description"`
	}
	if !bind(c, &body) {
		return
	}
	body.Action = strings.TrimSpace(body.Action)
	if err := store.ValidateKey(body.Action); err != nil {
		failErr(c, err)
		return
	}
	if !id.Valid(body.ResourceTypeID) {
		fail(c, 400, "invalid_request", "resource_type_id must be a ULID")
		return
	}
	pm := &store.Permission{ID: id.New(), ServiceID: sid, ResourceTypeID: body.ResourceTypeID, Action: body.Action, Description: body.Description}
	_, err := s.write(c, func(w *policy.Writer) error {
		if _, err := store.GetService(w.Ctx(), w.Tx, sid); err != nil {
			return err
		}
		rt, err := store.GetResourceType(w.Ctx(), w.Tx, body.ResourceTypeID)
		if err != nil || rt.ServiceID != sid {
			return errInvalid("resource_type_id does not belong to this service")
		}
		if err := store.CreatePermission(w.Ctx(), w.Tx, pm); err != nil {
			return err
		}
		return w.Audit("permission.create", "permission", pm.ID, nil, pm)
	})
	if err != nil {
		failErr(c, err)
		return
	}
	s.reply(c, 201, func() (any, error) { return store.GetPermission(c.Request.Context(), s.engine.DB(), pm.ID) })
}

func (s *Server) deletePermission(c *gin.Context) {
	pid, okID := pathID(c)
	if !okID {
		return
	}
	s.deleteWith(c, "permission", pid, func(w *policy.Writer) (any, error) {
		before, err := store.GetPermission(w.Ctx(), w.Tx, pid)
		if err != nil {
			return nil, err
		}
		return before, store.DeletePermission(w.Ctx(), w.Tx, pid)
	})
}

// ---- Roles ----

func (s *Server) listRoles(c *gin.Context) {
	items, err := store.ListRoles(c.Request.Context(), s.engine.DB(), page(c))
	if err != nil {
		failErr(c, err)
		return
	}
	list(c, items)
}

type roleOut struct {
	*store.Role
	PermissionIDs []string `json:"permission_ids"`
}

func (s *Server) roleWithPerms(c *gin.Context, rid string) (*roleOut, error) {
	r, err := store.GetRole(c.Request.Context(), s.engine.DB(), rid)
	if err != nil {
		return nil, err
	}
	perms, err := store.ListRolePermissionIDs(c.Request.Context(), s.engine.DB(), rid)
	if err != nil {
		return nil, err
	}
	return &roleOut{Role: r, PermissionIDs: perms}, nil
}

func (s *Server) getRole(c *gin.Context) {
	rid, okID := pathID(c)
	if !okID {
		return
	}
	s.reply(c, 200, func() (any, error) { return s.roleWithPerms(c, rid) })
}

func (s *Server) createRole(c *gin.Context) {
	var body struct {
		Name          string   `json:"name"`
		DisplayName   string   `json:"display_name"`
		Description   string   `json:"description"`
		PermissionIDs []string `json:"permission_ids"`
	}
	if !bind(c, &body) {
		return
	}
	body.Name = strings.TrimSpace(body.Name)
	if err := store.ValidateKey(body.Name); err != nil {
		failErr(c, err)
		return
	}
	r := &store.Role{ID: id.New(), Name: body.Name, DisplayName: body.DisplayName, Description: body.Description, Status: store.StatusActive}
	if r.DisplayName == "" {
		r.DisplayName = r.Name
	}
	_, err := s.write(c, func(w *policy.Writer) error {
		if err := store.CreateRole(w.Ctx(), w.Tx, r); err != nil {
			return err
		}
		if len(body.PermissionIDs) > 0 {
			if err := store.SetRolePermissions(w.Ctx(), w.Tx, r.ID, body.PermissionIDs); err != nil {
				return err
			}
		}
		return w.Audit("role.create", "role", r.ID, nil, gin.H{"role": r, "permission_ids": body.PermissionIDs})
	})
	if err != nil {
		failErr(c, err)
		return
	}
	s.reply(c, 201, func() (any, error) { return s.roleWithPerms(c, r.ID) })
}

func (s *Server) patchRole(c *gin.Context) {
	rid, okID := pathID(c)
	if !okID {
		return
	}
	var body patchBody
	if !bind(c, &body) {
		return
	}
	p, okP := body.toPatch(c, true, false)
	if !okP {
		return
	}
	var out *store.Role
	_, err := s.write(c, func(w *policy.Writer) error {
		before, err := store.GetRole(w.Ctx(), w.Tx, rid)
		if err != nil {
			return err
		}
		if out, err = store.UpdateRole(w.Ctx(), w.Tx, rid, p); err != nil {
			return err
		}
		return w.Audit("role.update", "role", rid, before, out)
	})
	if err != nil {
		failErr(c, err)
		return
	}
	ok(c, 200, out)
}

func (s *Server) deleteRole(c *gin.Context) {
	rid, okID := pathID(c)
	if !okID {
		return
	}
	s.deleteWith(c, "role", rid, func(w *policy.Writer) (any, error) {
		before, err := store.GetRole(w.Ctx(), w.Tx, rid)
		if err != nil {
			return nil, err
		}
		return before, store.DeleteRole(w.Ctx(), w.Tx, rid)
	})
}

func (s *Server) setRolePermissions(c *gin.Context) {
	rid, okID := pathID(c)
	if !okID {
		return
	}
	var body struct {
		PermissionIDs []string `json:"permission_ids"`
	}
	if !bind(c, &body) {
		return
	}
	if body.PermissionIDs == nil {
		fail(c, 400, "invalid_request", "permission_ids is required")
		return
	}
	for _, p := range body.PermissionIDs {
		if !id.Valid(p) {
			fail(c, 400, "invalid_request", "permission_ids must be ULIDs")
			return
		}
	}
	_, err := s.write(c, func(w *policy.Writer) error {
		if _, err := store.GetRole(w.Ctx(), w.Tx, rid); err != nil {
			return err
		}
		before, err := store.ListRolePermissionIDs(w.Ctx(), w.Tx, rid)
		if err != nil {
			return err
		}
		if err := store.SetRolePermissions(w.Ctx(), w.Tx, rid, body.PermissionIDs); err != nil {
			return err
		}
		return w.Audit("role.set_permissions", "role", rid, gin.H{"permission_ids": before}, gin.H{"permission_ids": body.PermissionIDs})
	})
	if err != nil {
		failErr(c, err)
		return
	}
	s.reply(c, 200, func() (any, error) { return s.roleWithPerms(c, rid) })
}

// ---- Assignments ----

func (s *Server) listAssignments(c *gin.Context) {
	f := store.AssignmentFilter{
		SubjectType: c.Query("subject_type"), SubjectID: c.Query("subject_id"), RoleID: c.Query("role_id"),
		ScopeType: c.Query("scope_type"), ServiceID: c.Query("service_id"), ResourceID: c.Query("resource_id"),
	}
	items, err := store.ListAssignments(c.Request.Context(), s.engine.DB(), f, page(c))
	if err != nil {
		failErr(c, err)
		return
	}
	list(c, items)
}

func (s *Server) createAssignment(c *gin.Context) {
	var body struct {
		SubjectType        string `json:"subject_type"`
		SubjectID          string `json:"subject_id"`
		RoleID             string `json:"role_id"`
		ScopeType          string `json:"scope_type"`
		ServiceID          string `json:"service_id"`
		ResourceID         string `json:"resource_id"`
		IncludeDescendants *bool  `json:"include_descendants"`
	}
	if !bind(c, &body) {
		return
	}
	if !id.Valid(body.SubjectID) || !id.Valid(body.RoleID) {
		fail(c, 400, "invalid_request", "subject_id and role_id must be ULIDs")
		return
	}
	a := &store.Assignment{ID: id.New(), SubjectType: body.SubjectType, SubjectID: body.SubjectID, RoleID: body.RoleID,
		ScopeType: body.ScopeType, ServiceID: body.ServiceID, ResourceID: body.ResourceID, IncludeDescendants: true}
	switch body.ScopeType {
	case store.ScopeService:
		if !id.Valid(body.ServiceID) {
			fail(c, 400, "invalid_request", "service_id is required for service scope")
			return
		}
	case store.ScopeResource:
		if !id.Valid(body.ResourceID) {
			fail(c, 400, "invalid_request", "resource_id is required for resource scope")
			return
		}
		if body.IncludeDescendants != nil {
			a.IncludeDescendants = *body.IncludeDescendants
		}
	case store.ScopeTenant:
	default:
		fail(c, 400, "invalid_request", "scope_type must be tenant, service or resource")
		return
	}
	_, err := s.write(c, func(w *policy.Writer) error {
		if err := store.CreateAssignment(w.Ctx(), w.Tx, a); err != nil {
			return err
		}
		return w.Audit("assignment.create", "assignment", a.ID, nil, a)
	})
	if err != nil {
		failErr(c, err)
		return
	}
	s.reply(c, 201, func() (any, error) { return store.GetAssignment(c.Request.Context(), s.engine.DB(), a.ID) })
}

func (s *Server) deleteAssignment(c *gin.Context) {
	aid, okID := pathID(c)
	if !okID {
		return
	}
	s.deleteWith(c, "assignment", aid, func(w *policy.Writer) (any, error) {
		before, err := store.GetAssignment(w.Ctx(), w.Tx, aid)
		if err != nil {
			return nil, err
		}
		return before, store.DeleteAssignment(w.Ctx(), w.Tx, aid)
	})
}

// ---- Service accounts ----

func (s *Server) listServiceAccounts(c *gin.Context) {
	sid, okID := pathID(c)
	if !okID {
		return
	}
	if _, err := store.GetService(c.Request.Context(), s.engine.DB(), sid); err != nil {
		failErr(c, err)
		return
	}
	items, err := store.ListServiceAccounts(c.Request.Context(), s.engine.DB(), sid, page(c))
	if err != nil {
		failErr(c, err)
		return
	}
	list(c, items)
}

func (s *Server) createServiceAccount(c *gin.Context) {
	sid, okID := pathID(c)
	if !okID {
		return
	}
	var body struct {
		ExternalID  string `json:"external_id"`
		DisplayName string `json:"display_name"`
		Description string `json:"description"`
	}
	if !bind(c, &body) {
		return
	}
	body.ExternalID = strings.TrimSpace(body.ExternalID)
	if body.ExternalID == "" || len(body.ExternalID) > 255 {
		fail(c, 400, "invalid_request", "external_id is required (max 255 chars)")
		return
	}
	sa := &store.ServiceAccount{ID: id.New(), ServiceID: sid, ExternalID: body.ExternalID, DisplayName: body.DisplayName, Description: body.Description, Status: store.StatusActive}
	if sa.DisplayName == "" {
		sa.DisplayName = sa.ExternalID
	}
	_, err := s.write(c, func(w *policy.Writer) error {
		if _, err := store.GetService(w.Ctx(), w.Tx, sid); err != nil {
			return err
		}
		if err := store.CreateServiceAccount(w.Ctx(), w.Tx, sa); err != nil {
			return err
		}
		return w.Audit("service_account.create", "service_account", sa.ID, nil, sa)
	})
	if err != nil {
		failErr(c, err)
		return
	}
	s.reply(c, 201, func() (any, error) { return store.GetServiceAccount(c.Request.Context(), s.engine.DB(), sa.ID) })
}

func (s *Server) patchServiceAccount(c *gin.Context) {
	said, okID := pathID(c)
	if !okID {
		return
	}
	var body patchBody
	if !bind(c, &body) {
		return
	}
	p, okP := body.toPatch(c, true, false)
	if !okP {
		return
	}
	var out *store.ServiceAccount
	_, err := s.write(c, func(w *policy.Writer) error {
		before, err := store.GetServiceAccount(w.Ctx(), w.Tx, said)
		if err != nil {
			return err
		}
		if out, err = store.UpdateServiceAccount(w.Ctx(), w.Tx, said, p); err != nil {
			return err
		}
		return w.Audit("service_account.update", "service_account", said, before, out)
	})
	if err != nil {
		failErr(c, err)
		return
	}
	ok(c, 200, out)
}

func (s *Server) deleteServiceAccount(c *gin.Context) {
	said, okID := pathID(c)
	if !okID {
		return
	}
	s.deleteWith(c, "service_account", said, func(w *policy.Writer) (any, error) {
		before, err := store.GetServiceAccount(w.Ctx(), w.Tx, said)
		if err != nil {
			return nil, err
		}
		return before, store.DeleteServiceAccount(w.Ctx(), w.Tx, said)
	})
}

// ---- Credentials ----

func (s *Server) listCredentials(c *gin.Context) {
	sid, okID := pathID(c)
	if !okID {
		return
	}
	if _, err := store.GetService(c.Request.Context(), s.engine.DB(), sid); err != nil {
		failErr(c, err)
		return
	}
	items, err := store.ListCredentials(c.Request.Context(), s.engine.DB(), sid, page(c))
	if err != nil {
		failErr(c, err)
		return
	}
	list(c, items)
}

// createCredential returns the plaintext token exactly once. Only the SHA-256 hash is stored.
func (s *Server) createCredential(c *gin.Context) {
	sid, okID := pathID(c)
	if !okID {
		return
	}
	var body struct {
		Name   string   `json:"name"`
		Scopes []string `json:"scopes"`
	}
	if !bind(c, &body) {
		return
	}
	if len(body.Scopes) == 0 {
		fail(c, 400, "invalid_request", "at least one scope is required")
		return
	}
	seen := map[string]bool{}
	scopes := make([]string, 0, len(body.Scopes))
	for _, sc := range body.Scopes {
		if !validScopes[sc] {
			fail(c, 400, "invalid_request", "unknown scope "+sc)
			return
		}
		if !seen[sc] {
			seen[sc] = true
			scopes = append(scopes, sc)
		}
	}
	raw := make([]byte, 32)
	if _, err := rand.Read(raw); err != nil {
		failErr(c, err)
		return
	}
	secret := base64.RawURLEncoding.EncodeToString(raw)
	hash := sha256.Sum256([]byte(secret))
	cred := &store.Credential{ID: id.New(), ServiceID: sid, Name: strings.TrimSpace(body.Name), SecretHash: hash[:], Scopes: scopes}
	_, err := s.write(c, func(w *policy.Writer) error {
		if _, err := store.GetService(w.Ctx(), w.Tx, sid); err != nil {
			return err
		}
		if err := store.CreateCredential(w.Ctx(), w.Tx, cred); err != nil {
			return err
		}
		return w.Audit("credential.create", "credential", cred.ID, nil, gin.H{"id": cred.ID, "service_id": sid, "name": cred.Name, "scopes": scopes})
	})
	if err != nil {
		failErr(c, err)
		return
	}
	out, err := store.GetCredential(c.Request.Context(), s.engine.DB(), cred.ID)
	if err != nil {
		failErr(c, err)
		return
	}
	ok(c, 201, gin.H{"id": out.ID, "service_id": out.ServiceID, "name": out.Name, "scopes": out.Scopes, "created_at": out.CreatedAt,
		"token": "authzie_" + out.ID + "." + secret, "request_id": requestID(c)})
}

func (s *Server) deleteCredential(c *gin.Context) {
	cid, okID := pathID(c)
	if !okID {
		return
	}
	s.deleteWith(c, "credential", cid, func(w *policy.Writer) (any, error) {
		before, err := store.GetCredential(w.Ctx(), w.Tx, cid)
		if err != nil {
			return nil, err
		}
		if before.RevokedAt != nil {
			return nil, store.ErrNotFound
		}
		return gin.H{"id": before.ID, "service_id": before.ServiceID, "name": before.Name, "scopes": before.Scopes},
			store.RevokeCredential(w.Ctx(), w.Tx, cid)
	})
}

// reply fetches a fresh representation and writes it.
func (s *Server) reply(c *gin.Context, status int, fetch func() (any, error)) {
	v, err := fetch()
	if err != nil {
		failErr(c, err)
		return
	}
	ok(c, status, v)
}
