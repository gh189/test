package httpapi

import (
	"strings"

	"github.com/gin-gonic/gin"

	"github.com/tongjie/authzie/internal/id"
	"github.com/tongjie/authzie/internal/policy"
	"github.com/tongjie/authzie/internal/store"
)

// credentialAllows enforces that a business credential only touches its own service with the right scope.
func credentialAllows(c *gin.Context, serviceID, scope string) bool {
	p := principalOf(c)
	if p.kind != kindCredential {
		return true
	}
	if p.cred.ServiceID != serviceID {
		fail(c, 403, "forbidden", "credential is bound to another service")
		return false
	}
	if !hasScope(p.cred, scope) {
		fail(c, 403, "forbidden", "credential lacks scope "+scope)
		return false
	}
	return true
}

func (s *Server) listResources(c *gin.Context) {
	sid, okID := pathID(c)
	if !okID {
		return
	}
	if !credentialAllows(c, sid, ScopeResourceRead) {
		return
	}
	if _, err := store.GetService(c.Request.Context(), s.engine.DB(), sid); err != nil {
		failErr(c, err)
		return
	}
	f := store.ResourceFilter{ExternalID: c.Query("external_id"), ResourceTypeID: c.Query("resource_type_id"), ParentID: c.Query("parent_id")}
	items, err := store.ListResources(c.Request.Context(), s.engine.DB(), sid, f, page(c))
	if err != nil {
		failErr(c, err)
		return
	}
	list(c, items)
}

func (s *Server) getResource(c *gin.Context) {
	rid, okID := pathID(c)
	if !okID {
		return
	}
	r, err := store.GetResource(c.Request.Context(), s.engine.DB(), rid)
	if err != nil {
		failErr(c, err)
		return
	}
	if p := principalOf(c); p.kind == kindCredential && (p.cred.ServiceID != r.ServiceID || !hasScope(p.cred, ScopeResourceRead)) {
		fail(c, 404, "not_found", "object not found")
		return
	}
	ok(c, 200, r)
}

// createResource creates a resource under parent_id (defaults to the service root).
func (s *Server) createResource(c *gin.Context) {
	sid, okID := pathID(c)
	if !okID {
		return
	}
	if !credentialAllows(c, sid, ScopeResourceWrite) {
		return
	}
	var body struct {
		ResourceTypeID string  `json:"resource_type_id"`
		ParentID       *string `json:"parent_id"`
		ExternalID     string  `json:"external_id"`
		ExternalKey    *string `json:"external_key"`
		DisplayName    string  `json:"display_name"`
		Description    string  `json:"description"`
	}
	if !bind(c, &body) {
		return
	}
	body.ExternalID = strings.TrimSpace(body.ExternalID)
	if body.ExternalID == "" || len(body.ExternalID) > 255 {
		fail(c, 400, "invalid_request", "external_id is required (max 255 chars)")
		return
	}
	if body.ExternalID == store.RootExternalID {
		fail(c, 400, "invalid_request", store.RootExternalID+" is reserved")
		return
	}
	if !id.Valid(body.ResourceTypeID) {
		fail(c, 400, "invalid_request", "resource_type_id must be a ULID")
		return
	}
	if body.ParentID != nil && !id.Valid(*body.ParentID) {
		fail(c, 400, "invalid_request", "parent_id must be a ULID")
		return
	}
	body.ExternalKey = trimPtr(body.ExternalKey)
	if body.ExternalKey != nil && *body.ExternalKey == "" {
		body.ExternalKey = nil
	}
	r := &store.Resource{ID: id.New(), ServiceID: sid, ResourceTypeID: body.ResourceTypeID, ParentID: body.ParentID,
		ExternalID: body.ExternalID, ExternalKey: body.ExternalKey, DisplayName: body.DisplayName, Description: body.Description, Status: store.StatusActive}
	if r.DisplayName == "" {
		r.DisplayName = r.ExternalID
	}
	_, err := s.write(c, func(w *policy.Writer) error {
		if _, err := store.GetService(w.Ctx(), w.Tx, sid); err != nil {
			return err
		}
		rt, err := store.GetResourceType(w.Ctx(), w.Tx, body.ResourceTypeID)
		if err != nil || rt.ServiceID != sid {
			return errInvalid("resource_type_id does not belong to this service")
		}
		if rt.TypeKey == store.RootTypeKey {
			return errInvalid("resources of type " + store.RootTypeKey + " cannot be created")
		}
		if r.ParentID == nil {
			root, err := store.GetRootResource(w.Ctx(), w.Tx, sid)
			if err != nil {
				return err
			}
			r.ParentID = &root.ID
		}
		if err := store.CreateResource(w.Ctx(), w.Tx, r); err != nil {
			return err
		}
		return w.Audit("resource.create", "resource", r.ID, nil, r)
	})
	if err != nil {
		failErr(c, err)
		return
	}
	s.reply(c, 201, func() (any, error) { return store.GetResource(c.Request.Context(), s.engine.DB(), r.ID) })
}

func (s *Server) patchResource(c *gin.Context) {
	rid, okID := pathID(c)
	if !okID {
		return
	}
	var body patchBody
	if !bind(c, &body) {
		return
	}
	isAdmin := principalOf(c).kind == kindAdmin
	p, okP := body.toPatch(c, isAdmin, true)
	if !okP {
		return
	}
	p.ExternalKey = trimPtr(p.ExternalKey)
	var out *store.Resource
	_, err := s.write(c, func(w *policy.Writer) error {
		before, err := store.GetResource(w.Ctx(), w.Tx, rid)
		if err != nil {
			return err
		}
		if !isAdmin {
			if pr := principalOf(c); pr.cred.ServiceID != before.ServiceID || !hasScope(pr.cred, ScopeResourceWrite) {
				return errForbidden
			}
		}
		if before.ExternalID == store.RootExternalID {
			if !isAdmin {
				return errForbidden
			}
			if p.Status != nil && *p.Status != store.StatusActive {
				return errInvalid("the service root resource cannot be disabled")
			}
		}
		if out, err = store.UpdateResource(w.Ctx(), w.Tx, rid, p); err != nil {
			return err
		}
		return w.Audit("resource.update", "resource", rid, before, out)
	})
	if err != nil {
		if err == errForbidden {
			fail(c, 403, "forbidden", "credential may not modify this resource")
			return
		}
		failErr(c, err)
		return
	}
	ok(c, 200, out)
}

func (s *Server) deleteResource(c *gin.Context) {
	rid, okID := pathID(c)
	if !okID {
		return
	}
	s.deleteWith(c, "resource", rid, func(w *policy.Writer) (any, error) {
		before, err := store.GetResource(w.Ctx(), w.Tx, rid)
		if err != nil {
			return nil, err
		}
		if before.ExternalID == store.RootExternalID {
			return nil, errInvalid("the service root resource cannot be deleted")
		}
		return before, store.DeleteResource(w.Ctx(), w.Tx, rid)
	})
}
