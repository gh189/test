package httpapi

import (
	"crypto/sha256"
	"crypto/subtle"
	"net/http"
	"runtime/debug"
	"strings"
	"time"

	"github.com/gin-gonic/gin"

	"github.com/tongjie/authzie/internal/id"
	"github.com/tongjie/authzie/internal/store"
)

type principalKind int

const (
	kindNone principalKind = iota
	kindAdmin
	kindCredential
)

type principal struct {
	kind  principalKind
	uid   string            // admin LDAP uid
	cred  *store.Credential // business credential
	token string            // session token (admin)
}

func principalOf(c *gin.Context) principal {
	if v, ok := c.Get("principal"); ok {
		return v.(principal)
	}
	return principal{}
}

func (s *Server) requestID() gin.HandlerFunc {
	return func(c *gin.Context) {
		rid := strings.TrimSpace(c.GetHeader("X-Request-ID"))
		if rid == "" || len(rid) > 128 {
			rid = id.New()
		}
		c.Set("request_id", rid)
		c.Header("X-Request-ID", rid)
		c.Next()
	}
}

func (s *Server) recovery() gin.HandlerFunc {
	return func(c *gin.Context) {
		defer func() {
			if r := recover(); r != nil {
				s.log.Error("panic recovered", "request_id", requestID(c), "panic", r, "stack", string(debug.Stack()))
				fail(c, 500, "internal_error", "internal error")
			}
		}()
		c.Next()
	}
}

// logging writes one JSON line per request. Headers and bodies are never logged.
func (s *Server) logging() gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()
		c.Next()
		attrs := []any{
			"request_id", requestID(c), "method", c.Request.Method, "path", c.Request.URL.Path,
			"status", c.Writer.Status(), "duration_ms", time.Since(start).Milliseconds(), "remote", c.ClientIP(),
		}
		p := principalOf(c)
		switch p.kind {
		case kindAdmin:
			attrs = append(attrs, "admin_uid", p.uid)
		case kindCredential:
			attrs = append(attrs, "credential_id", p.cred.ID)
		}
		s.log.Info("http", attrs...)
	}
}

// contentRules enforces CSRF header and JSON content type on mutating requests.
// Bearer-authenticated requests are not cookie-bound and therefore skip the CSRF header.
func (s *Server) contentRules() gin.HandlerFunc {
	return func(c *gin.Context) {
		if c.Request.Method == http.MethodGet || c.Request.Method == http.MethodHead {
			c.Next()
			return
		}
		bearer := strings.HasPrefix(c.GetHeader("Authorization"), "Bearer ")
		_, hasCookie := c.Request.Cookie(sessionCookie)
		// Anonymous requests (no cookie, no bearer) fall through to a 401 from the auth layer,
		// except login which is the only anonymous mutating endpoint and must still carry the header.
		cookieBound := hasCookie == nil || strings.HasSuffix(c.Request.URL.Path, "/admin/login")
		if !bearer && cookieBound && c.GetHeader(csrfHeader) != "1" {
			fail(c, 403, "csrf_header_required", "non-GET requests must send "+csrfHeader+": 1")
			return
		}
		if c.Request.ContentLength != 0 {
			ct := c.GetHeader("Content-Type")
			if mt, _, _ := strings.Cut(ct, ";"); strings.TrimSpace(mt) != "application/json" {
				fail(c, 415, "unsupported_media_type", "Content-Type must be application/json")
				return
			}
		}
		c.Next()
	}
}

func (s *Server) authAdmin(c *gin.Context) (principal, bool) {
	tok, err := c.Cookie(sessionCookie)
	if err != nil || tok == "" {
		return principal{}, false
	}
	uid, ok := s.sessions.Lookup(tok)
	if !ok {
		return principal{}, false
	}
	return principal{kind: kindAdmin, uid: uid, token: tok}, true
}

// authCredential validates "Authorization: Bearer authzie_<id>.<secret>".
// Returns (principal, status, code). status 0 means success.
func (s *Server) authCredential(c *gin.Context) (principal, int, string) {
	h := c.GetHeader("Authorization")
	if !strings.HasPrefix(h, "Bearer ") {
		return principal{}, 401, "unauthorized"
	}
	tok := strings.TrimSpace(strings.TrimPrefix(h, "Bearer "))
	if !strings.HasPrefix(tok, "authzie_") {
		return principal{}, 401, "unauthorized"
	}
	credID, secret, found := strings.Cut(strings.TrimPrefix(tok, "authzie_"), ".")
	if !found || !id.Valid(credID) || secret == "" {
		return principal{}, 401, "unauthorized"
	}
	cred, err := store.GetCredential(c.Request.Context(), s.engine.DB(), credID)
	if err != nil {
		return principal{}, 401, "unauthorized"
	}
	sum := sha256.Sum256([]byte(secret))
	if cred.RevokedAt != nil || subtle.ConstantTimeCompare(sum[:], cred.SecretHash) != 1 {
		return principal{}, 401, "unauthorized"
	}
	svc, err := store.GetService(c.Request.Context(), s.engine.DB(), cred.ServiceID)
	if err != nil || svc.Status != store.StatusActive {
		return principal{}, 403, "service_inactive"
	}
	return principal{kind: kindCredential, cred: cred}, 0, ""
}

func hasScope(cred *store.Credential, scope string) bool {
	for _, sc := range cred.Scopes {
		if sc == scope {
			return true
		}
	}
	return false
}

func (s *Server) requireAdmin() gin.HandlerFunc {
	return func(c *gin.Context) {
		p, ok := s.authAdmin(c)
		if !ok {
			fail(c, 401, "unauthorized", "administrator session required")
			return
		}
		c.Set("principal", p)
		c.Next()
	}
}

func (s *Server) requireCredential(scope string) gin.HandlerFunc {
	return func(c *gin.Context) {
		p, status, code := s.authCredential(c)
		if status != 0 {
			fail(c, status, code, "valid service credential required")
			return
		}
		if !hasScope(p.cred, scope) {
			fail(c, 403, "forbidden", "credential lacks scope "+scope)
			return
		}
		c.Set("principal", p)
		c.Next()
	}
}

// requireAdminOrCredential accepts either principal; handlers apply per-principal rules.
func (s *Server) requireAdminOrCredential() gin.HandlerFunc {
	return func(c *gin.Context) {
		if p, ok := s.authAdmin(c); ok {
			c.Set("principal", p)
			c.Next()
			return
		}
		if strings.HasPrefix(c.GetHeader("Authorization"), "Bearer ") {
			p, status, code := s.authCredential(c)
			if status != 0 {
				fail(c, status, code, "valid service credential required")
				return
			}
			c.Set("principal", p)
			c.Next()
			return
		}
		fail(c, 401, "unauthorized", "authentication required")
	}
}
