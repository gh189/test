package httpapi

import (
	"context"
	"errors"
	"net/http"
	"strings"
	"time"

	"github.com/gin-gonic/gin"

	"github.com/tongjie/authzie/internal/admin"
	"github.com/tongjie/authzie/internal/id"
	"github.com/tongjie/authzie/internal/ldapsync"
	"github.com/tongjie/authzie/internal/policy"
	"github.com/tongjie/authzie/internal/store"
)

func (s *Server) readyz(c *gin.Context) {
	ctx, cancel := context.WithTimeout(c.Request.Context(), 3*time.Second)
	defer cancel()
	if err := s.pinger(ctx); err != nil {
		fail(c, 503, "database_unavailable", "database is unreachable")
		return
	}
	if !s.engine.Ready() {
		fail(c, 503, "policy_not_ready", "policy snapshot is not ready")
		return
	}
	ok(c, 200, gin.H{"status": "ready", "policy_version": s.engine.Revision()})
}

// ---- Administrator auth ----

func (s *Server) adminLogin(c *gin.Context) {
	var body struct {
		UID      string `json:"uid"`
		Password string `json:"password"`
	}
	if !bind(c, &body) {
		return
	}
	body.UID = strings.TrimSpace(body.UID)
	if body.UID == "" || body.Password == "" {
		fail(c, 400, "invalid_request", "uid and password are required")
		return
	}
	ctx, cancel := context.WithTimeout(c.Request.Context(), s.cfg.LDAP.Timeout+2*time.Second)
	defer cancel()
	uid, err := s.ldap.Authenticate(ctx, body.UID, body.Password)
	if err != nil {
		if errors.Is(err, ldapsync.ErrInvalidCredentials) {
			s.auditLogin(c, body.UID, "admin.login_failed")
			fail(c, 401, "invalid_credentials", "invalid uid or password")
			return
		}
		failErr(c, err)
		return
	}
	if !admin.Allowed(uid) {
		s.auditLogin(c, uid, "admin.login_denied")
		fail(c, 403, "forbidden", "account is not an Authzie administrator")
		return
	}
	tok := s.sessions.Create(uid)
	http.SetCookie(c.Writer, &http.Cookie{
		Name: sessionCookie, Value: tok, Path: "/", HttpOnly: true, SameSite: http.SameSiteStrictMode,
		Secure: c.Request.TLS != nil, MaxAge: int(s.cfg.SessionTTL.Seconds()),
	})
	s.auditLogin(c, uid, "admin.login")
	ok(c, 200, gin.H{"uid": uid, "request_id": requestID(c)})
}

// auditLogin records login outcomes directly (no policy revision change).
func (s *Server) auditLogin(c *gin.Context, uid, action string) {
	err := store.InsertAudit(c.Request.Context(), s.engine.DB(), &store.AuditLog{
		ID: id.New(), ActorType: "admin", ActorID: uid, Action: action, ObjectType: "admin_session", ObjectID: uid,
		RequestID: requestID(c),
	})
	if err != nil {
		s.log.Error("audit login", "error", err, "request_id", requestID(c))
	}
}

func (s *Server) adminLogout(c *gin.Context) {
	if tok, err := c.Cookie(sessionCookie); err == nil && tok != "" {
		s.sessions.Delete(tok)
	}
	http.SetCookie(c.Writer, &http.Cookie{Name: sessionCookie, Value: "", Path: "/", HttpOnly: true, SameSite: http.SameSiteStrictMode, MaxAge: -1})
	ok(c, 200, gin.H{"request_id": requestID(c)})
}

func (s *Server) adminMe(c *gin.Context) {
	ok(c, 200, gin.H{"uid": principalOf(c).uid, "version": "1.0.0", "request_id": requestID(c)})
}

// ---- Decision ----

func (s *Server) check(c *gin.Context) {
	var body struct {
		SubjectType string `json:"subject_type"`
		SubjectID   string `json:"subject_id"`
		ResourceID  string `json:"resource_id"`
		Action      string `json:"action"`
	}
	if !bind(c, &body) {
		return
	}
	if body.SubjectType != store.SubjectUser && body.SubjectType != store.SubjectServiceAccount {
		fail(c, 400, "invalid_request", "subject_type must be 'user' or 'service_account'")
		return
	}
	if !id.Valid(body.SubjectID) || !id.Valid(body.ResourceID) || body.Action == "" {
		fail(c, 400, "invalid_request", "subject_id, resource_id (ULID) and action are required")
		return
	}
	d, err := s.engine.Check(c.Request.Context(), policy.Request{
		ServiceID: principalOf(c).cred.ServiceID, SubjectType: body.SubjectType, SubjectID: body.SubjectID,
		ResourceID: body.ResourceID, Action: body.Action,
	})
	if err != nil {
		failErr(c, err)
		return
	}
	ok(c, 200, gin.H{"allowed": d.Allowed, "reason": d.Reason, "policy_version": d.PolicyVersion, "request_id": requestID(c)})
}

// adminCheck lets an administrator simulate a decision for any service. Subject and
// resource may be given by ULID or by external ID; the response echoes what was resolved
// and, on ALLOW, the assignment that granted access.
func (s *Server) adminCheck(c *gin.Context) {
	var body struct {
		ServiceID          string `json:"service_id"`
		SubjectType        string `json:"subject_type"`
		SubjectID          string `json:"subject_id"`
		SubjectExternalID  string `json:"subject_external_id"`
		ResourceID         string `json:"resource_id"`
		ResourceExternalID string `json:"resource_external_id"`
		Action             string `json:"action"`
	}
	if !bind(c, &body) {
		return
	}
	ctx := c.Request.Context()
	db := s.engine.DB()
	if !id.Valid(body.ServiceID) || strings.TrimSpace(body.Action) == "" {
		fail(c, 400, "invalid_request", "service_id (ULID) and action are required")
		return
	}
	if body.SubjectType != store.SubjectUser && body.SubjectType != store.SubjectServiceAccount {
		fail(c, 400, "invalid_request", "subject_type must be 'user' or 'service_account'")
		return
	}
	if _, err := store.GetService(ctx, db, body.ServiceID); err != nil {
		failErr(c, err)
		return
	}

	subject := gin.H{"type": body.SubjectType}
	switch {
	case id.Valid(body.SubjectID):
		subject["id"] = body.SubjectID
	case strings.TrimSpace(body.SubjectExternalID) != "":
		ext := strings.TrimSpace(body.SubjectExternalID)
		if body.SubjectType == store.SubjectUser {
			u, err := store.GetUserByExternalID(ctx, db, ext)
			if err != nil {
				reply404(c, err, "subject_not_found", "user "+ext+" is not in the LDAP mirror")
				return
			}
			body.SubjectID, subject["id"], subject["external_id"], subject["display_name"], subject["status"] = u.ID, u.ID, u.ExternalID, u.DisplayName, u.Status
		} else {
			sa, err := store.GetServiceAccountByExternalID(ctx, db, body.ServiceID, ext)
			if err != nil {
				reply404(c, err, "subject_not_found", "service account "+ext+" does not exist in this service")
				return
			}
			body.SubjectID, subject["id"], subject["external_id"], subject["display_name"], subject["status"] = sa.ID, sa.ID, sa.ExternalID, sa.DisplayName, sa.Status
		}
	default:
		fail(c, 400, "invalid_request", "subject_id or subject_external_id is required")
		return
	}

	resource := gin.H{}
	switch {
	case id.Valid(body.ResourceID):
		resource["id"] = body.ResourceID
	case strings.TrimSpace(body.ResourceExternalID) != "":
		ext := strings.TrimSpace(body.ResourceExternalID)
		items, err := store.ListResources(ctx, db, body.ServiceID, store.ResourceFilter{ExternalID: ext}, store.Page{Limit: 1})
		if err != nil {
			failErr(c, err)
			return
		}
		if len(items) == 0 {
			fail(c, 404, "resource_not_found", "resource "+ext+" does not exist in this service")
			return
		}
		body.ResourceID = items[0].ID
		resource["id"], resource["external_id"], resource["display_name"], resource["status"] = items[0].ID, items[0].ExternalID, items[0].DisplayName, items[0].Status
	default:
		fail(c, 400, "invalid_request", "resource_id or resource_external_id is required")
		return
	}

	d, err := s.engine.Check(ctx, policy.Request{
		ServiceID: body.ServiceID, SubjectType: body.SubjectType, SubjectID: body.SubjectID,
		ResourceID: body.ResourceID, Action: strings.TrimSpace(body.Action),
	})
	if err != nil {
		failErr(c, err)
		return
	}
	ok(c, 200, gin.H{
		"allowed": d.Allowed, "reason": d.Reason, "policy_version": d.PolicyVersion,
		"matched_assignment": d.MatchedAssignment, "subject": subject, "resource": resource,
		"request_id": requestID(c),
	})
}

func reply404(c *gin.Context, err error, code, msg string) {
	if errors.Is(err, store.ErrNotFound) {
		fail(c, 404, code, msg)
		return
	}
	failErr(c, err)
}

// ---- Subject resolution ----

func (s *Server) resolveSubject(c *gin.Context) {
	var body struct {
		SubjectType string `json:"subject_type"`
		ExternalID  string `json:"external_id"`
	}
	if !bind(c, &body) {
		return
	}
	body.ExternalID = strings.TrimSpace(body.ExternalID)
	if body.ExternalID == "" {
		fail(c, 400, "invalid_request", "external_id is required")
		return
	}
	var subjectID, status string
	switch body.SubjectType {
	case store.SubjectUser:
		if !s.engine.Ready() {
			failErr(c, policy.ErrNotReady)
			return
		}
		if s.engine.LDAPStale() {
			failErr(c, policy.ErrLDAPStale)
			return
		}
		u, err := store.GetUserByExternalID(c.Request.Context(), s.engine.DB(), body.ExternalID)
		if err != nil {
			failErr(c, err)
			return
		}
		subjectID, status = u.ID, u.Status
	case store.SubjectServiceAccount:
		sa, err := store.GetServiceAccountByExternalID(c.Request.Context(), s.engine.DB(), principalOf(c).cred.ServiceID, body.ExternalID)
		if err != nil {
			failErr(c, err)
			return
		}
		subjectID, status = sa.ID, sa.Status
	default:
		fail(c, 400, "invalid_request", "subject_type must be 'user' or 'service_account'")
		return
	}
	ok(c, 200, gin.H{"subject_id": subjectID, "status": status, "request_id": requestID(c)})
}

// ---- LDAP mirror (read-only) ----

func (s *Server) listUsers(c *gin.Context) {
	items, err := store.ListUsers(c.Request.Context(), s.engine.DB(), c.Query("q"), page(c))
	if err != nil {
		failErr(c, err)
		return
	}
	list(c, items)
}

func (s *Server) getUser(c *gin.Context) {
	uid, okID := pathID(c)
	if !okID {
		return
	}
	u, err := store.GetUser(c.Request.Context(), s.engine.DB(), uid)
	if err != nil {
		failErr(c, err)
		return
	}
	ok(c, 200, u)
}

func (s *Server) listGroups(c *gin.Context) {
	items, err := store.ListGroups(c.Request.Context(), s.engine.DB(), c.Query("q"), page(c))
	if err != nil {
		failErr(c, err)
		return
	}
	list(c, items)
}

func (s *Server) listGroupMembers(c *gin.Context) {
	gid, okID := pathID(c)
	if !okID {
		return
	}
	if _, err := store.GetGroup(c.Request.Context(), s.engine.DB(), gid); err != nil {
		failErr(c, err)
		return
	}
	items, err := store.ListGroupMembers(c.Request.Context(), s.engine.DB(), gid, page(c))
	if err != nil {
		failErr(c, err)
		return
	}
	list(c, items)
}

// ---- Audit & sync ----

func (s *Server) listAuditLogs(c *gin.Context) {
	f := store.AuditFilter{ObjectType: c.Query("object_type"), ObjectID: c.Query("object_id"), ActorID: c.Query("actor_id")}
	for _, q := range []struct {
		key string
		dst **time.Time
	}{{"from", &f.From}, {"to", &f.To}} {
		if v := c.Query(q.key); v != "" {
			t, err := time.Parse(time.RFC3339, v)
			if err != nil {
				fail(c, 400, "invalid_request", q.key+" must be RFC3339")
				return
			}
			*q.dst = &t
		}
	}
	items, err := store.ListAudit(c.Request.Context(), s.engine.DB(), f, page(c))
	if err != nil {
		failErr(c, err)
		return
	}
	list(c, items)
}

func (s *Server) ldapStatus(c *gin.Context) {
	st, err := s.syncer.Status(c.Request.Context())
	if err != nil {
		failErr(c, err)
		return
	}
	ok(c, 200, st)
}

func (s *Server) ldapRun(c *gin.Context) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
	defer cancel()
	if err := s.syncer.Run(ctx); err != nil {
		if errors.Is(err, ldapsync.ErrSyncInProgress) || errors.Is(err, ldapsync.ErrUnavailable) {
			failErr(c, err)
			return
		}
		fail(c, 502, "ldap_sync_failed", err.Error())
		return
	}
	st, err := s.syncer.Status(c.Request.Context())
	if err != nil {
		failErr(c, err)
		return
	}
	ok(c, 200, st)
}
