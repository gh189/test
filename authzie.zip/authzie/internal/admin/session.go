// Package admin holds the hard-coded administrator allowlist and the server-side session store.
package admin

import (
	"crypto/rand"
	"encoding/base64"
	"sync"
	"time"
)

// Allowlist is the set of LDAP user IDs permitted to manage Authzie.
// 1.0.0 deliberately hard-codes this; changing administrators requires a new release.
var Allowlist = []string{"45020897"}

// Allowed reports whether uid is an administrator.
func Allowed(uid string) bool {
	for _, a := range Allowlist {
		if a == uid {
			return true
		}
	}
	return false
}

type session struct {
	uid     string
	expires time.Time
}

// Sessions is an in-memory session store. Single-replica deployment makes this sufficient.
type Sessions struct {
	ttl time.Duration
	mu  sync.Mutex
	m   map[string]session
}

func NewSessions(ttl time.Duration) *Sessions {
	return &Sessions{ttl: ttl, m: map[string]session{}}
}

// Create issues a new opaque session token for uid.
func (s *Sessions) Create(uid string) string {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		panic(err)
	}
	tok := base64.RawURLEncoding.EncodeToString(b)
	s.mu.Lock()
	defer s.mu.Unlock()
	s.gc()
	s.m[tok] = session{uid: uid, expires: time.Now().Add(s.ttl)}
	return tok
}

// Lookup returns the uid for a valid, unexpired token.
func (s *Sessions) Lookup(tok string) (string, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	sess, ok := s.m[tok]
	if !ok || time.Now().After(sess.expires) {
		delete(s.m, tok)
		return "", false
	}
	return sess.uid, true
}

// Delete revokes a token.
func (s *Sessions) Delete(tok string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	delete(s.m, tok)
}

func (s *Sessions) gc() {
	now := time.Now()
	for k, v := range s.m {
		if now.After(v.expires) {
			delete(s.m, k)
		}
	}
}
