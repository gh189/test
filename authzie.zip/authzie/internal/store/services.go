package store

import (
	"context"
	"fmt"
)

const serviceCols = "id, service_key, display_name, description, status, created_at, updated_at"

func CreateService(ctx context.Context, q Q, s *Service) error {
	return exec(ctx, q, `INSERT INTO services (id, service_key, display_name, description, status)
		VALUES ($1,$2,$3,$4,'active')`, s.ID, s.ServiceKey, s.DisplayName, s.Description)
}

func GetService(ctx context.Context, q Q, id string) (*Service, error) {
	return one[Service](ctx, q, `SELECT `+serviceCols+` FROM services WHERE id=$1 AND status<>'deleted'`, id)
}

func ListServices(ctx context.Context, q Q, p Page) ([]Service, error) {
	l, o := p.norm()
	return many[Service](ctx, q, `SELECT `+serviceCols+` FROM services WHERE status<>'deleted'
		ORDER BY service_key LIMIT $1 OFFSET $2`, l, o)
}

func UpdateService(ctx context.Context, q Q, id string, p StatusPatch) (*Service, error) {
	return one[Service](ctx, q, `UPDATE services SET
		display_name=COALESCE($2,display_name), description=COALESCE($3,description),
		status=COALESCE($4,status), updated_at=now()
		WHERE id=$1 AND status<>'deleted' RETURNING `+serviceCols, id, p.DisplayName, p.Description, p.Status)
}

// DeleteService cascades: all owned objects, credentials and related assignments.
func DeleteService(ctx context.Context, q Q, id string) error {
	stmts := []string{
		`DELETE FROM assignments WHERE (scope_type='service' AND service_id=$1)
			OR (scope_type='resource' AND resource_id IN (SELECT id FROM resources WHERE service_id=$1))
			OR (subject_type='service_account' AND subject_id IN (SELECT id FROM service_accounts WHERE service_id=$1))`,
		`DELETE FROM role_permissions WHERE permission_id IN (SELECT id FROM permissions WHERE service_id=$1)`,
		`DELETE FROM permissions WHERE service_id=$1`,
		`UPDATE credentials SET revoked_at=COALESCE(revoked_at, now()) WHERE service_id=$1`,
		`UPDATE service_accounts SET status='deleted', updated_at=now() WHERE service_id=$1 AND status<>'deleted'`,
		`UPDATE resources SET status='deleted', updated_at=now() WHERE service_id=$1 AND status<>'deleted'`,
		`UPDATE services SET status='deleted', updated_at=now() WHERE id=$1`,
	}
	for _, s := range stmts {
		if err := exec(ctx, q, s, id); err != nil {
			return err
		}
	}
	return nil
}

// ---- Resource types ----

const rtCols = "id, service_id, type_key, display_name, description, created_at, updated_at"

func CreateResourceType(ctx context.Context, q Q, rt *ResourceType) error {
	return exec(ctx, q, `INSERT INTO resource_types (id, service_id, type_key, display_name, description)
		VALUES ($1,$2,$3,$4,$5)`, rt.ID, rt.ServiceID, rt.TypeKey, rt.DisplayName, rt.Description)
}

func GetResourceType(ctx context.Context, q Q, id string) (*ResourceType, error) {
	return one[ResourceType](ctx, q, `SELECT `+rtCols+` FROM resource_types rt WHERE id=$1
		AND EXISTS (SELECT 1 FROM services s WHERE s.id=rt.service_id AND s.status<>'deleted')`, id)
}

func ListResourceTypes(ctx context.Context, q Q, serviceID string, p Page) ([]ResourceType, error) {
	l, o := p.norm()
	return many[ResourceType](ctx, q, `SELECT `+rtCols+` FROM resource_types WHERE service_id=$1
		ORDER BY type_key LIMIT $2 OFFSET $3`, serviceID, l, o)
}

func UpdateResourceType(ctx context.Context, q Q, id string, p StatusPatch) (*ResourceType, error) {
	return one[ResourceType](ctx, q, `UPDATE resource_types SET
		display_name=COALESCE($2,display_name), description=COALESCE($3,description), updated_at=now()
		WHERE id=$1 RETURNING `+rtCols, id, p.DisplayName, p.Description)
}

// DeleteResourceType fails with ErrObjectInUse while live resources or permissions reference it.
func DeleteResourceType(ctx context.Context, q Q, id string) error {
	var n int
	err := q.QueryRow(ctx, `SELECT (SELECT count(*) FROM resources WHERE resource_type_id=$1 AND status<>'deleted')
		+ (SELECT count(*) FROM permissions WHERE resource_type_id=$1)`, id).Scan(&n)
	if err != nil {
		return wrap(err)
	}
	if n > 0 {
		return ErrObjectInUse
	}
	// Deleted resources may still reference the type; drop them so the FK allows removal.
	if err := exec(ctx, q, `DELETE FROM resources WHERE resource_type_id=$1 AND status='deleted'`, id); err != nil {
		return err
	}
	return exec(ctx, q, `DELETE FROM resource_types WHERE id=$1`, id)
}

// ---- Permissions ----

const permCols = "id, service_id, resource_type_id, action, description, created_at"

func CreatePermission(ctx context.Context, q Q, pm *Permission) error {
	return exec(ctx, q, `INSERT INTO permissions (id, service_id, resource_type_id, action, description)
		VALUES ($1,$2,$3,$4,$5)`, pm.ID, pm.ServiceID, pm.ResourceTypeID, pm.Action, pm.Description)
}

func GetPermission(ctx context.Context, q Q, id string) (*Permission, error) {
	return one[Permission](ctx, q, `SELECT `+permCols+` FROM permissions WHERE id=$1`, id)
}

func ListPermissions(ctx context.Context, q Q, serviceID string, p Page) ([]Permission, error) {
	l, o := p.norm()
	return many[Permission](ctx, q, `SELECT `+permCols+` FROM permissions WHERE service_id=$1
		ORDER BY resource_type_id, action LIMIT $2 OFFSET $3`, serviceID, l, o)
}

// DeletePermission also removes role-permission links (FK cascade).
func DeletePermission(ctx context.Context, q Q, id string) error {
	return exec(ctx, q, `DELETE FROM permissions WHERE id=$1`, id)
}

// ValidateKey checks natural keys such as service_key, type_key, action and role name.
func ValidateKey(v string) error {
	if len(v) == 0 || len(v) > 64 {
		return fmt.Errorf("%w: key must be 1-64 characters", ErrInvalid)
	}
	for _, r := range v {
		ok := r == '_' || r == '-' || (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9')
		if !ok {
			return fmt.Errorf("%w: key may contain only a-z, 0-9, '_' and '-'", ErrInvalid)
		}
	}
	return nil
}
