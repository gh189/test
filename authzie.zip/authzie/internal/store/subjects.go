package store

import (
	"context"
	"fmt"
	"time"
)

// ---- Users / Groups (LDAP mirror, read-only via API) ----

const userCols = "id, external_id, dn, display_name, status, present, created_at, updated_at"
const groupCols = "id, external_id, dn, display_name, status, created_at, updated_at"

func GetUser(ctx context.Context, q Q, id string) (*User, error) {
	return one[User](ctx, q, `SELECT `+userCols+` FROM users WHERE id=$1`, id)
}

func GetUserByExternalID(ctx context.Context, q Q, ext string) (*User, error) {
	return one[User](ctx, q, `SELECT `+userCols+` FROM users WHERE external_id=$1`, ext)
}

func ListUsers(ctx context.Context, q Q, search string, p Page) ([]User, error) {
	l, o := p.norm()
	return many[User](ctx, q, `SELECT `+userCols+` FROM users
		WHERE $1='' OR external_id ILIKE '%'||$1||'%' OR display_name ILIKE '%'||$1||'%'
		ORDER BY external_id LIMIT $2 OFFSET $3`, search, l, o)
}

func ListGroups(ctx context.Context, q Q, search string, p Page) ([]Group, error) {
	l, o := p.norm()
	return many[Group](ctx, q, `SELECT `+groupCols+` FROM groups
		WHERE $1='' OR external_id ILIKE '%'||$1||'%' OR display_name ILIKE '%'||$1||'%'
		ORDER BY external_id LIMIT $2 OFFSET $3`, search, l, o)
}

func GetGroup(ctx context.Context, q Q, id string) (*Group, error) {
	return one[Group](ctx, q, `SELECT `+groupCols+` FROM groups WHERE id=$1`, id)
}

func ListGroupMembers(ctx context.Context, q Q, groupID string, p Page) ([]User, error) {
	l, o := p.norm()
	return many[User](ctx, q, `SELECT u.id, u.external_id, u.dn, u.display_name, u.status, u.present, u.created_at, u.updated_at
		FROM group_members gm JOIN users u ON u.id=gm.user_id WHERE gm.group_id=$1
		ORDER BY u.external_id LIMIT $2 OFFSET $3`, groupID, l, o)
}

// MirrorUser is one user as observed in LDAP.
type MirrorUser struct {
	ExternalID  string
	DN          string
	DisplayName string
	Disabled    bool
}

// MirrorGroup is one group as observed in LDAP, with resolved member external IDs.
type MirrorGroup struct {
	ExternalID  string
	DN          string
	DisplayName string
	MemberIDs   []string
}

// MirrorChange records one user/group status transition caused by a sync.
type MirrorChange struct {
	ObjectType string `json:"object_type"`
	ObjectID   string `json:"object_id"`
	ExternalID string `json:"external_id"`
	From       string `json:"from"`
	To         string `json:"to"`
}

// CountActiveUsers returns the number of users present in the last published mirror.
func CountActiveUsers(ctx context.Context, q Q) (int, error) {
	var n int
	err := q.QueryRow(ctx, `SELECT count(*) FROM users WHERE present`).Scan(&n)
	return n, wrap(err)
}

// ApplyMirror atomically replaces the LDAP mirror. Users keep their internal ID across
// disappearance and reappearance; groups are keyed by external_id the same way.
func ApplyMirror(ctx context.Context, q Q, users []MirrorUser, groups []MirrorGroup, newID func() string) ([]MirrorChange, error) {
	var changes []MirrorChange

	existingUsers, err := many[User](ctx, q, `SELECT `+userCols+` FROM users`)
	if err != nil {
		return nil, err
	}
	byExt := map[string]*User{}
	for i := range existingUsers {
		byExt[existingUsers[i].ExternalID] = &existingUsers[i]
	}
	seen := map[string]bool{}
	for _, u := range users {
		status := StatusActive
		if u.Disabled {
			status = StatusInactive
		}
		seen[u.ExternalID] = true
		if cur, ok := byExt[u.ExternalID]; ok {
			if cur.Status != status {
				changes = append(changes, MirrorChange{"user", cur.ID, u.ExternalID, cur.Status, status})
			}
			if err := exec(ctx, q, `UPDATE users SET dn=$2, display_name=$3, status=$4, present=TRUE, updated_at=now() WHERE id=$1`,
				cur.ID, u.DN, u.DisplayName, status); err != nil {
				return nil, err
			}
			continue
		}
		uid := newID()
		if err := exec(ctx, q, `INSERT INTO users (id, external_id, dn, display_name, status, present) VALUES ($1,$2,$3,$4,$5,TRUE)`,
			uid, u.ExternalID, u.DN, u.DisplayName, status); err != nil {
			return nil, err
		}
		changes = append(changes, MirrorChange{"user", uid, u.ExternalID, "", status})
	}
	for ext, cur := range byExt {
		if seen[ext] {
			continue
		}
		if cur.Status != StatusInactive || cur.Present {
			if cur.Status != StatusInactive {
				changes = append(changes, MirrorChange{"user", cur.ID, ext, cur.Status, StatusInactive})
			}
			if err := exec(ctx, q, `UPDATE users SET status='inactive', present=FALSE, updated_at=now() WHERE id=$1`, cur.ID); err != nil {
				return nil, err
			}
		}
	}

	existingGroups, err := many[Group](ctx, q, `SELECT `+groupCols+` FROM groups`)
	if err != nil {
		return nil, err
	}
	gByExt := map[string]*Group{}
	for i := range existingGroups {
		gByExt[existingGroups[i].ExternalID] = &existingGroups[i]
	}
	gSeen := map[string]bool{}
	if err := exec(ctx, q, `DELETE FROM group_members`); err != nil {
		return nil, err
	}
	for _, g := range groups {
		gSeen[g.ExternalID] = true
		var gid string
		if cur, ok := gByExt[g.ExternalID]; ok {
			gid = cur.ID
			if cur.Status != StatusActive {
				changes = append(changes, MirrorChange{"group", gid, g.ExternalID, cur.Status, StatusActive})
			}
			if err := exec(ctx, q, `UPDATE groups SET dn=$2, display_name=$3, status='active', updated_at=now() WHERE id=$1`,
				gid, g.DN, g.DisplayName); err != nil {
				return nil, err
			}
		} else {
			gid = newID()
			if err := exec(ctx, q, `INSERT INTO groups (id, external_id, dn, display_name, status) VALUES ($1,$2,$3,$4,'active')`,
				gid, g.ExternalID, g.DN, g.DisplayName); err != nil {
				return nil, err
			}
			changes = append(changes, MirrorChange{"group", gid, g.ExternalID, "", StatusActive})
		}
		if len(g.MemberIDs) > 0 {
			if err := exec(ctx, q, `INSERT INTO group_members (group_id, user_id)
				SELECT $1, id FROM users WHERE external_id = ANY($2) ON CONFLICT DO NOTHING`, gid, g.MemberIDs); err != nil {
				return nil, err
			}
		}
	}
	for ext, cur := range gByExt {
		if gSeen[ext] || cur.Status == StatusInactive {
			continue
		}
		changes = append(changes, MirrorChange{"group", cur.ID, ext, cur.Status, StatusInactive})
		if err := exec(ctx, q, `UPDATE groups SET status='inactive', updated_at=now() WHERE id=$1`, cur.ID); err != nil {
			return nil, err
		}
	}
	return changes, nil
}

func GetLDAPSyncState(ctx context.Context, q Q) (*LDAPSyncState, error) {
	return one[LDAPSyncState](ctx, q, `SELECT last_success_started_at, last_attempt_at, last_error, last_summary FROM ldap_sync_state WHERE id=1`)
}

func RecordLDAPSuccess(ctx context.Context, q Q, startedAt time.Time, summary any) error {
	return exec(ctx, q, `UPDATE ldap_sync_state SET last_success_started_at=$1, last_attempt_at=$1, last_error='', last_summary=$2 WHERE id=1`,
		startedAt, summary)
}

func RecordLDAPFailure(ctx context.Context, q Q, attemptedAt time.Time, msg string) error {
	return exec(ctx, q, `UPDATE ldap_sync_state SET last_attempt_at=$1, last_error=$2 WHERE id=1`, attemptedAt, msg)
}

// ---- Service accounts ----

const saCols = "id, service_id, external_id, display_name, description, status, created_at, updated_at"

func CreateServiceAccount(ctx context.Context, q Q, sa *ServiceAccount) error {
	return exec(ctx, q, `INSERT INTO service_accounts (id, service_id, external_id, display_name, description, status)
		VALUES ($1,$2,$3,$4,$5,'active')`, sa.ID, sa.ServiceID, sa.ExternalID, sa.DisplayName, sa.Description)
}

func GetServiceAccount(ctx context.Context, q Q, id string) (*ServiceAccount, error) {
	return one[ServiceAccount](ctx, q, `SELECT `+saCols+` FROM service_accounts WHERE id=$1 AND status<>'deleted'`, id)
}

func GetServiceAccountByExternalID(ctx context.Context, q Q, serviceID, ext string) (*ServiceAccount, error) {
	return one[ServiceAccount](ctx, q, `SELECT `+saCols+` FROM service_accounts WHERE service_id=$1 AND external_id=$2 AND status<>'deleted'`, serviceID, ext)
}

func ListServiceAccounts(ctx context.Context, q Q, serviceID string, p Page) ([]ServiceAccount, error) {
	l, o := p.norm()
	return many[ServiceAccount](ctx, q, `SELECT `+saCols+` FROM service_accounts WHERE service_id=$1 AND status<>'deleted'
		ORDER BY external_id LIMIT $2 OFFSET $3`, serviceID, l, o)
}

func UpdateServiceAccount(ctx context.Context, q Q, id string, p StatusPatch) (*ServiceAccount, error) {
	return one[ServiceAccount](ctx, q, `UPDATE service_accounts SET display_name=COALESCE($2,display_name),
		description=COALESCE($3,description), status=COALESCE($4,status), updated_at=now()
		WHERE id=$1 AND status<>'deleted' RETURNING `+saCols, id, p.DisplayName, p.Description, p.Status)
}

func DeleteServiceAccount(ctx context.Context, q Q, id string) error {
	if err := exec(ctx, q, `DELETE FROM assignments WHERE subject_type='service_account' AND subject_id=$1`, id); err != nil {
		return err
	}
	return exec(ctx, q, `UPDATE service_accounts SET status='deleted', updated_at=now() WHERE id=$1 AND status<>'deleted'`, id)
}

// ---- Credentials ----

const credCols = "id, service_id, name, secret_hash, scopes, created_at, revoked_at"

func CreateCredential(ctx context.Context, q Q, c *Credential) error {
	return exec(ctx, q, `INSERT INTO credentials (id, service_id, name, secret_hash, scopes) VALUES ($1,$2,$3,$4,$5)`,
		c.ID, c.ServiceID, c.Name, c.SecretHash, c.Scopes)
}

// GetCredential returns any credential including revoked ones; callers check RevokedAt.
func GetCredential(ctx context.Context, q Q, id string) (*Credential, error) {
	return one[Credential](ctx, q, `SELECT `+credCols+` FROM credentials WHERE id=$1`, id)
}

func ListCredentials(ctx context.Context, q Q, serviceID string, p Page) ([]Credential, error) {
	l, o := p.norm()
	return many[Credential](ctx, q, `SELECT `+credCols+` FROM credentials WHERE service_id=$1 AND revoked_at IS NULL
		ORDER BY created_at LIMIT $2 OFFSET $3`, serviceID, l, o)
}

func RevokeCredential(ctx context.Context, q Q, id string) error {
	return exec(ctx, q, `UPDATE credentials SET revoked_at=now() WHERE id=$1 AND revoked_at IS NULL`, id)
}

// ---- Assignments ----

const asgCols = "id, subject_type, subject_id, role_id, scope_type, service_id, resource_id, include_descendants, created_at"

// CreateAssignment validates the subject, role and scope, normalizes scope fields and inserts.
func CreateAssignment(ctx context.Context, q Q, a *Assignment) error {
	var exists bool
	var err error
	switch a.SubjectType {
	case SubjectUser:
		err = q.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM users WHERE id=$1)`, a.SubjectID).Scan(&exists)
	case SubjectGroup:
		err = q.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM groups WHERE id=$1)`, a.SubjectID).Scan(&exists)
	case SubjectServiceAccount:
		err = q.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM service_accounts WHERE id=$1 AND status<>'deleted')`, a.SubjectID).Scan(&exists)
	default:
		return fmt.Errorf("%w: invalid subject_type", ErrInvalid)
	}
	if err != nil {
		return wrap(err)
	}
	if !exists {
		return fmt.Errorf("%w: subject not found", ErrInvalid)
	}
	if _, err := GetRole(ctx, q, a.RoleID); err != nil {
		return fmt.Errorf("%w: role not found", ErrInvalid)
	}
	switch a.ScopeType {
	case ScopeTenant:
		a.ServiceID, a.ResourceID, a.IncludeDescendants = "", "", false
	case ScopeService:
		if _, err := GetService(ctx, q, a.ServiceID); err != nil {
			return fmt.Errorf("%w: service not found", ErrInvalid)
		}
		a.ResourceID, a.IncludeDescendants = "", false
	case ScopeResource:
		if _, err := GetResource(ctx, q, a.ResourceID); err != nil {
			return fmt.Errorf("%w: resource not found", ErrInvalid)
		}
		a.ServiceID = ""
	default:
		return fmt.Errorf("%w: invalid scope_type", ErrInvalid)
	}
	return exec(ctx, q, `INSERT INTO assignments (id, subject_type, subject_id, role_id, scope_type, service_id, resource_id, include_descendants)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`, a.ID, a.SubjectType, a.SubjectID, a.RoleID, a.ScopeType, a.ServiceID, a.ResourceID, a.IncludeDescendants)
}

func GetAssignment(ctx context.Context, q Q, id string) (*Assignment, error) {
	return one[Assignment](ctx, q, `SELECT `+asgCols+` FROM assignments WHERE id=$1`, id)
}

type AssignmentFilter struct {
	SubjectType string
	SubjectID   string
	RoleID      string
	ScopeType   string
	ServiceID   string
	ResourceID  string
}

func ListAssignments(ctx context.Context, q Q, f AssignmentFilter, p Page) ([]Assignment, error) {
	l, o := p.norm()
	return many[Assignment](ctx, q, `SELECT `+asgCols+` FROM assignments WHERE
		($1='' OR subject_type=$1) AND ($2='' OR subject_id=$2) AND ($3='' OR role_id=$3)
		AND ($4='' OR scope_type=$4) AND ($5='' OR service_id=$5) AND ($6='' OR resource_id=$6)
		ORDER BY created_at DESC LIMIT $7 OFFSET $8`, f.SubjectType, f.SubjectID, f.RoleID, f.ScopeType, f.ServiceID, f.ResourceID, l, o)
}

func DeleteAssignment(ctx context.Context, q Q, id string) error {
	return exec(ctx, q, `DELETE FROM assignments WHERE id=$1`, id)
}

// ---- Audit ----

func InsertAudit(ctx context.Context, q Q, a *AuditLog) error {
	return exec(ctx, q, `INSERT INTO audit_logs (id, actor_type, actor_id, action, object_type, object_id, before, after, request_id)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`, a.ID, a.ActorType, a.ActorID, a.Action, a.ObjectType, a.ObjectID, a.Before, a.After, a.RequestID)
}

type AuditFilter struct {
	ObjectType string
	ObjectID   string
	ActorID    string
	From       *time.Time
	To         *time.Time
}

func ListAudit(ctx context.Context, q Q, f AuditFilter, p Page) ([]AuditLog, error) {
	l, o := p.norm()
	return many[AuditLog](ctx, q, `SELECT id, actor_type, actor_id, action, object_type, object_id, before, after, request_id, created_at
		FROM audit_logs WHERE ($1='' OR object_type=$1) AND ($2='' OR object_id=$2) AND ($3='' OR actor_id=$3)
		AND ($4::timestamptz IS NULL OR created_at >= $4) AND ($5::timestamptz IS NULL OR created_at <= $5)
		ORDER BY created_at DESC LIMIT $6 OFFSET $7`, f.ObjectType, f.ObjectID, f.ActorID, f.From, f.To, l, o)
}

// BumpRevision increments the policy revision inside the write transaction.
func BumpRevision(ctx context.Context, q Q) (int64, error) {
	var rev int64
	err := q.QueryRow(ctx, `UPDATE policy_state SET revision=revision+1 WHERE id=1 RETURNING revision`).Scan(&rev)
	return rev, wrap(err)
}

func GetRevision(ctx context.Context, q Q) (int64, error) {
	var rev int64
	err := q.QueryRow(ctx, `SELECT revision FROM policy_state WHERE id=1`).Scan(&rev)
	return rev, wrap(err)
}
