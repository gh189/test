package store

import (
	"context"
	"time"
)

// Dump is everything the policy engine needs to build one immutable snapshot.
type Dump struct {
	Revision        int64
	Services        []Service
	Permissions     []Permission
	Resources       []Resource
	Roles           []Role
	RolePermissions []RolePermission
	Users           []User
	Groups          []Group
	GroupMembers    []GroupMember
	ServiceAccounts []ServiceAccount
	Assignments     []Assignment
	LDAPSyncedAt    *time.Time
}

// LoadDump reads all live policy data in one consistent pass.
func LoadDump(ctx context.Context, q Q) (*Dump, error) {
	d := &Dump{}
	var err error
	if d.Revision, err = GetRevision(ctx, q); err != nil {
		return nil, err
	}
	if d.Services, err = many[Service](ctx, q, `SELECT `+serviceCols+` FROM services WHERE status<>'deleted'`); err != nil {
		return nil, err
	}
	if d.Permissions, err = many[Permission](ctx, q, `SELECT `+permCols+` FROM permissions`); err != nil {
		return nil, err
	}
	if d.Resources, err = many[Resource](ctx, q, `SELECT `+resCols+` FROM resources WHERE status<>'deleted'`); err != nil {
		return nil, err
	}
	if d.Roles, err = many[Role](ctx, q, `SELECT `+roleCols+` FROM roles WHERE status<>'deleted'`); err != nil {
		return nil, err
	}
	if d.RolePermissions, err = many[RolePermission](ctx, q, `SELECT role_id, permission_id FROM role_permissions`); err != nil {
		return nil, err
	}
	if d.Users, err = many[User](ctx, q, `SELECT `+userCols+` FROM users`); err != nil {
		return nil, err
	}
	if d.Groups, err = many[Group](ctx, q, `SELECT `+groupCols+` FROM groups`); err != nil {
		return nil, err
	}
	if d.GroupMembers, err = many[GroupMember](ctx, q, `SELECT group_id, user_id FROM group_members`); err != nil {
		return nil, err
	}
	if d.ServiceAccounts, err = many[ServiceAccount](ctx, q, `SELECT `+saCols+` FROM service_accounts WHERE status<>'deleted'`); err != nil {
		return nil, err
	}
	if d.Assignments, err = many[Assignment](ctx, q, `SELECT `+asgCols+` FROM assignments`); err != nil {
		return nil, err
	}
	st, err := GetLDAPSyncState(ctx, q)
	if err != nil {
		return nil, err
	}
	d.LDAPSyncedAt = st.LastSuccessStartedAt
	return d, nil
}
