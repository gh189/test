// Package store is the repository layer. All database access goes through it.
package store

import (
	"context"
	"errors"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
)

// Q is satisfied by *pgxpool.Pool and pgx.Tx.
type Q interface {
	Exec(ctx context.Context, sql string, args ...any) (pgconn.CommandTag, error)
	Query(ctx context.Context, sql string, args ...any) (pgx.Rows, error)
	QueryRow(ctx context.Context, sql string, args ...any) pgx.Row
}

var (
	ErrNotFound      = errors.New("not_found")
	ErrAlreadyExists = errors.New("already_exists")
	ErrObjectDeleted = errors.New("object_deleted")
	ErrObjectInUse   = errors.New("object_in_use")
	ErrInvalid       = errors.New("invalid")
)

const (
	StatusActive   = "active"
	StatusInactive = "inactive"
	StatusDeleted  = "deleted"

	SubjectUser           = "user"
	SubjectGroup          = "group"
	SubjectServiceAccount = "service_account"

	ScopeTenant   = "tenant"
	ScopeService  = "service"
	ScopeResource = "resource"

	RootTypeKey    = "service_root"
	RootExternalID = "authzie:root"
	MaxDepth       = 32
)

type Service struct {
	ID          string    `db:"id" json:"id"`
	ServiceKey  string    `db:"service_key" json:"service_key"`
	DisplayName string    `db:"display_name" json:"display_name"`
	Description string    `db:"description" json:"description"`
	Status      string    `db:"status" json:"status"`
	CreatedAt   time.Time `db:"created_at" json:"created_at"`
	UpdatedAt   time.Time `db:"updated_at" json:"updated_at"`
}

type ResourceType struct {
	ID          string    `db:"id" json:"id"`
	ServiceID   string    `db:"service_id" json:"service_id"`
	TypeKey     string    `db:"type_key" json:"type_key"`
	DisplayName string    `db:"display_name" json:"display_name"`
	Description string    `db:"description" json:"description"`
	CreatedAt   time.Time `db:"created_at" json:"created_at"`
	UpdatedAt   time.Time `db:"updated_at" json:"updated_at"`
}

type Permission struct {
	ID             string    `db:"id" json:"id"`
	ServiceID      string    `db:"service_id" json:"service_id"`
	ResourceTypeID string    `db:"resource_type_id" json:"resource_type_id"`
	Action         string    `db:"action" json:"action"`
	Description    string    `db:"description" json:"description"`
	CreatedAt      time.Time `db:"created_at" json:"created_at"`
}

type Resource struct {
	ID             string    `db:"id" json:"id"`
	ServiceID      string    `db:"service_id" json:"service_id"`
	ResourceTypeID string    `db:"resource_type_id" json:"resource_type_id"`
	ParentID       *string   `db:"parent_id" json:"parent_id"`
	ExternalID     string    `db:"external_id" json:"external_id"`
	ExternalKey    *string   `db:"external_key" json:"external_key"`
	DisplayName    string    `db:"display_name" json:"display_name"`
	Description    string    `db:"description" json:"description"`
	Status         string    `db:"status" json:"status"`
	Depth          int       `db:"depth" json:"depth"`
	CreatedAt      time.Time `db:"created_at" json:"created_at"`
	UpdatedAt      time.Time `db:"updated_at" json:"updated_at"`
}

type Role struct {
	ID          string    `db:"id" json:"id"`
	Name        string    `db:"name" json:"name"`
	DisplayName string    `db:"display_name" json:"display_name"`
	Description string    `db:"description" json:"description"`
	Status      string    `db:"status" json:"status"`
	CreatedAt   time.Time `db:"created_at" json:"created_at"`
	UpdatedAt   time.Time `db:"updated_at" json:"updated_at"`
}

type RolePermission struct {
	RoleID       string `db:"role_id"`
	PermissionID string `db:"permission_id"`
}

type User struct {
	ID          string    `db:"id" json:"id"`
	ExternalID  string    `db:"external_id" json:"external_id"`
	DN          string    `db:"dn" json:"dn"`
	DisplayName string    `db:"display_name" json:"display_name"`
	Status      string    `db:"status" json:"status"`
	Present     bool      `db:"present" json:"present"`
	CreatedAt   time.Time `db:"created_at" json:"created_at"`
	UpdatedAt   time.Time `db:"updated_at" json:"updated_at"`
}

type Group struct {
	ID          string    `db:"id" json:"id"`
	ExternalID  string    `db:"external_id" json:"external_id"`
	DN          string    `db:"dn" json:"dn"`
	DisplayName string    `db:"display_name" json:"display_name"`
	Status      string    `db:"status" json:"status"`
	CreatedAt   time.Time `db:"created_at" json:"created_at"`
	UpdatedAt   time.Time `db:"updated_at" json:"updated_at"`
}

type GroupMember struct {
	GroupID string `db:"group_id"`
	UserID  string `db:"user_id"`
}

type ServiceAccount struct {
	ID          string    `db:"id" json:"id"`
	ServiceID   string    `db:"service_id" json:"service_id"`
	ExternalID  string    `db:"external_id" json:"external_id"`
	DisplayName string    `db:"display_name" json:"display_name"`
	Description string    `db:"description" json:"description"`
	Status      string    `db:"status" json:"status"`
	CreatedAt   time.Time `db:"created_at" json:"created_at"`
	UpdatedAt   time.Time `db:"updated_at" json:"updated_at"`
}

type Credential struct {
	ID         string     `db:"id" json:"id"`
	ServiceID  string     `db:"service_id" json:"service_id"`
	Name       string     `db:"name" json:"name"`
	SecretHash []byte     `db:"secret_hash" json:"-"`
	Scopes     []string   `db:"scopes" json:"scopes"`
	CreatedAt  time.Time  `db:"created_at" json:"created_at"`
	RevokedAt  *time.Time `db:"revoked_at" json:"revoked_at"`
}

type Assignment struct {
	ID                 string    `db:"id" json:"id"`
	SubjectType        string    `db:"subject_type" json:"subject_type"`
	SubjectID          string    `db:"subject_id" json:"subject_id"`
	RoleID             string    `db:"role_id" json:"role_id"`
	ScopeType          string    `db:"scope_type" json:"scope_type"`
	ServiceID          string    `db:"service_id" json:"service_id,omitempty"`
	ResourceID         string    `db:"resource_id" json:"resource_id,omitempty"`
	IncludeDescendants bool      `db:"include_descendants" json:"include_descendants"`
	CreatedAt          time.Time `db:"created_at" json:"created_at"`
}

type AuditLog struct {
	ID         string    `db:"id" json:"id"`
	ActorType  string    `db:"actor_type" json:"actor_type"`
	ActorID    string    `db:"actor_id" json:"actor_id"`
	Action     string    `db:"action" json:"action"`
	ObjectType string    `db:"object_type" json:"object_type"`
	ObjectID   string    `db:"object_id" json:"object_id"`
	Before     any       `db:"before" json:"before"`
	After      any       `db:"after" json:"after"`
	RequestID  string    `db:"request_id" json:"request_id"`
	CreatedAt  time.Time `db:"created_at" json:"created_at"`
}

type LDAPSyncState struct {
	LastSuccessStartedAt *time.Time `db:"last_success_started_at" json:"last_success_started_at"`
	LastAttemptAt        *time.Time `db:"last_attempt_at" json:"last_attempt_at"`
	LastError            string     `db:"last_error" json:"last_error"`
	LastSummary          any        `db:"last_summary" json:"last_summary"`
}

// Page bounds list queries.
type Page struct {
	Limit  int
	Offset int
}

func (p Page) norm() (int, int) {
	l := p.Limit
	if l <= 0 || l > 1000 {
		l = 100
	}
	o := p.Offset
	if o < 0 {
		o = 0
	}
	return l, o
}

// wrap converts pgx errors to store errors.
func wrap(err error) error {
	if err == nil {
		return nil
	}
	if errors.Is(err, pgx.ErrNoRows) {
		return ErrNotFound
	}
	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) {
		switch pgErr.Code {
		case "23505":
			return ErrAlreadyExists
		case "23503":
			return ErrObjectInUse
		}
	}
	return err
}

func one[T any](ctx context.Context, q Q, sql string, args ...any) (*T, error) {
	rows, err := q.Query(ctx, sql, args...)
	if err != nil {
		return nil, wrap(err)
	}
	v, err := pgx.CollectOneRow(rows, pgx.RowToAddrOfStructByNameLax[T])
	return v, wrap(err)
}

func many[T any](ctx context.Context, q Q, sql string, args ...any) ([]T, error) {
	rows, err := q.Query(ctx, sql, args...)
	if err != nil {
		return nil, wrap(err)
	}
	v, err := pgx.CollectRows(rows, pgx.RowToStructByNameLax[T])
	if v == nil {
		v = []T{}
	}
	return v, wrap(err)
}

func exec(ctx context.Context, q Q, sql string, args ...any) error {
	_, err := q.Exec(ctx, sql, args...)
	return wrap(err)
}

// StatusPatch describes the mutable fields shared by most entities.
type StatusPatch struct {
	DisplayName *string
	Description *string
	ExternalKey *string
	Status      *string
}
