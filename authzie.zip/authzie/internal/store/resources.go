package store

import (
	"context"
	"fmt"
)

const resCols = "id, service_id, resource_type_id, parent_id, external_id, external_key, display_name, description, status, depth, created_at, updated_at"

// CreateResource inserts a resource under parent (nil for the service root).
// Depth and parent validity (same service, live, depth limit) are enforced here.
func CreateResource(ctx context.Context, q Q, r *Resource) error {
	depth := 0
	if r.ParentID != nil {
		parent, err := one[Resource](ctx, q, `SELECT `+resCols+` FROM resources WHERE id=$1 AND status<>'deleted'`, *r.ParentID)
		if err != nil {
			return fmt.Errorf("%w: parent resource not found", ErrInvalid)
		}
		if parent.ServiceID != r.ServiceID {
			return fmt.Errorf("%w: parent belongs to another service", ErrInvalid)
		}
		depth = parent.Depth + 1
		if depth >= MaxDepth {
			return fmt.Errorf("%w: maximum tree depth (%d) exceeded", ErrInvalid, MaxDepth)
		}
	}
	// Same external_id can never be recreated once deleted.
	var deleted bool
	err := q.QueryRow(ctx, `SELECT status='deleted' FROM resources WHERE service_id=$1 AND external_id=$2`,
		r.ServiceID, r.ExternalID).Scan(&deleted)
	if err == nil {
		if deleted {
			return ErrObjectDeleted
		}
		return ErrAlreadyExists
	}
	r.Depth = depth
	return exec(ctx, q, `INSERT INTO resources (id, service_id, resource_type_id, parent_id, external_id, external_key,
		display_name, description, status, depth) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'active',$9)`,
		r.ID, r.ServiceID, r.ResourceTypeID, r.ParentID, r.ExternalID, r.ExternalKey, r.DisplayName, r.Description, depth)
}

func GetResource(ctx context.Context, q Q, id string) (*Resource, error) {
	return one[Resource](ctx, q, `SELECT `+resCols+` FROM resources WHERE id=$1 AND status<>'deleted'`, id)
}

func GetRootResource(ctx context.Context, q Q, serviceID string) (*Resource, error) {
	return one[Resource](ctx, q, `SELECT `+resCols+` FROM resources WHERE service_id=$1 AND external_id=$2`, serviceID, RootExternalID)
}

// ResourceFilter narrows ListResources.
type ResourceFilter struct {
	ExternalID     string
	ResourceTypeID string
	ParentID       string
}

func ListResources(ctx context.Context, q Q, serviceID string, f ResourceFilter, p Page) ([]Resource, error) {
	l, o := p.norm()
	return many[Resource](ctx, q, `SELECT `+resCols+` FROM resources WHERE service_id=$1 AND status<>'deleted'
		AND ($2='' OR external_id=$2) AND ($3='' OR resource_type_id=$3) AND ($4='' OR parent_id=$4)
		ORDER BY depth, external_id LIMIT $5 OFFSET $6`, serviceID, f.ExternalID, f.ResourceTypeID, f.ParentID, l, o)
}

func UpdateResource(ctx context.Context, q Q, id string, p StatusPatch) (*Resource, error) {
	return one[Resource](ctx, q, `UPDATE resources SET
		display_name=COALESCE($2,display_name), description=COALESCE($3,description),
		external_key=COALESCE($4,external_key), status=COALESCE($5,status), updated_at=now()
		WHERE id=$1 AND status<>'deleted' RETURNING `+resCols, id, p.DisplayName, p.Description, p.ExternalKey, p.Status)
}

// DeleteResource soft-deletes the resource and drops assignments scoped to it. Children are kept.
func DeleteResource(ctx context.Context, q Q, id string) error {
	if err := exec(ctx, q, `DELETE FROM assignments WHERE scope_type='resource' AND resource_id=$1`, id); err != nil {
		return err
	}
	return exec(ctx, q, `UPDATE resources SET status='deleted', updated_at=now() WHERE id=$1 AND status<>'deleted'`, id)
}

// ---- Roles ----

const roleCols = "id, name, display_name, description, status, created_at, updated_at"

func CreateRole(ctx context.Context, q Q, r *Role) error {
	return exec(ctx, q, `INSERT INTO roles (id, name, display_name, description, status) VALUES ($1,$2,$3,$4,'active')`,
		r.ID, r.Name, r.DisplayName, r.Description)
}

func GetRole(ctx context.Context, q Q, id string) (*Role, error) {
	return one[Role](ctx, q, `SELECT `+roleCols+` FROM roles WHERE id=$1 AND status<>'deleted'`, id)
}

func ListRoles(ctx context.Context, q Q, p Page) ([]Role, error) {
	l, o := p.norm()
	return many[Role](ctx, q, `SELECT `+roleCols+` FROM roles WHERE status<>'deleted' ORDER BY name LIMIT $1 OFFSET $2`, l, o)
}

func UpdateRole(ctx context.Context, q Q, id string, p StatusPatch) (*Role, error) {
	return one[Role](ctx, q, `UPDATE roles SET display_name=COALESCE($2,display_name),
		description=COALESCE($3,description), status=COALESCE($4,status), updated_at=now()
		WHERE id=$1 AND status<>'deleted' RETURNING `+roleCols, id, p.DisplayName, p.Description, p.Status)
}

func DeleteRole(ctx context.Context, q Q, id string) error {
	if err := exec(ctx, q, `DELETE FROM assignments WHERE role_id=$1`, id); err != nil {
		return err
	}
	if err := exec(ctx, q, `DELETE FROM role_permissions WHERE role_id=$1`, id); err != nil {
		return err
	}
	return exec(ctx, q, `UPDATE roles SET status='deleted', updated_at=now() WHERE id=$1 AND status<>'deleted'`, id)
}

func ListRolePermissionIDs(ctx context.Context, q Q, roleID string) ([]string, error) {
	rows, err := q.Query(ctx, `SELECT permission_id FROM role_permissions WHERE role_id=$1 ORDER BY permission_id`, roleID)
	if err != nil {
		return nil, wrap(err)
	}
	defer rows.Close()
	out := []string{}
	for rows.Next() {
		var s string
		if err := rows.Scan(&s); err != nil {
			return nil, wrap(err)
		}
		out = append(out, s)
	}
	return out, wrap(rows.Err())
}

// SetRolePermissions replaces the role's permission set. Unknown permission IDs return ErrInvalid.
func SetRolePermissions(ctx context.Context, q Q, roleID string, permIDs []string) error {
	if len(permIDs) > 0 {
		var n int
		if err := q.QueryRow(ctx, `SELECT count(*) FROM permissions WHERE id = ANY($1)`, permIDs).Scan(&n); err != nil {
			return wrap(err)
		}
		if n != len(permIDs) {
			return fmt.Errorf("%w: unknown permission id", ErrInvalid)
		}
	}
	if err := exec(ctx, q, `DELETE FROM role_permissions WHERE role_id=$1`, roleID); err != nil {
		return err
	}
	for _, pid := range permIDs {
		if err := exec(ctx, q, `INSERT INTO role_permissions (role_id, permission_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`, roleID, pid); err != nil {
			return err
		}
	}
	return nil
}
