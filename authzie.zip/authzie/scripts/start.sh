#!/usr/bin/env bash
# Build and start Authzie. Every AUTHZIE_* variable is listed here with its
# default; override any of them in the environment before running this script.
set -euo pipefail

cd "$(dirname "$0")/.."

# --- HTTP / core ----------------------------------------------------------
export AUTHZIE_LISTEN_ADDR="${AUTHZIE_LISTEN_ADDR:-127.0.0.1:8080}"
export AUTHZIE_DATABASE_URL="${AUTHZIE_DATABASE_URL:-postgres://app:secret@10.0.1.6:5432/authzie?sslmode=disable}"
export AUTHZIE_DATABASE_SCHEMA="${AUTHZIE_DATABASE_SCHEMA:-public}"
export AUTHZIE_LOG_LEVEL="${AUTHZIE_LOG_LEVEL:-info}"
export AUTHZIE_SESSION_TTL="${AUTHZIE_SESSION_TTL:-12h}"

# --- LDAP connection ------------------------------------------------------
export AUTHZIE_LDAP_URL="${AUTHZIE_LDAP_URL:-ldap://10.0.1.8:389}"
export AUTHZIE_LDAP_START_TLS="${AUTHZIE_LDAP_START_TLS:-false}"
export AUTHZIE_LDAP_CA_FILE="${AUTHZIE_LDAP_CA_FILE:-}"
export AUTHZIE_LDAP_INSECURE_SKIP_VERIFY="${AUTHZIE_LDAP_INSECURE_SKIP_VERIFY:-false}"
export AUTHZIE_LDAP_BIND_DN="${AUTHZIE_LDAP_BIND_DN:-}"
export AUTHZIE_LDAP_BIND_PASSWORD="${AUTHZIE_LDAP_BIND_PASSWORD:-}"
export AUTHZIE_LDAP_TIMEOUT="${AUTHZIE_LDAP_TIMEOUT:-10s}"
export AUTHZIE_LDAP_PAGE_SIZE="${AUTHZIE_LDAP_PAGE_SIZE:-500}"

# --- LDAP users -----------------------------------------------------------
export AUTHZIE_LDAP_USER_BASE_DN="${AUTHZIE_LDAP_USER_BASE_DN:-cn=users,dc=lab,dc=local}"
export AUTHZIE_LDAP_USER_FILTER="${AUTHZIE_LDAP_USER_FILTER:-(objectClass=inetOrgPerson)}"
export AUTHZIE_LDAP_USER_ID_ATTR="${AUTHZIE_LDAP_USER_ID_ATTR:-uid}"
export AUTHZIE_LDAP_USER_NAME_ATTR="${AUTHZIE_LDAP_USER_NAME_ATTR:-displayName}"
export AUTHZIE_LDAP_USER_DISABLED_ATTR="${AUTHZIE_LDAP_USER_DISABLED_ATTR:-sambaAcctFlags}"
export AUTHZIE_LDAP_USER_DISABLED_REGEX="${AUTHZIE_LDAP_USER_DISABLED_REGEX:-\[.*D.*\]}"

# --- LDAP groups ----------------------------------------------------------
export AUTHZIE_LDAP_GROUP_BASE_DN="${AUTHZIE_LDAP_GROUP_BASE_DN:-cn=groups,dc=lab,dc=local}"
export AUTHZIE_LDAP_GROUP_FILTER="${AUTHZIE_LDAP_GROUP_FILTER:-(objectClass=posixGroup)}"
export AUTHZIE_LDAP_GROUP_ID_ATTR="${AUTHZIE_LDAP_GROUP_ID_ATTR:-cn}"
export AUTHZIE_LDAP_GROUP_NAME_ATTR="${AUTHZIE_LDAP_GROUP_NAME_ATTR:-cn}"
export AUTHZIE_LDAP_GROUP_MEMBER_ATTR="${AUTHZIE_LDAP_GROUP_MEMBER_ATTR:-member}"

# --- LDAP mirror ----------------------------------------------------------
export AUTHZIE_LDAP_SYNC_INTERVAL="${AUTHZIE_LDAP_SYNC_INTERVAL:-60s}"
export AUTHZIE_LDAP_MAX_STALENESS="${AUTHZIE_LDAP_MAX_STALENESS:-30m}"
export AUTHZIE_LDAP_MAX_SHRINK_RATIO="${AUTHZIE_LDAP_MAX_SHRINK_RATIO:-0.5}"

mkdir -p bin
go build -o bin/authzie ./cmd/authzie

echo "Starting Authzie on http://${AUTHZIE_LISTEN_ADDR}"
exec ./bin/authzie
