package com.lab.tools;

import com.google.gson.JsonObject;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;

import static spark.Spark.*;

public class Web {
    static final Logger logger = MyLogger.getLogger(Web.class.getCanonicalName());

    public void start() {
        port(Constants.PORT);
        staticFiles.location("/public");
        staticFiles.externalLocation(Constants.CACHE_DIR);
        staticFiles.header("Access-Control-Allow-Origin", "*");
        enableCORS("*", "*", "*");
    }

    private static void enableCORS(final String origin, final String methods, final String headers) {
        options("/*", (request, response) -> {
            String accessControlRequestHeaders = request.headers("Access-Control-Request-Headers");
            if (accessControlRequestHeaders != null) {
                response.header("Access-Control-Allow-Headers", accessControlRequestHeaders);
            }

            String accessControlRequestMethod = request.headers("Access-Control-Request-Method");
            if (accessControlRequestMethod != null) {
                response.header("Access-Control-Allow-Methods", accessControlRequestMethod);
            }

            return null;
        });

        before((request, response) -> {
            response.header("Access-Control-Allow-Origin", origin);
            response.header("Access-Control-Request-Method", methods);
            response.header("Access-Control-Allow-Headers", headers);
            response.header("Access-Control-Allow-Credentials", "true");
        });

        get("/api/stream", (req, res) -> {
            new Thread(() -> {
                if (FileUtils.sizeOfDirectory(new File("cache")) / (1024.0 * 1024.0 * 1024.0) > 20) {
                    try {
                        FileUtils.cleanDirectory(new File("cache"));
                    } catch (IOException e) {
                        logger.error("Error while cleaning cache directory", e);
                    }
                }
            }).start();

            if (req.queryParams("file") == null) {
                res.status(400);
                res.type("application/json");
                return msg("File not found");
            }

            if (!new File(String.format("cache/%s.m3u8", Utils.getSha1Hash(req.queryParams("file")))).exists()) {
                new Thread(() -> {
                    File lockFile = new File(String.format("cache/%s.lock", Utils.getSha1Hash(req.queryParams("file"))));
                    if (lockFile.exists()) {
                        return;
                    }

                    try {
                        lockFile.createNewFile();
                    } catch (IOException e) {
                        logger.error("Error while creating lock file", e);
                    }

                    logger.info("Generating cache files...");
                    FFmpeg ffmpeg = new FFmpeg(System.getenv("FFMPEG_PATH"));
                    try {
                        ffmpeg.stream(req.queryParams("file"));
                    } catch (Exception e) {
                        res.status(500);
                        res.type("application/json");
                        logger.error("Failed to stream video: {}", e.getMessage());
                    } finally {
                        lockFile.delete();
                    }
                }).start();

                try {
                    Thread.sleep(5000);
                } catch (InterruptedException ignored) {}
            }

            res.redirect(String.format(
                    "http://%s:7010/%s.m3u8",
                    Constants.HOST,
                    Utils.getSha1Hash(req.queryParams("file")))
            );
            return null;
        });
    }

    private static JsonObject msg(String msg) {
        JsonObject error = new JsonObject();
        error.addProperty("msg", msg);
        return error;
    }
}