package com.lab.tools;

public class Constants {
    public static final int PORT = System.getProperty("port") == null ? 7010 : Integer.parseInt(System.getProperty("port"));

    // Do NOT use 'PATH' as environment variable name, which will shadow default $PATH variable in *NIX systems
    public static final String CACHE_DIR = System.getenv("CACHE_DIR");

    public static final String HOST = System.getenv("ENV") != null && System.getenv("ENV").equals("dev") ?
            "localhost" :
            "10.0.1.6";
}
