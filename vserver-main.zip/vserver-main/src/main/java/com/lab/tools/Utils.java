package com.lab.tools;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.logging.log4j.Logger;

import java.io.File;

public class Utils {
    static final Logger logger = MyLogger.getLogger(Utils.class.getCanonicalName());

    public static void ensureDirExists(String dir) {
        File file = new File(dir);
        file.mkdirs();
    }

    public static String getSha1Hash(String str) {
        return DigestUtils.sha1Hex(str);
    }
}
