package com.lab.tools;

import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.CommandLine;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

public class FFmpeg {
    static final Logger logger = MyLogger.getLogger(FFmpeg.class.getCanonicalName());
    private String executable;

    public FFmpeg(String executable) {
        this.executable = executable;
    }

    public void stream(String path) throws Exception {
        CommandLine cl = new CommandLine(executable);

//        String file = StringUtils.substringAfterLast(path, "/");
//        String fileName = StringUtils.substringBeforeLast(file, ".");

        String[] options = new String[] {
                "-hide_banner",
                "-loglevel",
                "error",
                "-i",
                path,
                "-profile:v",
                "baseline",
                "-preset",
                "ultrafast",
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-hls_time",
                "10",
                "-hls_list_size",
                "0",
                "-f",
                "hls",
                String.format("%s/%s.m3u8", Constants.CACHE_DIR, Utils.getSha1Hash(path))
        };

        for (String s : options) {
            cl.addArgument(s, false);
        }

        logger.info("Executing command: " + cl);

        DefaultExecutor executor = new DefaultExecutor();
        try {
            executor.execute(cl);
        } catch (IOException e) {
            logger.error("Error executing command", e);
        }
        logger.info("Done: {}.", path);
    }
}
