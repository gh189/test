package com.lab.tools;

import org.apache.logging.log4j.Logger;

/**
 * Hello world!
 *
 */
public class App 
{
    static final Logger logger = MyLogger.getLogger(App.class.getCanonicalName());
    public static void main( String[] args )
    {
        logger.info( "Started. Cache directory: {}", Constants.CACHE_DIR);
        Utils.ensureDirExists(Constants.CACHE_DIR);

        Web web = new Web();
        new Thread(web::start).start();
    }
}
