$(document).ready(function () {
    const player = videojs($("#video")[0], {
        controls: true,
        autoplay: true,
        preload: 'auto'
    });

    $("#playBtn").on('click', function() {
        player.pause();
        player.src([{
            type: 'application/x-mpegURL',
            src: `/api/stream?file=${$("#path").val()}`,
        }])
        player.load();
        player.play();
    });
});